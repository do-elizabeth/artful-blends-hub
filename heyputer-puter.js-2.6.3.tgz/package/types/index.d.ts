export class Puter {
    static FSItem: typeof FSItem;
    /**
     * The environment that the SDK is running in.
     *
     * `gui` means the SDK is running in the Puter GUI, i.e. Puter.com.
     * `app` means it is running as a Puter app, i.e. within an iframe in
     * the Puter GUI. `web` means it is running in a 3rd-party website.
     *
     * @type {import('./lib/types.js').PuterEnvironment}
     */
    env: import("./lib/types.js").PuterEnvironment;
    /**
     * Arguments the host environment launched this app with.
     *
     * @type {Record<string, unknown>}
     */
    args: Record<string, unknown>;
    /**
     * The token the SDK authenticates API calls with, if any.
     *
     * @type {string | null}
     */
    authToken: string | null;
    /**
     * Origin every API call is sent to.
     *
     * @type {string}
     */
    APIOrigin: string;
    /**
     * Tool schemas this app exposes to `puter.ai`.
     *
     * @type {import('./lib/types.js').ToolSchema[]}
     */
    tools: import("./lib/types.js").ToolSchema[];
    /** @type {InstanceType<typeof Util>} */
    util: InstanceType<typeof Util>;
    /** @type {InstanceType<typeof Auth>} */
    auth: InstanceType<typeof Auth>;
    /** @type {InstanceType<typeof OS>} */
    os: InstanceType<typeof OS>;
    /** @type {InstanceType<import('./modules/FileSystem/index.js').FSConstructor>} */
    fs: InstanceType<import("./modules/FileSystem/index.js").FSConstructor>;
    /** @type {InstanceType<typeof UI>} */
    ui: InstanceType<typeof UI>;
    /** @type {InstanceType<typeof Hosting>} */
    hosting: InstanceType<typeof Hosting>;
    /** @type {InstanceType<typeof Apps>} */
    apps: InstanceType<typeof Apps>;
    /** @type {InstanceType<typeof AI>} */
    ai: InstanceType<typeof AI>;
    /** @type {InstanceType<typeof KV>} */
    kv: InstanceType<typeof KV>;
    /** @type {InstanceType<typeof Email>} */
    email: InstanceType<typeof Email>;
    /** @type {InstanceType<typeof Events>} */
    events: InstanceType<typeof Events>;
    /** @type {InstanceType<typeof Perms>} */
    perms: InstanceType<typeof Perms>;
    /** @type {InstanceType<typeof Teams>} */
    teams: InstanceType<typeof Teams>;
    /** @type {InstanceType<typeof Drivers>} */
    drivers: InstanceType<typeof Drivers>;
    /** @type {InstanceType<typeof Debug>} */
    debug: InstanceType<typeof Debug>;
    /** @type {InstanceType<typeof Peer>} */
    peer: InstanceType<typeof Peer>;
    /** @type {InstanceType<import('./modules/Workers.js').WorkersConstructor>} */
    workers: InstanceType<import("./modules/Workers.js").WorkersConstructor>;
    /**
     * The `path-browserify` helpers, re-exposed so apps can build Puter paths
     * without pulling in their own copy. Spelled out rather than taken from
     * the package, which ships no types of its own.
     *
     * @type {{
     *     join: (...parts: string[]) => string,
     *     dirname: (p: string) => string,
     *     basename: (p: string) => string,
     *     normalize?: (p: string) => string,
     *     [key: string]: unknown,
     * }}
     */
    path: {
        join: (...parts: string[]) => string;
        dirname: (p: string) => string;
        basename: (p: string) => string;
        normalize?: (p: string) => string;
        [key: string]: unknown;
    };
    set defaultAPIOrigin(v: string);
    /** @returns {string} */
    get defaultAPIOrigin(): string;
    set defaultGUIOrigin(v: string);
    /** @returns {string} */
    get defaultGUIOrigin(): string;
    /**
     * Called once the user is authenticated. Set by the app using the SDK.
     *
     * @type {((user: Record<string, unknown>) => void) | undefined}
     */
    onAuth: ((user: Record<string, unknown>) => void) | undefined;
    /**
     * State object to keep track of the authentication request status. This
     * is used to prevent multiple authentication popups from showing up by
     * different parts of the app.
     */
    puterAuthState: {
        isPromptOpen: boolean;
        authGranted: null;
        resolver: null;
    };
    appInstanceID: string | undefined;
    parentInstanceID: string | undefined;
    eventHandlers: {};
    _reauthInflight: null;
    _authStateListeners: Set<any>;
    debugMode: boolean;
    quiet: boolean;
    /**
     * @internal
     * Whether a module holding a live connection (today, FileSystem's
     * cache-invalidation socket) may open one. Seeded off
     * `puter_socket_enabled` so an embedder can opt out before this instance
     * exists — e.g. the events worker runtime, which builds one client per
     * delivery and never wants it parked in a delivery-room socket.
     */
    socketEnabled: boolean;
    /**
     * Puter.js Modules
     *
     * These are the modules you see on docs.puter.com; for example:
     *
     * - Puter.fs
     * - Puter.kv
     * - Puter.ui
     *
     * InitSubmodules is called from the constructor of this class.
     */
    initSubmodules(): void;
    normalizeAuthTokenCandidate: (tokenCandidate: any) => string | null;
    decodeJwtPayload: (tokenCandidate: any) => any;
    normalizeStringCandidate: (valueCandidate: any) => string | null;
    decodeCompressedAppID: (compressedAppIDCandidate: any) => any;
    getAppIDFromAuthToken: (tokenCandidate: any) => any;
    _cache: kvjs;
    _opscache: kvjs;
    appID: string | undefined;
    appName: string | undefined;
    appDataPath: string | undefined;
    logger: SimpleLogger;
    apiCallLogger: APICallLogger;
    lock_rao_: Lock;
    p_can_request_rao_: Promise<void>;
    rao_requested_: boolean;
    whoamiCache_: any;
    _needsOriginReauth: {
        reason: string;
    } | null;
    /** @type {import('./modules/networking/types.js').Networking} */
    net: import("./modules/networking/types.js").Networking;
    /**
     * @internal
     * Makes a request to `/rao`. This method aquires a lock to prevent
     * multiple requests, and is effectively idempotent.
     */
    request_rao_(): Promise<any>;
    /**
     * @returns {Promise<import('./modules/Auth.js').User | null>} The
     *   cached user, or null when there was no token, the token was
     *   rejected, or the request failed.
     * @internal
     * Populates `puter.whoami` for callers that read the cached user
     * synchronously. Non-interactive for the same reason as `/rao`: this
     * runs on every load without the user asking, so a stale token must not
     * raise sign-in UI. Callers that need a definite answer (and the prompt
     * that comes with it) use `puter.auth.getUser()`.
     *
     * Uses `fetchUrl` rather than `this.auth` because `setAuthToken` runs
     * before `initSubmodules` in the app environment, and carries the token
     * explicitly because `includePuterAuth` reads `globalThis.puter`, which
     * isn't assigned until the constructor returns.
     */
    cacheWhoami_(): Promise<import("./modules/Auth.js").User | null>;
    whoami: any;
    /**
     * Instantiates a module, registers it for auth/origin updates, and
     * hands it back for the caller to attach. Assigning the result to a
     * named property rather than having this write `this[name]` is what
     * keeps each module's type visible to consumers of the SDK.
     *
     * @template T
     * @param {string} name
     * @param {new (
     *     puter: Puter,
     *     parameters: Record<string, unknown>,
     * ) => T} cls
     * @param {Record<string, unknown>} [parameters]
     * @returns {T}
     */
    registerModule<T>(name: string, cls: new (puter: Puter, parameters: Record<string, unknown>) => T, parameters?: Record<string, unknown>): T;
    /**
     * Subscribes to auth token / API origin changes. Modules read both live
     * off this instance, so this is only needed by the ones holding a
     * connection that has to be rebuilt.
     *
     * @param {() => void} listener
     * @returns {() => void} Unsubscribes the listener.
     */
    onAuthStateChanged(listener: () => void): () => void;
    _emitAuthStateChanged(): void;
    /** @param {string} appID */
    setAppID: (appID: string) => void;
    /** @param {string} authToken */
    setAuthToken: (authToken: string) => void;
    /**
     * Decides whether a stored token may be attached to requests for the
     * current API origin.
     *
     * - A bound token may only ever be replayed to the exact origin it was
     *   minted against.
     * - An unbound (legacy) token is only honored against the default API
     *   origin — never against a URL-supplied custom `puter.api_origin`.
     */
    _storedTokenUsableForCurrentOrigin: (boundOrigin: any) => boolean;
    /** @param {string} APIOrigin */
    setAPIOrigin: (APIOrigin: string) => void;
    runWhenPuterHappensCallbacks: () => void;
    /**
     * Forget the current token, in memory and (on a 3rd-party site or an
     * app) in localStorage. Callers own the surrounding policy — emitting
     * events, driving reauth — this only drops the value.
     *
     * @internal
     */
    _clearAuthToken: () => void;
    resetAuthToken: () => void;
    /**
     * Reauth coordinator. Called by the network layer (lib/utils.js) when
     * the backend returns `401 { code: 'reauth_required', reason, auth_id
     * }`.
     *
     * Behavior is environment-specific:
     *
     * - `web` / `app`: clear the stored token, emit an event, and drive the
     *   existing puter.com login popup. Returns a promise that resolves
     *   when the user signs in (so callers can replay) or rejects if reauth
     *   fails / is canceled.
     * - `gui`: no-op — the GUI environment renders its own modal and host
     *   code is responsible for the flow.
     * - Workers / nodejs: there's no UI surface to drive, so reject with a
     *   structured error and let worker code react.
     *
     * Idempotent: parallel callers share a single in-flight promise.
     *
     * @param {{ reason?: string; auth_id?: string }} signal
     */
    triggerReauth: (signal?: {
        reason?: string;
        auth_id?: string;
    }) => Promise<undefined>;
    /**
     * @param {{
     *     reason?: string;
     *     auth_id?: string;
     *     sentToken?: string;
     * }} signal
     * @internal
     * The non-interactive half of the reauth policy, called by the network
     * layer (lib/networkUtils.js) when a request the user didn't initiate
     * comes back `401 { code: 'reauth_required' | 'token_auth_failed' }`.
     *
     * Boot-time telemetry and cache warmers run on every page load, so
     * escalating their 401 to `triggerReauth` puts a sign-in popup (or the
     * consent dialog, when there's no user activation to open one with) in
     * front of a visitor who did nothing but load the page. Instead: forget
     * the dead token and announce it, leaving the prompt to the next call
     * the user actually makes.
     *
     * `sentToken` is the token the failed request carried. A reauth may have
     * completed while it was in flight, so a token that no longer matches is
     * left alone rather than signing the user back out.
     */
    dropStaleAuthToken: ({ reason, auth_id, sentToken }?: {
        reason?: string;
        auth_id?: string;
        sentToken?: string;
    }) => void;
    _emitReauthEvent: ({ reason, auth_id }: {
        reason: any;
        auth_id: any;
    }) => void;
    /**
     * Register a listener for SDK events. Used by host apps to react to
     * `puter.auth.reauth_required`.
     */
    on: (eventName: any, handler: any) => () => any;
    off: (eventName: any, handler: any) => void;
    /**
     * @internal
     * Delete a token left behind under the retired `puter.auth.token` key.
     * The backend no longer honors that format, so a visitor holding one is
     * simply signed out — sending it would only earn a 401, and leaving it
     * in storage would keep tempting later readers.
     */
    discardRetiredAuthToken_: () => void;
    exit: (statusCode?: number) => void;
    /**
     * A function that generates a domain-safe name by combining a random
     * adjective, a random noun, and a random number (between 0 and 9999).
     * The result is returned as a string with components separated by
     * hyphens. It is useful when you need to create unique identifiers that
     * are also human-friendly.
     *
     * @param {string} [separateWith='-'] - The character to use to separate
     *   the components of the generated name. Default is `'-'`
     * @returns {string} A unique, hyphen-separated string comprising of an
     *   adjective, a noun, and a number.
     */
    randName: (separateWith?: string) => string;
    getUser: (...args: any[]) => Promise<any>;
    print: (...args: any[]) => void;
    /**
     * Configures API call logging settings
     *
     * @param {import('./lib/types.js').APILoggingConfig} [config]
     * @returns {this}
     */
    configureAPILogging: (config?: import("./lib/types.js").APILoggingConfig) => this;
    /**
     * Enables API call logging with optional configuration
     *
     * @param {import('./lib/types.js').APILoggingConfig} [config]
     * @returns {this}
     */
    enableAPILogging: (config?: import("./lib/types.js").APILoggingConfig) => this;
    /**
     * Disables API call logging
     *
     * @returns {this}
     */
    disableAPILogging: () => this;
    /**
     * Initializes network connectivity monitoring to purge cache when
     * connection is lost
     *
     * @internal
     */
    initNetworkMonitoring: () => void;
    /**
     * Prints a styled CTA in the browser console encouraging developers to
     * publish their app on the Puter App Store.
     *
     * @internal
     */
    printDevCTA: () => void;
    /**
     * Shows the "Unsupported Protocol" warning dialog when the SDK is
     * loaded directly from the file:// protocol. Runs once on load (when
     * the DOM is ready) so the developer is told to use a web server
     * immediately, instead of only when an action triggers the auth flow.
     *
     * @internal
     */
    warnUnsupportedProtocol: () => void;
    /**
     * Checks and updates the GUI FS cache for most-commonly used paths
     *
     * @internal
     */
    checkAndUpdateGUIFScache: () => void;
    #private;
}
export const puter: Puter;
export default puter;
import Util from './modules/Util.js';
import Auth from './modules/Auth.js';
import { OS } from './modules/os/index.js';
import UI from './modules/UI.js';
import { Hosting } from './modules/hosting/index.js';
import { Apps } from './modules/apps/index.js';
import { AI } from './modules/ai/index.js';
import { KV } from './modules/kv/index.js';
import Email from './modules/Email.js';
import { Events } from './modules/events/index.js';
import { Perms } from './modules/perms/index.js';
import { Teams } from './modules/teams/index.js';
import Drivers from './modules/Drivers.js';
import { Debug } from './modules/Debug.js';
import Peer from './modules/Peer.js';
import kvjs from '@heyputer/kv.js';
declare class SimpleLogger {
    constructor(fields?: {});
    fieldsObj: {};
    enabled: Set<any>;
    on(category: any): void;
    fields(extra?: {}): SimpleLogger;
    info(...args: any[]): void;
    warn(...args: any[]): void;
    error(...args: any[]): void;
    debug(...args: any[]): void;
    _prefix(): string[];
}
import APICallLogger from './lib/APICallLogger.js';
declare class Lock {
    locked: boolean;
    queue: any[];
    acquire(): Promise<void>;
    release(): void;
}
import FSItem from './modules/FSItem.js';
