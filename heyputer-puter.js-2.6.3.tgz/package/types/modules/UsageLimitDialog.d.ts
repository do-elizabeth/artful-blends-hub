/**
 * Shows a usage limit dialog to the user
 * @param {string} message - The message to display
 */
export function showUsageLimitDialog(message: string): void;
export default UsageLimitDialog;
declare class UsageLimitDialog extends HTMLElement {
    constructor(message: any);
    message: any;
    connectedCallback(): void;
    open(): void;
    close(): void;
}
