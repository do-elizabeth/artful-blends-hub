export default getAbsolutePathForApp;
declare function getAbsolutePathForApp(relativePath: any, puter?: import("../../../index.js").Puter): any;
