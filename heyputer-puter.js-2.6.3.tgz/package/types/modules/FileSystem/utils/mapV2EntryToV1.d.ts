export default mapV2EntryToV1;
/**
 * Convert a v2 (camelCase) fsentry from `/fs/readdir` into the v1 snake_case
 * shape existing callers and the GUI consume. The backend readdir response is
 * enriched with the three fields the client can't reconstruct on its own
 * (`type`, a signed `thumbnail`, and `associatedApp`); everything else is a
 * rename or a trivial derivation here. Mirrors the backend's `toLegacyEntry`.
 *
 * @param {Record<string, unknown>} entry
 * @returns {Record<string, unknown>}
 */
declare function mapV2EntryToV1(entry: Record<string, unknown>): Record<string, unknown>;
