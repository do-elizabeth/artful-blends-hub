export default read;
export type ReadOptions = import("../types.js").ReadOptions;
/** @typedef {import('../types.js').ReadOptions} ReadOptions */
/**
 * Reads a file and resolves with its contents as a `Blob`. Relative paths
 * resolve against the app's root directory.
 *
 * @type {{
 *   (options: ReadOptions): Promise<Blob>,
 *   (
 *     filePath: string,
 *     options?: ReadOptions,
 *     success?: (value: Blob) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<Blob>,
 *   (
 *     filePath: string,
 *     success: (value: Blob) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<Blob>,
 * }}
 */
declare const read: {
    (options: ReadOptions): Promise<Blob>;
    (filePath: string, options?: ReadOptions, success?: (value: Blob) => void, error?: (reason: unknown) => void): Promise<Blob>;
    (filePath: string, success: (value: Blob) => void, error?: (reason: unknown) => void): Promise<Blob>;
};
