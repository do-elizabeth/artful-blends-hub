export function toShareRecipients(value: unknown): Array<{
    email?: string;
    username?: string;
}>;
export function toShareItems(options: Record<string, unknown>, resolvePath?: (path: string) => string): Array<{
    path?: string;
    uid?: string;
}>;
export function toShare(row: Record<string, unknown>): Share;
export function invalidateShareCache(items: Array<{
    path?: string;
    uid?: string;
}>): void;
export type Share = import("../types.js").Share;
export type ShareRecipient = import("../types.js").ShareRecipient;
