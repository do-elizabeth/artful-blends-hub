export default rename;
export type RenameOptions = import("../types.js").RenameOptions;
export type FSItem = import("../../FSItem.js").FSItem;
/** @typedef {import('../types.js').RenameOptions} RenameOptions */
/** @typedef {import('../../FSItem.js').FSItem} FSItem */
/**
 * Renames a file or directory. The item can be addressed by `path` (relative
 * paths resolve against the app's root directory) or by `uid`.
 *
 * @type {{
 *   (options: RenameOptions): Promise<FSItem>,
 *   (
 *     path: string,
 *     newName: string,
 *     success?: (value: FSItem) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItem>,
 * }}
 */
declare const rename: {
    (options: RenameOptions): Promise<FSItem>;
    (path: string, newName: string, success?: (value: FSItem) => void, error?: (reason: unknown) => void): Promise<FSItem>;
};
