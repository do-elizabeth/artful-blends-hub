export function chunkArray(values: unknown[], chunkSize: number): unknown[][];
export function normalizeUploadEntries(items: unknown, options: Record<string, unknown>): Promise<unknown[]>;
export function separateFilesAndDirs(entries: unknown[], dirPath: string, options: Record<string, unknown>): {
    dirs: Array<{
        path: string;
    }>;
    files: unknown[];
    totalSize: number;
    fileCount: number;
};
