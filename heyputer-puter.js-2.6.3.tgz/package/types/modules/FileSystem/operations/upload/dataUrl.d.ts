export function estimateDataUrlSize(dataUrl: string): number;
export function isDataUrl(value: unknown): boolean;
export function parseDataUrlContentType(dataUrl: string): string | undefined;
export function dataUrlToBlob(dataUrl: string): Promise<Blob>;
