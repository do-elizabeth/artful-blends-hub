export function postJson(apiOrigin: string, authToken: string, endpoint: string, payload: unknown): Promise<unknown>;
export function toErrorMessage(error: unknown): string;
export function uploadBlobToSignedUrl({ url, blob, contentType, timeoutMs, onProgress, onRequestCreated, onRequestCompleted, }: {
    url: string;
    blob: Blob;
    contentType?: string;
    timeoutMs?: number;
    onProgress?: (deltaBytes: number) => void;
    onRequestCreated?: (request: XMLHttpRequest) => void;
    onRequestCompleted?: (request: XMLHttpRequest) => void;
}): Promise<{
    etag: string | null;
}>;
