/**
 * Run the signed batch-write upload for the current operation.
 *
 * Resolves/rejects the caller's promise (via `ctx.resolve` / `ctx.reject` /
 * `ctx.error`) and returns `true` when the upload was fully handled. Returns
 * `false` when the backend does not support signed batch writes, signalling the
 * caller to fall back to the legacy upload path.
 *
 * Must be called with the FileSystem module as `this`.
 *
 * @param {object} ctx
 * @returns {Promise<boolean>} `true` if settled, `false` to fall back to legacy
 */
export function performSignedBatchUpload(ctx: object): Promise<boolean>;
export class performSignedBatchUpload {
    /**
     * Run the signed batch-write upload for the current operation.
     *
     * Resolves/rejects the caller's promise (via `ctx.resolve` / `ctx.reject` /
     * `ctx.error`) and returns `true` when the upload was fully handled. Returns
     * `false` when the backend does not support signed batch writes, signalling the
     * caller to fall back to the legacy upload path.
     *
     * Must be called with the FileSystem module as `this`.
     *
     * @param {object} ctx
     * @returns {Promise<boolean>} `true` if settled, `false` to fall back to legacy
     */
    constructor(ctx: object);
    signedBatchWriteSupported: boolean;
}
export function isSignedBatchWriteUnavailableError(error: unknown): boolean;
export function sharedFailureFields(failedItems: Array<{
    code?: string;
    status?: number;
}>): {
    code?: string;
    status?: number;
};
export function toSignedRequestPath(baseDirPath: string, requestItem: {
    type?: string;
    directoryPath?: string;
    file?: {
        puter_full_path?: string;
        filepath?: string;
        name?: string;
    };
}): string | undefined;
