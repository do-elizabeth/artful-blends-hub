export function normalizeThumbnailData(thumbnailData: unknown): string | undefined;
export function defaultThumbnailGenerator(file: File): Promise<string | undefined>;
export function generateThumbnails(files: File[], options: import("../../types.js").UploadOptions, signal?: AbortSignal): Promise<Array<string | undefined>>;
