export default upload;
export type UploadItems = import("../../types.js").UploadItems;
export type UploadOptions = import("../../types.js").UploadOptions;
export type FSItem = import("../../../FSItem.js").FSItem;
export type UploadOperation = (this: import("../../index.js").PuterJSFileSystemModule, items: UploadItems, dirPath?: string, options?: UploadOptions) => Promise<FSItem | FSItem[]>;
declare const upload: UploadOperation;
