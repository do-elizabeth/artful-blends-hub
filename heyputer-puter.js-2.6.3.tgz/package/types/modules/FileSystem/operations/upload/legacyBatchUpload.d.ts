/**
 * Run the legacy `/batch` upload for the current operation. Settles the
 * caller's promise asynchronously through `ctx.resolve` / `ctx.error` once the
 * server responds.
 *
 * Must be called with the FileSystem module as `this`.
 *
 * @param {object} ctx
 * @returns {void}
 */
export function performLegacyBatchUpload(ctx: object): void;
export type BatchResult = {
    error?: boolean;
    status?: number;
    message?: string;
    code?: string;
};
