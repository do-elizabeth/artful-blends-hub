export default copy;
export type CopyOptions = import("../types.js").CopyOptions;
export type FSItem = import("../../FSItem.js").FSItem;
/** @typedef {import('../types.js').CopyOptions} CopyOptions */
/** @typedef {import('../../FSItem.js').FSItem} FSItem */
/**
 * Copies a file or directory to another location. Relative paths resolve
 * against the app's root directory. When `destination` is a directory the item
 * is copied into it under the same name.
 *
 * @type {{
 *   (options: CopyOptions): Promise<FSItem>,
 *   (
 *     source: string,
 *     destination: string,
 *     options?: CopyOptions,
 *     success?: (value: FSItem) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItem>,
 * }}
 */
declare const copy: {
    (options: CopyOptions): Promise<FSItem>;
    (source: string, destination: string, options?: CopyOptions, success?: (value: FSItem) => void, error?: (reason: unknown) => void): Promise<FSItem>;
};
