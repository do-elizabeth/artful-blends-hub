/**
 * Performs one authenticated request against the filesystem API and resolves
 * with the parsed response, after running it through `transform` if given.
 * Legacy success/error callbacks receive the same value the promise settles
 * with.
 *
 * @this {FileSystemModule}
 * @param {FSRequestSpec} spec
 * @returns {Promise<unknown>}
 */
export function fsRequest(this: import("../index.js").PuterJSFileSystemModule, spec: FSRequestSpec): Promise<unknown>;
export function isOptionsObject(value: unknown): boolean;
export function firstDefined(options: Record<string, unknown>, ...names: string[]): unknown;
export function parseOperationArgs(args: unknown[], positional?: string[]): Record<string, unknown>;
export function ensureAuthenticated(): Promise<void>;
export function defineOperation<T extends (...args: any[]) => Promise<unknown> = (this: FileSystemModule, ...args: unknown[]) => Promise<unknown>>({ positional, request }: {
    positional?: string[];
    request: (this: FileSystemModule, options: Record<string, unknown>) => FSRequestSpec | Promise<FSRequestSpec>;
}): T;
export type FileSystemModule = import("../index.js").PuterJSFileSystemModule;
/**
 * One request against the filesystem API.
 */
export type FSRequestSpec = {
    endpoint: string;
    body?: unknown;
    method?: "get" | "post" | "put" | "delete";
    contentType?: string;
    responseType?: "" | "blob" | "text";
    authHeader?: boolean;
    prepareXhr?: (xhr: XMLHttpRequest) => void;
    transform?: (response: unknown) => unknown;
    success?: (value: unknown) => void;
    error?: (reason: unknown) => void;
};
