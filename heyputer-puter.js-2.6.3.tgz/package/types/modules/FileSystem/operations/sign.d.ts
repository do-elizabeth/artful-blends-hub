export default sign;
export type SignResult = import("../types.js").SignResult;
/** @typedef {import('../types.js').SignResult} SignResult */
/**
 * Signs one or more filesystem entries for an app, producing the access URLs
 * and token that let the app open them. Resolves with `{ token, items }`,
 * where `items` is a single object when a single item was signed and an array
 * otherwise.
 *
 * @type {(
 *   appUid: string,
 *   items: unknown | unknown[],
 *   success?: (value: SignResult) => void,
 *   error?: (reason: unknown) => void,
 * ) => Promise<SignResult>}
 */
declare const sign: (appUid: string, items: unknown | unknown[], success?: (value: SignResult) => void, error?: (reason: unknown) => void) => Promise<SignResult>;
