export default listSharedByMe;
export type ListSharedByMeOptions = import("../types.js").ListSharedByMeOptions;
export type SharePage = import("../types.js").SharePage;
/** @typedef {import('../types.js').ListSharedByMeOptions} ListSharedByMeOptions */
/** @typedef {import('../types.js').SharePage} SharePage */
/**
 * Lists everything you have shared out, a page at a time — across every item,
 * without naming one. Includes invites nobody has claimed yet (`pending`),
 * and, for items you own, shares a delegate with `manage` access issued.
 *
 * `appUid` narrows to what one app issued in your name, or `'none'` for what
 * you shared yourself. An app is bound to its own grants either way.
 *
 * `cursor` comes back only while more pages remain, so iterate until it is
 * absent rather than comparing `items.length` to `limit` — a page can be short
 * once items the caller can no longer see are filtered out.
 *
 * @type {{
 *   (options?: ListSharedByMeOptions): Promise<SharePage>,
 *   (
 *     success?: (value: SharePage) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<SharePage>,
 * }}
 */
declare const listSharedByMe: {
    (options?: ListSharedByMeOptions): Promise<SharePage>;
    (success?: (value: SharePage) => void, error?: (reason: unknown) => void): Promise<SharePage>;
};
