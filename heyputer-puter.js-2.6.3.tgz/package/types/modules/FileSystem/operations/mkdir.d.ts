export default mkdir;
export type MkdirOptions = import("../types.js").MkdirOptions;
export type FSItem = import("../../FSItem.js").FSItem;
/** @typedef {import('../types.js').MkdirOptions} MkdirOptions */
/** @typedef {import('../../FSItem.js').FSItem} FSItem */
/**
 * Creates a directory. Relative paths resolve against the app's root
 * directory.
 *
 * @type {{
 *   (options: MkdirOptions): Promise<FSItem>,
 *   (
 *     dirPath: string,
 *     options?: MkdirOptions,
 *     success?: (value: FSItem) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItem>,
 *   (
 *     dirPath: string,
 *     success: (value: FSItem) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItem>,
 * }}
 */
declare const mkdir: {
    (options: MkdirOptions): Promise<FSItem>;
    (dirPath: string, options?: MkdirOptions, success?: (value: FSItem) => void, error?: (reason: unknown) => void): Promise<FSItem>;
    (dirPath: string, success: (value: FSItem) => void, error?: (reason: unknown) => void): Promise<FSItem>;
};
