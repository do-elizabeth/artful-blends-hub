export default unshare;
export type UnshareOptions = import("../types.js").UnshareOptions;
export type ShareRecipient = import("../types.js").ShareRecipient;
/** @typedef {import('../types.js').UnshareOptions} UnshareOptions */
/** @typedef {import('../types.js').ShareRecipient} ShareRecipient */
/**
 * Withdraws a user's access to a file or directory.
 *
 * The item's owner can withdraw any share of it, whoever granted it. Anyone
 * else can withdraw the shares they granted, or their own access — pass
 * yourself as the recipient to leave a share someone else gave you.
 *
 * Resolves with the number of grants actually removed, which is `0` when there
 * was nothing to withdraw.
 *
 * @type {{
 *   (options: UnshareOptions): Promise<{ revoked: number }>,
 *   (
 *     path: string,
 *     recipient: ShareRecipient,
 *     success?: (value: { revoked: number }) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<{ revoked: number }>,
 * }}
 */
declare const unshare: {
    (options: UnshareOptions): Promise<{
        revoked: number;
    }>;
    (path: string, recipient: ShareRecipient, success?: (value: {
        revoked: number;
    }) => void, error?: (reason: unknown) => void): Promise<{
        revoked: number;
    }>;
};
