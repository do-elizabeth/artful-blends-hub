export default space;
export type SpaceInfo = import("../types.js").SpaceInfo;
export type SpaceCallbacks = import("../../../lib/types.js").RequestCallbacks<SpaceInfo>;
/** @typedef {import('../types.js').SpaceInfo} SpaceInfo */
/** @typedef {import('../../../lib/types.js').RequestCallbacks<SpaceInfo>} SpaceCallbacks */
/**
 * Returns the storage capacity and usage of the current user, in bytes.
 *
 * @type {{
 *   (options?: SpaceCallbacks): Promise<SpaceInfo>,
 *   (
 *     success: (value: SpaceInfo) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<SpaceInfo>,
 * }}
 */
declare const space: {
    (options?: SpaceCallbacks): Promise<SpaceInfo>;
    (success: (value: SpaceInfo) => void, error?: (reason: unknown) => void): Promise<SpaceInfo>;
};
