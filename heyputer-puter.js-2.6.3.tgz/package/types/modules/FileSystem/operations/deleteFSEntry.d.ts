export default deleteFSEntry;
export type DeleteOptions = import("../types.js").DeleteOptions;
/** @typedef {import('../types.js').DeleteOptions} DeleteOptions */
/**
 * Deletes one or more files or directories. Relative paths resolve against the
 * app's root directory.
 *
 * Named `deleteFSEntry` rather than `delete` because `delete` is a reserved
 * keyword; it is exposed as `puter.fs.delete`.
 *
 * @type {{
 *   (options: DeleteOptions): Promise<void>,
 *   (
 *     paths: string | string[],
 *     options?: DeleteOptions,
 *     success?: () => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<void>,
 * }}
 */
declare const deleteFSEntry: {
    (options: DeleteOptions): Promise<void>;
    (paths: string | string[], options?: DeleteOptions, success?: () => void, error?: (reason: unknown) => void): Promise<void>;
};
