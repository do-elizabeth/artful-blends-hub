export default revokeReadURL;
/**
 * Revokes a read URL (or the access token / token UUID used by it).
 * After revocation, the URL will no longer allow reading the file.
 *
 * @type {(urlOrTokenOrUuid: string) => Promise<void>}
 */
declare const revokeReadURL: (urlOrTokenOrUuid: string) => Promise<void>;
