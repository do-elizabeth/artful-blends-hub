export default share;
export type ShareOptions = import("../types.js").ShareOptions;
export type ShareMode = import("../types.js").ShareMode;
export type ShareRecipient = import("../types.js").ShareRecipient;
export type Share = import("../types.js").Share;
/** @typedef {import('../types.js').ShareOptions} ShareOptions */
/** @typedef {import('../types.js').ShareMode} ShareMode */
/** @typedef {import('../types.js').ShareRecipient} ShareRecipient */
/** @typedef {import('../types.js').Share} Share */
/**
 * Gives another Puter user access to a file or directory. Relative paths
 * resolve against the app's root directory.
 *
 * Resolves with one {@link Share} per recipient/item pair that succeeded. A
 * pair that fails — an unknown recipient, say — does not fail the others; its
 * error is reported on the rejected pair only when every pair failed.
 *
 * @type {{
 *   (options: ShareOptions): Promise<Share[]>,
 *   (
 *     path: string,
 *     recipient: ShareRecipient | ShareRecipient[],
 *     mode?: ShareMode,
 *     success?: (value: Share[]) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<Share[]>,
 * }}
 */
declare const share: {
    (options: ShareOptions): Promise<Share[]>;
    (path: string, recipient: ShareRecipient | ShareRecipient[], mode?: ShareMode, success?: (value: Share[]) => void, error?: (reason: unknown) => void): Promise<Share[]>;
};
