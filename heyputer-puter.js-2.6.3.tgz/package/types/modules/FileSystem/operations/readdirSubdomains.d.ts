export default readdirSubdomains;
export type DirectorySubdomains = {
    directory_id: number;
    subdomains: unknown[];
    has_website: boolean;
};
/**
 * @typedef {{
 *   directory_id: number,
 *   subdomains: unknown[],
 *   has_website: boolean,
 * }} DirectorySubdomains
 */
/**
 * Fetches the subdomains hosted out of each of the given directories, in one
 * request.
 *
 * @type {(options: {
 *   directory_ids: number[],
 *   success?: (value: DirectorySubdomains[]) => void,
 *   error?: (reason: unknown) => void,
 * }) => Promise<DirectorySubdomains[]>}
 */
declare const readdirSubdomains: (options: {
    directory_ids: number[];
    success?: (value: DirectorySubdomains[]) => void;
    error?: (reason: unknown) => void;
}) => Promise<DirectorySubdomains[]>;
