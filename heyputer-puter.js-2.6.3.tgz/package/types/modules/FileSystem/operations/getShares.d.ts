export default getShares;
export type GetSharesOptions = import("../types.js").GetSharesOptions;
export type Share = import("../types.js").Share;
/** @typedef {import('../types.js').GetSharesOptions} GetSharesOptions */
/** @typedef {import('../types.js').Share} Share */
/**
 * Lists who can reach a file or directory you can manage.
 *
 * Includes shares granted by anyone holding `manage` on the item, not only
 * your own — which is how an owner sees what a delegate has re-shared.
 *
 * @type {{
 *   (options: GetSharesOptions): Promise<Share[]>,
 *   (
 *     path: string,
 *     success?: (value: Share[]) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<Share[]>,
 * }}
 */
declare const getShares: {
    (options: GetSharesOptions): Promise<Share[]>;
    (path: string, success?: (value: Share[]) => void, error?: (reason: unknown) => void): Promise<Share[]>;
};
