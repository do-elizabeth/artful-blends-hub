export default getReadURL;
/**
 * Creates a URL that reads the file at `path` without further authentication.
 *
 * `expiresIn` is how long the URL stays valid, as a
 * [jsonwebtoken](https://github.com/auth0/node-jsonwebtoken#usage) duration
 * string (e.g. `'24h'`, `'30d'`; units `s`, `m`, `h`, `d`, `w`, `y`) or a
 * number of seconds. Directories cannot be read this way.
 *
 * @type {(path: string, expiresIn?: string | number) => Promise<string>}
 */
declare const getReadURL: (path: string, expiresIn?: string | number) => Promise<string>;
