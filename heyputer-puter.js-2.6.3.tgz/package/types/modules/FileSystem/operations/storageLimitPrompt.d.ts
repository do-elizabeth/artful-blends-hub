export function isStorageLimitError(error: unknown): boolean;
export function promptIfStorageLimitError(error: unknown): void;
