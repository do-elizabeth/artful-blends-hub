export default listShared;
export type ListSharedOptions = import("../types.js").ListSharedOptions;
export type SharePage = import("../types.js").SharePage;
/** @typedef {import('../types.js').ListSharedOptions} ListSharedOptions */
/** @typedef {import('../types.js').SharePage} SharePage */
/**
 * Lists what other users have shared with you, a page at a time.
 *
 * `cursor` comes back only while more pages remain, so iterate until it is
 * absent rather than comparing `items.length` to `limit` — a page can be short
 * once items the caller can no longer see are filtered out.
 *
 * @type {{
 *   (options?: ListSharedOptions): Promise<SharePage>,
 *   (
 *     success?: (value: SharePage) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<SharePage>,
 * }}
 */
declare const listShared: {
    (options?: ListSharedOptions): Promise<SharePage>;
    (success?: (value: SharePage) => void, error?: (reason: unknown) => void): Promise<SharePage>;
};
