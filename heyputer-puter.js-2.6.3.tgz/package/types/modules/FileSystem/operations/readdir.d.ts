export default readdir;
export type ReaddirOptions = import("../types.js").ReaddirOptions;
export type FSItemRead = import("../types.js").FSItemRead;
export type FSItemPage = import("../../../lib/types.js").ListPage<FSItemRead>;
export type ReaddirOperation = {
    (options: ReaddirOptions & {
        stream: true;
    }): AsyncIterableIterator<FSItemPage>;
    (options: ReaddirOptions & ({
        cursor: string | null;
    } | {
        includeTotal: true;
    })): Promise<FSItemPage>;
    (options: ReaddirOptions): Promise<FSItemRead[]>;
    (path: string, options?: ReaddirOptions, success?: (value: FSItemRead[]) => void, error?: (reason: unknown) => void): Promise<FSItemRead[]>;
    (path: string, success?: (value: FSItemRead[]) => void, error?: (reason: unknown) => void): Promise<FSItemRead[]>;
};
/**
 * @typedef {{
 *   (options: ReaddirOptions & { stream: true }): AsyncIterableIterator<FSItemPage>,
 *   (options: ReaddirOptions & ({ cursor: string | null } | { includeTotal: true })): Promise<FSItemPage>,
 *   (options: ReaddirOptions): Promise<FSItemRead[]>,
 *   (
 *     path: string,
 *     options?: ReaddirOptions,
 *     success?: (value: FSItemRead[]) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItemRead[]>,
 *   (
 *     path: string,
 *     success?: (value: FSItemRead[]) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItemRead[]>,
 * }} ReaddirOperation
 */
/**
 * Lists the contents of a directory, addressed by `path` (relative paths
 * resolve against the app's root directory) or by `uid`.
 *
 * By default the whole listing is returned as an array. Passing `cursor` or
 * `includeTotal` returns one `{items, cursor?, total?}` page instead, and
 * `stream: true` returns an async iterator over those pages.
 *
 * @type {ReaddirOperation}
 */
declare const readdir: ReaddirOperation;
