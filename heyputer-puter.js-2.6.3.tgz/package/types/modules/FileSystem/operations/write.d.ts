export default write;
export type WriteOptions = import("../types.js").WriteOptions;
export type FSItem = import("../../FSItem.js").FSItem;
export type WriteOperation = {
    (file: File): Promise<FSItem>;
    (targetPath: string, data?: string | File | Blob | ArrayBuffer | ArrayBufferView, options?: WriteOptions): Promise<FSItem>;
};
/**
 * Writes data to a file, creating it if it doesn't exist and overwriting it if
 * it does. Relative paths resolve against the app's root directory. Writing no
 * data creates an empty file; writing a `File` on its own names the file after
 * itself.
 *
 * @type {WriteOperation}
 */
declare const write: WriteOperation;
