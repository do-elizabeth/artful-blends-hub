export default move;
export type MoveOptions = import("../types.js").MoveOptions;
export type FSItem = import("../../FSItem.js").FSItem;
/** @typedef {import('../types.js').MoveOptions} MoveOptions */
/** @typedef {import('../../FSItem.js').FSItem} FSItem */
/**
 * Moves a file or directory to another location. Relative paths resolve
 * against the app's root directory. When `destination` is a directory the item
 * is moved into it under the same name; otherwise the last path component is
 * used as the new name.
 *
 * @type {{
 *   (options: MoveOptions): Promise<FSItem>,
 *   (
 *     source: string,
 *     destination: string,
 *     options?: MoveOptions,
 *     success?: (value: FSItem) => void,
 *     error?: (reason: unknown) => void,
 *   ): Promise<FSItem>,
 * }}
 */
declare const move: {
    (options: MoveOptions): Promise<FSItem>;
    (source: string, destination: string, options?: MoveOptions, success?: (value: FSItem) => void, error?: (reason: unknown) => void): Promise<FSItem>;
};
