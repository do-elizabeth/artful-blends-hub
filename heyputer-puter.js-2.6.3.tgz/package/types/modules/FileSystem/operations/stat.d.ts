export default stat;
export type StatOptions = import("../types.js").StatOptions;
export type FSItemRead = import("../types.js").FSItemRead;
export type FSItemWithShares = import("../types.js").FSItemWithShares;
export type StatOperation = {
    (options: StatOptions & {
        returnShares: true;
    }): Promise<FSItemWithShares>;
    (options: StatOptions): Promise<FSItemRead>;
    (path: string, options: StatOptions & {
        returnShares: true;
    }, success?: (value: FSItemWithShares) => void, error?: (reason: unknown) => void): Promise<FSItemWithShares>;
    (path: string, options?: StatOptions, success?: (value: FSItemRead) => void, error?: (reason: unknown) => void): Promise<FSItemRead>;
    (path: string, success: (value: FSItemRead) => void, error?: (reason: unknown) => void): Promise<FSItemRead>;
};
declare const stat: StatOperation;
