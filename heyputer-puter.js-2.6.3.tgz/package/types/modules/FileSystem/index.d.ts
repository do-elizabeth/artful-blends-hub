/**
 * The Cloud Storage API. Lets you store and manage files and directories in
 * the cloud.
 *
 * Operation implementations live under `operations/` as `this`-context
 * functions whose JSDoc (including the per-form `@overload` declarations) is
 * the source of truth for the public signatures — `types/` is generated from
 * it, never edited by hand.
 */
export class PuterJSFileSystemModule extends PuterModule {
    space: {
        (options?: import("./operations/space.js").SpaceCallbacks): Promise<import("./operations/space.js").SpaceInfo>;
        (success: (value: import("./operations/space.js").SpaceInfo) => void, error?: (reason: unknown) => void): Promise<import("./operations/space.js").SpaceInfo>;
    };
    mkdir: {
        (options: import("./operations/mkdir.js").MkdirOptions): Promise<import("./operations/mkdir.js").FSItem>;
        (dirPath: string, options?: import("./operations/mkdir.js").MkdirOptions, success?: (value: import("./operations/mkdir.js").FSItem) => void, error?: (reason: unknown) => void): Promise<import("./operations/mkdir.js").FSItem>;
        (dirPath: string, success: (value: import("./operations/mkdir.js").FSItem) => void, error?: (reason: unknown) => void): Promise<import("./operations/mkdir.js").FSItem>;
    };
    copy: {
        (options: import("./operations/copy.js").CopyOptions): Promise<import("./operations/copy.js").FSItem>;
        (source: string, destination: string, options?: import("./operations/copy.js").CopyOptions, success?: (value: import("./operations/copy.js").FSItem) => void, error?: (reason: unknown) => void): Promise<import("./operations/copy.js").FSItem>;
    };
    rename: {
        (options: import("./operations/rename.js").RenameOptions): Promise<import("./operations/rename.js").FSItem>;
        (path: string, newName: string, success?: (value: import("./operations/rename.js").FSItem) => void, error?: (reason: unknown) => void): Promise<import("./operations/rename.js").FSItem>;
    };
    upload: import("./operations/upload/index.js").UploadOperation;
    read: {
        (options: import("./operations/read.js").ReadOptions): Promise<Blob>;
        (filePath: string, options?: import("./operations/read.js").ReadOptions, success?: (value: Blob) => void, error?: (reason: unknown) => void): Promise<Blob>;
        (filePath: string, success: (value: Blob) => void, error?: (reason: unknown) => void): Promise<Blob>;
    };
    delete: {
        (options: import("./operations/deleteFSEntry.js").DeleteOptions): Promise<void>;
        (paths: string | string[], options?: import("./operations/deleteFSEntry.js").DeleteOptions, success?: () => void, error?: (reason: unknown) => void): Promise<void>;
    };
    move: {
        (options: import("./operations/move.js").MoveOptions): Promise<import("./operations/move.js").FSItem>;
        (source: string, destination: string, options?: import("./operations/move.js").MoveOptions, success?: (value: import("./operations/move.js").FSItem) => void, error?: (reason: unknown) => void): Promise<import("./operations/move.js").FSItem>;
    };
    write: import("./operations/write.js").WriteOperation;
    sign: (appUid: string, items: unknown | unknown[], success?: (value: import("./operations/sign.js").SignResult) => void, error?: (reason: unknown) => void) => Promise<import("./operations/sign.js").SignResult>;
    getReadURL: (path: string, expiresIn?: string | number) => Promise<string>;
    revokeReadURL: (urlOrTokenOrUuid: string) => Promise<void>;
    readdir: import("./operations/readdir.js").ReaddirOperation;
    readdirSubdomains: (options: {
        directory_ids: number[];
        success?: (value: import("./operations/readdirSubdomains.js").DirectorySubdomains[]) => void;
        error?: (reason: unknown) => void;
    }) => Promise<import("./operations/readdirSubdomains.js").DirectorySubdomains[]>;
    stat: import("./operations/stat.js").StatOperation;
    share: {
        (options: import("./operations/share.js").ShareOptions): Promise<import("./operations/share.js").Share[]>;
        (path: string, recipient: import("./operations/share.js").ShareRecipient | import("./operations/share.js").ShareRecipient[], mode?: import("./operations/share.js").ShareMode, success?: (value: import("./operations/share.js").Share[]) => void, error?: (reason: unknown) => void): Promise<import("./operations/share.js").Share[]>;
    };
    unshare: {
        (options: import("./operations/unshare.js").UnshareOptions): Promise<{
            revoked: number;
        }>;
        (path: string, recipient: import("./operations/unshare.js").ShareRecipient, success?: (value: {
            revoked: number;
        }) => void, error?: (reason: unknown) => void): Promise<{
            revoked: number;
        }>;
    };
    listShared: {
        (options?: import("./operations/listShared.js").ListSharedOptions): Promise<import("./operations/listShared.js").SharePage>;
        (success?: (value: import("./operations/listShared.js").SharePage) => void, error?: (reason: unknown) => void): Promise<import("./operations/listShared.js").SharePage>;
    };
    listSharedByMe: {
        (options?: import("./operations/listSharedByMe.js").ListSharedByMeOptions): Promise<import("./operations/listSharedByMe.js").SharePage>;
        (success?: (value: import("./operations/listSharedByMe.js").SharePage) => void, error?: (reason: unknown) => void): Promise<import("./operations/listSharedByMe.js").SharePage>;
    };
    getShares: {
        (options: import("./operations/getShares.js").GetSharesOptions): Promise<import("./operations/getShares.js").Share[]>;
        (path: string, success?: (value: import("./operations/getShares.js").Share[]) => void, error?: (reason: unknown) => void): Promise<import("./operations/getShares.js").Share[]>;
    };
    FSItem: typeof FSItem;
    cacheUpdateTimer: NodeJS.Timeout | null;
    /**
     * Initializes the socket connection to the server using the current API origin.
     * If a socket connection already exists, it disconnects it before creating a new one.
     * Sets up various event listeners on the socket to handle different socket events like
     * connect, disconnect, reconnect, reconnect_attempt, reconnect_error, reconnect_failed, and error.
     *
     * @memberof FileSystem
     * @returns {void}
     */
    initializeSocket(): void;
    socket: import("socket.io-client").Socket<import("@socket.io/component-emitter").DefaultEventsMap, import("@socket.io/component-emitter").DefaultEventsMap> | undefined;
    shouldUseSocketAutoUnref(): boolean;
    bindSocketEvents(): void;
    /**
     * Reconnects the socket against the current token and API origin. Called
     * by the SDK whenever either changes.
     *
     * @memberof [FileSystem]
     * @returns {void}
     */
    onAuthStateChanged(): void;
    /**
     * The cache-related actions after local and remote updates.
     *
     * @memberof PuterJSFileSystemModule
     * @returns {void}
     */
    invalidateCache(): void;
    /**
     * Calls the cache API to get the last change timestamp from the server.
     *
     * @memberof PuterJSFileSystemModule
     * @returns {Promise<number>} The timestamp from the server
     */
    getCacheTimestamp(): Promise<number>;
    /**
     * Checks cache timestamp and purges cache if needed.
     * Only runs in GUI environment.
     *
     * @memberof PuterJSFileSystemModule
     * @returns {void}
     */
    checkCacheAndPurge(): void;
    /**
     * Starts the background task to update LAST_VALID_TS every 1 second.
     * Only runs in GUI environment.
     *
     * @memberof PuterJSFileSystemModule
     * @returns {void}
     */
    startCacheUpdateTimer(): void;
    /**
     * Stops the background cache update timer.
     *
     * @memberof PuterJSFileSystemModule
     * @returns {void}
     */
    stopCacheUpdateTimer(): void;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle, the socket plumbing, and the legacy `authToken` accessor
 * omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof PuterJSFileSystemModule,
 *     'puter' | 'authToken'
 *     | 'socket' | 'cacheUpdateTimer'
 *     | 'initializeSocket' | 'shouldUseSocketAutoUnref' | 'bindSocketEvents'
 *     | 'onAuthStateChanged' | 'invalidateCache'
 *     | 'startCacheUpdateTimer' | 'stopCacheUpdateTimer'
 * >} FSConstructor
 */
export const FS: FSConstructor;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle, the socket plumbing, and the legacy `authToken` accessor
 * omitted.
 */
export type FSConstructor = import("../../lib/types.js").OmitMembers<typeof PuterJSFileSystemModule, "puter" | "authToken" | "socket" | "cacheUpdateTimer" | "initializeSocket" | "shouldUseSocketAutoUnref" | "bindSocketEvents" | "onAuthStateChanged" | "invalidateCache" | "startCacheUpdateTimer" | "stopCacheUpdateTimer">;
import { PuterModule } from '../../lib/PuterModule.js';
import FSItem from '../FSItem.js';
