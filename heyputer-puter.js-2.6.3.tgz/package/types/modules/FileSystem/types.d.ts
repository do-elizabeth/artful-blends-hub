export type FSItem = import("../FSItem.js").FSItem;
export type RequestCallbacks<T = unknown> = import("../../lib/types.js").RequestCallbacks<T>;
/**
 * Storage space information for the current user, in bytes.
 */
export type SpaceInfo = {
    /**
     * Total storage capacity available to the user, in bytes.
     */
    capacity: number;
    /**
     * Amount of storage space used by the user, in bytes.
     */
    used: number;
};
export type CopyOptionsOwn = {
    /**
     * Path to the file or directory to copy. Required when passing options as
     * the only argument.
     */
    source?: string | undefined;
    /**
     * Path to the destination. Required when passing options as the only
     * argument.
     */
    destination?: string | undefined;
    /**
     * Whether to overwrite the destination file or directory if it already
     * exists. Defaults to `false`.
     */
    overwrite?: boolean | undefined;
    /**
     * The new name to use for the copied file or directory. Defaults to
     * `undefined`.
     */
    newName?: string | undefined;
    /**
     * Whether to deduplicate the file or directory name if it already
     * exists. Defaults to `false`.
     */
    dedupeName?: boolean | undefined;
};
/**
 * Options for the `copy` operation.
 */
export type CopyOptions = CopyOptionsOwn & RequestCallbacks<FSItem>;
export type MoveOptionsOwn = {
    /**
     * Path to the file or directory to move. Required when passing options as
     * the only argument.
     */
    source?: string | undefined;
    /**
     * Path to the destination. Required when passing options as the only
     * argument.
     */
    destination?: string | undefined;
    /**
     * Whether to overwrite the destination file or directory if it already
     * exists. Defaults to `false`.
     */
    overwrite?: boolean | undefined;
    /**
     * The new name to use for the moved file or directory. Defaults to
     * `undefined`.
     */
    newName?: string | undefined;
    /**
     * Whether to create missing parent directories. Defaults to
     * `false`.
     */
    createMissingParents?: boolean | undefined;
    newMetadata?: Record<string, unknown> | undefined;
    excludeSocketID?: string | undefined;
    original_client_socket_id?: string | undefined;
};
/**
 * Options for the `move` operation.
 */
export type MoveOptions = MoveOptionsOwn & RequestCallbacks<FSItem>;
export type MkdirOptionsOwn = {
    /**
     * The directory path to create if not specified via function parameter.
     */
    path?: string | undefined;
    /**
     * Whether to overwrite the directory if it already exists. Defaults to
     * `false`.
     */
    overwrite?: boolean | undefined;
    /**
     * Whether to deduplicate the directory name if it already exists.
     * Defaults to `false`.
     */
    dedupeName?: boolean | undefined;
    rename?: boolean | undefined;
    /**
     * Whether to create missing parent directories. Defaults to
     * `false`.
     */
    createMissingParents?: boolean | undefined;
    recursive?: boolean | undefined;
    shortcutTo?: string | undefined;
};
/**
 * Options for the `mkdir` operation.
 */
export type MkdirOptions = MkdirOptionsOwn & RequestCallbacks<FSItem>;
export type DeleteOptionsOwn = {
    /**
     * A single path or array of paths to delete. Required when
     * passing options as the only argument.
     */
    paths?: string | string[] | undefined;
    /**
     * Whether to delete the directory recursively. Defaults to `true`.
     */
    recursive?: boolean | undefined;
    /**
     * Whether to delete only the descendants of the directory and not
     * the directory itself. Defaults to `false`.
     */
    descendantsOnly?: boolean | undefined;
};
/**
 * Options for the `delete` operation.
 */
export type DeleteOptions = DeleteOptionsOwn & RequestCallbacks<void>;
export type ReadOptionsOwn = {
    /**
     * Path to the file to read. Required when passing options as the only
     * argument.
     */
    path?: string | undefined;
    /**
     * The offset to start reading from.
     */
    offset?: number | undefined;
    /**
     * The number of bytes to read from the offset. Required if `offset` is
     * provided.
     */
    byte_count?: number | undefined;
};
/**
 * Options for the `read` operation.
 */
export type ReadOptions = ReadOptionsOwn & RequestCallbacks<Blob>;
export type ReaddirOptionsOwn = {
    /**
     * The path to the directory to read. Required when passing options as the
     * only argument.
     */
    path?: string | undefined;
    /**
     * The UID of the directory to read.
     */
    uid?: string | undefined;
    no_thumbs?: boolean | undefined;
    no_assocs?: boolean | undefined;
    consistency?: "strong" | "eventual" | undefined;
    /**
     * Maximum number of entries to return.
     */
    limit?: number | undefined;
    /**
     * Skips the given number of entries. Prefer `cursor` for paging through
     * large directories.
     */
    offset?: number | undefined;
    /**
     * Opaque continuation cursor from a previous page.
     */
    cursor?: string | null | undefined;
    /**
     * Include a `total` count of every entry across all pages.
     */
    includeTotal?: boolean | undefined;
    /**
     * Sort field. Default is `name`.
     */
    sortBy?: "name" | "modified" | "type" | "size" | undefined;
    /**
     * Sort direction. Default is `asc`.
     */
    sortOrder?: "asc" | "desc" | undefined;
    /**
     * Whether to also list the contents of subdirectories. Defaults to
     * `false`.
     */
    recursive?: boolean | undefined;
    /**
     * How many levels to descend when `recursive` is `true`. Defaults to
     * unlimited.
     */
    depth?: number | undefined;
};
/**
 * Options for the `readdir` operation.
 */
export type ReaddirOptions = ReaddirOptionsOwn & RequestCallbacks<FSItem[]>;
export type RenameOptionsOwn = {
    /**
     * The UID of the file or directory to rename. Can be used instead of `path`.
     */
    uid?: string | undefined;
    /**
     * Path to the file or directory to rename. Required when passing options as
     * the only argument.
     */
    path?: string | undefined;
    /**
     * The new name for the file or directory. Required when passing options as
     * the only argument.
     */
    newName?: string | undefined;
    excludeSocketID?: string | undefined;
    original_client_socket_id?: string | undefined;
};
/**
 * Options for the `rename` operation.
 */
export type RenameOptions = RenameOptionsOwn & RequestCallbacks<FSItem>;
export type StatOptionsOwn = {
    /**
     * Path to the file or directory. Required when passing options as the only
     * argument.
     */
    path?: string | undefined;
    /**
     * The UID of the file or directory. Can be used instead of `path`.
     */
    uid?: string | undefined;
    consistency?: "strong" | "eventual" | undefined;
    /**
     * Whether to return subdomain information. Defaults to `false`.
     */
    returnSubdomains?: boolean | undefined;
    /**
     * Whether to return the workers attached to the item. Workers are
     * served alongside subdomains, so this is an alias of `returnSubdomains` — setting either one returns
     * both. Defaults to `false`.
     */
    returnWorkers?: boolean | undefined;
    /**
     * Whether to return permission information. Defaults to `false`.
     */
    returnPermissions?: boolean | undefined;
    /**
     * Whether to return version information. Defaults to `false`.
     */
    returnVersions?: boolean | undefined;
    /**
     * Whether to return size information. Defaults to `false`.
     */
    returnSize?: boolean | undefined;
    /**
     * Whether to return who the item is shared with, as a `shares`
     * array on the result. Empty unless you can manage the item. Defaults to `false`.
     */
    returnShares?: boolean | undefined;
};
/**
 * Options for the `stat` operation.
 */
export type StatOptions = StatOptionsOwn & RequestCallbacks<FSItem>;
/**
 * What `stat()` and `readdir()` return: an item plus the sharing state only
 * those two report. `is_shared` is null for items the caller does not own.
 */
export type FSItemRead = FSItem & {
    is_shared?: boolean | null;
};
/**
 * A `stat()` result with `returnShares` set.
 */
export type FSItemWithShares = FSItemRead & {
    shares: Share[];
};
export type ThumbnailGeneratorContext = {
    /**
     * Built-in browser image generator.
     */
    defaultGenerator: (file: File) => Promise<string | undefined>;
    /**
     * Aborted when upload preparation is cancelled.
     */
    signal?: AbortSignal | undefined;
};
export type ThumbnailGenerator = (file: File, context: ThumbnailGeneratorContext) => string | undefined | Promise<string | undefined>;
export type UploadOptionsOwn = {
    /**
     * Generate browser image thumbnails before uploading. Defaults to `false`.
     */
    generateThumbnails?: boolean | undefined;
    /**
     * Overrides image generation; return `undefined` to skip.
     */
    thumbnailGenerator?: ThumbnailGenerator | undefined;
    /**
     * Thumbnail data URL or URL, used when no generated thumbnail is returned.
     */
    thumbnail?: string | undefined;
    /**
     * Whether to overwrite the destination file if it already exists.
     * Defaults to `false`.
     */
    overwrite?: boolean | undefined;
    /**
     * Whether to deduplicate the file name if it already exists. Defaults
     * to `true`. Ignored when `overwrite` is `true`.
     */
    dedupeName?: boolean | undefined;
    name?: string | undefined;
    parsedDataTransferItems?: boolean | undefined;
    createFileParent?: boolean | undefined;
    createMissingAncestors?: boolean | undefined;
    /**
     * Whether to create missing parent directories. Defaults to
     * `false`.
     */
    createMissingParents?: boolean | undefined;
    shortcutTo?: string | undefined;
    appUID?: string | undefined;
    strict?: boolean | undefined;
    init?: ((operationId: string, xhr: XMLHttpRequest) => void) | undefined;
    start?: (() => void) | undefined;
    progress?: ((operationId: string, progress: number) => void) | undefined;
    abort?: ((operationId: string) => void) | undefined;
};
/**
 * Options for the `upload` operation.
 */
export type UploadOptions = UploadOptionsOwn & RequestCallbacks<FSItem | FSItem[]>;
/**
 * One operation's outcome inside a failed upload: either a failed operation
 * (`error: true`, with its own `status`, `message`, and `code`) or the
 * `FSItem` a successful operation produced.
 */
export type UploadOperationResult = {
    error: true;
    status?: number;
    message?: string;
    code?: string;
    [key: string]: unknown;
} | FSItem;
/**
 * The rejection value of `upload()` when the batch request itself completed
 * but one or more of its operations failed.
 */
export type UploadBatchError = {
    message: string;
    /**
     * `batch_upload_failed` when nothing was written, `batch_upload_partially_failed` when only some
     * operations failed, and `batch_upload_no_results` when the server reported success without saying what
     * it wrote.
     */
    code: "batch_upload_failed" | "batch_upload_partially_failed" | "batch_upload_no_results";
    status: number;
    /**
     * Every operation's result, in the order the operations
     * were sent.
     */
    results: UploadOperationResult[];
    /**
     * Just the operations that failed.
     */
    failedItems: UploadOperationResult[];
    failedCount: number;
    totalCount: number;
};
export type WriteOptionsOwn = {
    /**
     * Whether to overwrite the file if it already exists. Defaults to
     * `true`.
     */
    overwrite?: boolean | undefined;
    /**
     * Whether to deduplicate the file name if it already exists. Defaults
     * to `false`.
     */
    dedupeName?: boolean | undefined;
    /**
     * Whether to create missing parent directories. Defaults to
     * `false`.
     */
    createMissingParents?: boolean | undefined;
    createMissingAncestors?: boolean | undefined;
    init?: ((operationId: string, xhr: XMLHttpRequest) => void) | undefined;
    start?: (() => void) | undefined;
    progress?: ((operationId: string, progress: number) => void) | undefined;
    abort?: ((operationId: string) => void) | undefined;
};
/**
 * Options for the `write` operation.
 */
export type WriteOptions = WriteOptionsOwn & RequestCallbacks<FSItem>;
/**
 * What `sign()` resolves to.
 */
export type SignResult<T = Record<string, unknown>> = {
    token: string;
    items: T | T[];
};
/**
 * Everything `upload()` accepts as its items argument.
 */
export type UploadItems = DataTransferItemList | DataTransferItem | FileList | File[] | Blob[] | Blob | File | string | unknown[];
/**
 * How much access a share grants. Stronger modes imply the weaker ones, so
 * `write` also allows reading, and `manage` — the strongest — allows
 * everything `write` does plus re-sharing the item with other people.
 */
export type ShareMode = "see" | "list" | "read" | "write" | "manage";
/**
 * Who a share is for. Give an `email` or a `username`; a bare string is read
 * as an email when it contains `@` and a username otherwise.
 *
 * A team is named by `team` (uid) or `teamHandle`, never as a bare
 * string -- that spelling already means an email or a username.
 */
export type ShareRecipient = string | {
    email?: string;
    username?: string;
    team?: string;
    teamHandle?: string;
};
/**
 * One live share.
 */
export type Share = {
    /**
     * Identifier for this share.
     */
    uid: string;
    /**
     * Access the recipient has.
     */
    mode: ShareMode;
    /**
     * Path of the shared item.
     */
    path: string;
    /**
     * UID of the shared item.
     */
    entryUid: string;
    /**
     * Whether the shared item is a directory.
     */
    isDir: boolean;
    /**
     * The item's name. Not set by `getShares()`,
     * which describes access to an item the caller already named.
     */
    name: string | null;
    /**
     * The item's content type, or `'folder'`. Only
     * set by the listings, `listShared()` and `listSharedByMe()`.
     */
    type: string | null;
    /**
     * URL of the item's thumbnail, if it has
     * one. Only set by the listings, `listShared()` and `listSharedByMe()`.
     */
    thumbnail: string | null;
    /**
     * Username of the item's owner. Only set by
     * the listings, `listShared()` and `listSharedByMe()`.
     */
    owner: string | null;
    /**
     * Username of whoever granted it.
     */
    issuer: string | null;
    /**
     * Username of whoever received it. Null for a
     * team share, which has no individual holder -- see `holderTeam`.
     */
    holder: string | null;
    /**
     * The team this was shared with, when it was shared with one.
     */
    holderTeam?: {
        uid: string;
        name: string | null;
        handle: string | null;
    } | undefined;
    /**
     * Shared ancestor this access comes from, if any.
     */
    inheritedFrom?: string | null | undefined;
    /**
     * UID of the app that asked for this
     * share, or `null` when a person made it directly.
     */
    issuedByApp?: string | null | undefined;
    /**
     * True when the recipient's email has no
     * confirmed account yet. The share is recorded but grants nothing until they
     * create an account with that address and confirm it.
     */
    pending?: boolean | undefined;
    /**
     * Address a pending share was sent
     * to. Only set when `pending`.
     */
    recipientEmail?: string | null | undefined;
    /**
     * Last-modified time of the item, unix seconds.
     */
    modified: number;
    /**
     * Size of the item in bytes; null for a directory.
     */
    size: number | null;
    /**
     * Whether the call created access that did not exist
     * before. Set by `share()` only; a listing leaves it undefined.
     */
    isNew?: boolean | undefined;
};
export type ShareOptionsOwn = {
    /**
     * Item to share. Relative paths resolve against the
     * app's root directory.
     */
    path?: string | undefined;
    /**
     * Item to share, by UID. Use instead of `path`.
     */
    uid?: string | undefined;
    /**
     * Several items to share in one call.
     */
    paths?: string[] | undefined;
    /**
     * Who to share with.
     */
    recipient?: ShareRecipient | ShareRecipient[] | undefined;
    /**
     * Alias for
     * `recipient`.
     */
    recipients?: ShareRecipient | ShareRecipient[] | undefined;
    /**
     * Access to grant. Defaults to `'read'`.
     */
    mode?: ShareMode | undefined;
};
export type ShareOptions = ShareOptionsOwn & RequestCallbacks<Share[]>;
export type UnshareOptionsOwn = {
    /**
     * Item to stop sharing.
     */
    path?: string | undefined;
    /**
     * Item to stop sharing, by UID.
     */
    uid?: string | undefined;
    /**
     * Who to withdraw access from. Pass
     * yourself to leave a share someone else granted you.
     */
    recipient?: ShareRecipient | undefined;
};
export type UnshareOptions = UnshareOptionsOwn & RequestCallbacks<{
    revoked: number;
}>;
export type ListSharedOptionsOwn = {
    /**
     * Maximum shares per page.
     */
    limit?: number | undefined;
    /**
     * Continuation token from a previous page.
     */
    cursor?: string | undefined;
    /**
     * Include the total count in the response.
     */
    includeTotal?: boolean | undefined;
};
export type ListSharedOptions = ListSharedOptionsOwn & RequestCallbacks<SharePage>;
export type ListSharedByMeOptionsOwn = {
    /**
     * Narrow to the shares one app issued in your
     * name, or `'none'` for the ones you made yourself.
     */
    appUid?: string | undefined;
};
export type ListSharedByMeOptions = ListSharedOptionsOwn & ListSharedByMeOptionsOwn & RequestCallbacks<SharePage>;
/**
 * A page of shares. `cursor` is present only while more pages remain, so
 * iterate until it is absent rather than counting items.
 */
export type SharePage = {
    items: Share[];
    cursor?: string | undefined;
    total?: number | undefined;
};
export type GetSharesOptionsOwn = {
    /**
     * Item to inspect.
     */
    path?: string | undefined;
    /**
     * Item to inspect, by UID.
     */
    uid?: string | undefined;
};
export type GetSharesOptions = GetSharesOptionsOwn & RequestCallbacks<Share[]>;
