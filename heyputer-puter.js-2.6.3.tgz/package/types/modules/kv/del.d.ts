/**
 * @overload
 * @param {string} key
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<boolean>}
 */
export function del(key: string, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<boolean>;
export type KVOptConfig = import("./types.js").KVOptConfig;
