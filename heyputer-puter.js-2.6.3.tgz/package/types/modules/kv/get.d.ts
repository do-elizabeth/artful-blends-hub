/**
 * @template [T = unknown]
 * @overload
 * @param {string} key
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<T | undefined>}
 */
export function get<T = unknown>(key: string, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<T | undefined>;
export type KVOptConfig = import("./types.js").KVOptConfig;
