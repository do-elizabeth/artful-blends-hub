/**
 * @template [T = KVScalar]
 * @overload
 * @param {string} key
 * @param {T} value
 * @param {KVOptConfig} optConfig
 * @returns {Promise<boolean>}
 */
export function set<T = unknown>(key: string, value: T, optConfig: KVOptConfig): Promise<boolean>;
/**
 * @template [T = KVScalar]
 * @overload
 * @param {string} key
 * @param {T} value
 * @param {number} [expireAt]
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<boolean>}
 */
export function set<T = unknown>(key: string, value: T, expireAt?: number | undefined, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<boolean>;
/**
 * @template [T = KVScalar]
 * @overload
 * @param {KVSetObject<T>} item
 * @returns {Promise<boolean>}
 */
export function set<T = unknown>(item: KVSetObject<T>): Promise<boolean>;
/**
 * @overload
 * @param {KVSetItem[]} items
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<boolean>}
 */
export function set(items: KVSetItem[], optConfig?: import("./types.js").KVOptConfig | undefined): Promise<boolean>;
/**
 * @overload
 * @param {KVSetBatch} batch
 * @returns {Promise<boolean>}
 */
export function set(batch: KVSetBatch): Promise<boolean>;
export type KVOptConfig = import("./types.js").KVOptConfig;
export type KVScalar = import("./types.js").KVScalar;
export type KVSetBatch<T = unknown> = import("./types.js").KVSetBatch<T>;
export type KVSetItem<T = unknown> = import("./types.js").KVSetItem<T>;
export type KVSetObject<T = unknown> = import("./types.js").KVSetObject<T>;
