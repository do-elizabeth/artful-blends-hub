/**
 * @overload
 * @param {string} key
 * @param {KVOptConfig} optConfig
 * @returns {Promise<KVValue>}
 */
export function add(key: string, optConfig: KVOptConfig): Promise<KVValue>;
/**
 * @overload
 * @param {string} key
 * @param {KVValue | KVAddPath} [value]
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<KVValue>}
 */
export function add(key: string, value?: KVValue | KVAddPath, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<KVValue>;
export type KVAddPath = import("./types.js").KVAddPath;
export type KVOptConfig = import("./types.js").KVOptConfig;
export type KVValue = import("./types.js").KVValue;
