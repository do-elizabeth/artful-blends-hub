/**
 * @overload
 * @param {string} key
 * @param {number} ttlSeconds
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<boolean>}
 */
export function expire(key: string, ttlSeconds: number, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<boolean>;
export type KVOptConfig = import("./types.js").KVOptConfig;
