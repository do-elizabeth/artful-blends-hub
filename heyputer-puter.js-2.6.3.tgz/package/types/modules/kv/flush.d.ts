/**
 * @overload
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<boolean>}
 */
export function flush(optConfig?: import("./types.js").KVOptConfig | undefined): Promise<boolean>;
export type KVOptConfig = import("./types.js").KVOptConfig;
