/**
 * @overload
 * @param {string} [pattern]
 * @param {false} [returnValues]
 * @returns {Promise<string[]>}
 */
export function list(pattern?: string | undefined, returnValues?: false | undefined): Promise<string[]>;
/**
 * @template [T = unknown]
 * @overload
 * @param {string} pattern
 * @param {true} returnValues
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<KVPair<T>[]>}
 */
export function list<T = unknown>(pattern: string, returnValues: true, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<KVPair<T>[]>;
/**
 * @template [T = unknown]
 * @overload
 * @param {true} returnValues
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<KVPair<T>[]>}
 */
export function list<T = unknown>(returnValues: true, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<KVPair<T>[]>;
/**
 * @overload
 * @param {string} pattern
 * @param {KVOptConfig} optConfig
 * @returns {Promise<string[]>}
 */
export function list(pattern: string, optConfig: KVOptConfig): Promise<string[]>;
/**
 * @overload
 * @param {KVListOptions & { stream: true, returnValues?: false }} options
 * @returns {AsyncIterableIterator<KVListPage<string>>}
 */
export function list(options: KVListOptions & {
    stream: true;
    returnValues?: false;
}): AsyncIterableIterator<KVListPage<string>>;
/**
 * @template [T = unknown]
 * @overload
 * @param {KVListOptions & { stream: true, returnValues: true }} options
 * @returns {AsyncIterableIterator<KVListPage<KVPair<T>>>}
 */
export function list<T = unknown>(options: KVListOptions & {
    stream: true;
    returnValues: true;
}): AsyncIterableIterator<KVListPage<KVPair<T>>>;
/**
 * @overload
 * @param {KVListOptions & KVListPaginationOptions & { returnValues?: false }} options
 * @returns {Promise<KVListPage<string>>}
 */
export function list(options: KVListOptions & KVListPaginationOptions & {
    returnValues?: false;
}): Promise<KVListPage<string>>;
/**
 * @template [T = unknown]
 * @overload
 * @param {KVListOptions & KVListPaginationOptions & { returnValues: true }} options
 * @returns {Promise<KVListPage<KVPair<T>>>}
 */
export function list<T = unknown>(options: KVListOptions & KVListPaginationOptions & {
    returnValues: true;
}): Promise<KVListPage<KVPair<T>>>;
/**
 * @overload
 * @param {KVListOptions & { returnValues?: false }} options
 * @returns {Promise<string[]>}
 */
export function list(options: KVListOptions & {
    returnValues?: false;
}): Promise<string[]>;
/**
 * @template [T = unknown]
 * @overload
 * @param {KVListOptions & { returnValues: true }} options
 * @returns {Promise<KVPair<T>[]>}
 */
export function list<T = unknown>(options: KVListOptions & {
    returnValues: true;
}): Promise<KVPair<T>[]>;
export type KVListOptions = import("./types.js").KVListOptions;
export type KVListPage<T = unknown> = import("./types.js").KVListPage<T>;
export type KVListPaginationOptions = import("./types.js").KVListPaginationOptions;
export type KVOptConfig = import("./types.js").KVOptConfig;
export type KVPair<T = unknown> = import("./types.js").KVPair<T>;
