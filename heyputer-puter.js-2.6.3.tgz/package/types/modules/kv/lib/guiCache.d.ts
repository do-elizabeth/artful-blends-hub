/**
 * Boot-time read cache for the GUI's well-known keys. Lazy: nothing is
 * fetched until the first `lookup()` resolves the init deferred; every read
 * within the lifetime window is then served from the one batched response.
 */
export class GuiBootCache {
    /** @param {import('../../../index.js').Puter} puter */
    constructor(puter: import("../../../index.js").Puter);
    puter: import("../../../index.js").Puter;
    batch: {
        promise: Promise<any>;
        resolve: (value?: unknown) => void;
        reject: (reason?: unknown) => void;
    };
    init: {
        promise: Promise<any>;
        resolve: (value?: unknown) => void;
        reject: (reason?: unknown) => void;
    };
    /** True when `key` is a boot key this cache can still serve. */
    serves(key: any): boolean;
    /**
     * @param {string} key
     * @returns {Promise<unknown>}
     */
    lookup(key: string): Promise<unknown>;
}
