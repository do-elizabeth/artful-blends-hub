export const MAX_KEY_SIZE: 1024;
export const MAX_VALUE_SIZE: number;
export function assertKeyPresent(key: unknown): void;
export function assertKeySize(key: unknown): void;
export function assertValueSize(value: unknown): void;
