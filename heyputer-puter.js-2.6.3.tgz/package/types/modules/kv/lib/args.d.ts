export function isObject(value: any): value is Record<string, unknown>;
export function isOptConfigShorthand(value: any): boolean;
export function isBatchSetItem(value: any): boolean;
export function parseTrailingArgs(rest: unknown[]): {
    optConfig: unknown;
    success: unknown;
    error: unknown;
};
export function parseOptConfigThenCallbacks(rest: unknown[]): {
    optConfig: Record<string, unknown>;
    success: unknown;
    error: unknown;
} | {
    success: unknown;
    error: unknown;
    optConfig?: undefined;
};
export function parseCounterArgs(keyOrOptions: unknown, amountOrMap?: unknown, optConfig?: unknown): Record<string, unknown>;
