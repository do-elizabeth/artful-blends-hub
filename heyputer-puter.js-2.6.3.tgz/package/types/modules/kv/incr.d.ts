/**
 * @overload
 * @param {string} key
 * @param {KVOptConfig} optConfig
 * @returns {Promise<number>}
 */
export function incr(key: string, optConfig: KVOptConfig): Promise<number>;
/**
 * @overload
 * @param {string} key
 * @param {number | KVIncrementPath} [amount]
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<number>}
 */
export function incr(key: string, amount?: number | import("./types.js").KVIncrementPath | undefined, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<number>;
export type KVIncrementPath = import("./types.js").KVIncrementPath;
export type KVOptConfig = import("./types.js").KVOptConfig;
