/** @typedef {import('../../index.js').Puter} Puter */
/**
 * The key-value store. Each app has its own private store within each user's
 * account; apps cannot access other apps' stores.
 *
 * Method implementations live in the sibling files as `this`-context
 * functions whose JSDoc (including the per-form `@overload` declarations) is
 * the source of truth for the public signatures — `types/` is generated from
 * it, never edited by hand.
 */
export class KVModule extends PuterModule {
    /** @type {GuiBootCache} */
    guiCache: GuiBootCache;
    /**
     * The maximum allowed key size, in bytes (`1 KB`).
     *
     * @readonly
     */
    readonly MAX_KEY_SIZE: 1024;
    /**
     * The maximum allowed value size, in bytes (`400 KB`).
     *
     * @readonly
     */
    readonly MAX_VALUE_SIZE: number;
    set: typeof set;
    get: typeof get;
    del: typeof del;
    incr: typeof incr;
    decr: typeof decr;
    add: typeof add;
    remove: typeof remove;
    update: typeof update;
    expire: typeof expire;
    expireAt: typeof expireAt;
    list: typeof list;
    flush: typeof flush;
    /** Alias of {@link flush}. */
    clear: typeof flush;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle, the GUI boot cache, and the legacy `authToken` accessor
 * omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof KVModule,
 *     'puter' | 'guiCache' | 'authToken'
 * >} KVConstructor
 */
export const KV: KVConstructor;
export type Puter = import("../../index.js").Puter;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle, the GUI boot cache, and the legacy `authToken` accessor
 * omitted.
 */
export type KVConstructor = import("../../lib/types.js").OmitMembers<typeof KVModule, "puter" | "guiCache" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { GuiBootCache } from './lib/guiCache.js';
import { set } from './set.js';
import { get } from './get.js';
import { del } from './del.js';
import { incr } from './incr.js';
import { decr } from './decr.js';
import { add } from './add.js';
import { remove } from './remove.js';
import { update } from './update.js';
import { expire } from './expire.js';
import { expireAt } from './expireAt.js';
import { list } from './list.js';
import { flush } from './flush.js';
