/**
 * @overload
 * @param {string} key
 * @param {KVUpdatePath} pathAndValueMap
 * @param {KVOptConfig} optConfig
 * @returns {Promise<KVValue>}
 */
export function update(key: string, pathAndValueMap: KVUpdatePath, optConfig: KVOptConfig): Promise<KVValue>;
/**
 * @overload
 * @param {string} key
 * @param {KVUpdatePath} pathAndValueMap
 * @param {number} [ttl]
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<KVValue>}
 */
export function update(key: string, pathAndValueMap: KVUpdatePath, ttl?: number | undefined, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<KVValue>;
/**
 * @overload
 * @param {KVUpdateObject} item
 * @returns {Promise<KVValue>}
 */
export function update(item: KVUpdateObject): Promise<KVValue>;
export type KVOptConfig = import("./types.js").KVOptConfig;
export type KVUpdateObject = import("./types.js").KVUpdateObject;
export type KVUpdatePath = import("./types.js").KVUpdatePath;
export type KVValue = import("./types.js").KVValue;
