export type KVValue = string | number | boolean | object | unknown;
export type KVScalar = KVValue | KVValue[];
/**
 * A key-value pair as returned by `list()` when `returnValues` is `true`.
 */
export type KVPair<T = unknown> = {
    /**
     * The key name.
     */
    key: string;
    /**
     * The value associated with the key. Can be of any type.
     */
    value: T;
};
/**
 * A single item in a batch `set()` operation.
 */
export type KVSetItem<T = unknown> = {
    /**
     * The key to create or update. Maximum key size is `1 KB`.
     */
    key: string;
    /**
     * The value to store. Maximum value size is `400 KB`.
     */
    value: T;
    /**
     * Timestamp, in seconds, at which the key should expire.
     */
    expireAt?: number | undefined;
};
/**
 * Object form of the arguments to `set()`.
 */
export type KVSetObject<T = unknown> = {
    /**
     * The key to create or update. Maximum key size is `1 KB`.
     */
    key: string;
    /**
     * The value to store. Maximum value size is `400 KB`.
     */
    value: T;
    /**
     * Timestamp, in seconds, at which the key should expire.
     */
    expireAt?: number | undefined;
    optConfig?: KVOptConfig | undefined;
};
/**
 * Wrapped batch form of `set()`, setting multiple items in a single request.
 */
export type KVSetBatch<T = unknown> = {
    /**
     * The key-value items to set in a single request.
     */
    items: KVSetItem<T>[];
    optConfig?: KVOptConfig | undefined;
};
/**
 * Maps a dot-separated path to a property within an object value (e.g.
 * `"user.score"`) to the amount to increment/decrement it by.
 */
export type KVIncrementPath = Record<string, number>;
/**
 * Maps each dot-separated path (e.g. `"profile.name"`) to the new value for
 * that path.
 */
export type KVUpdatePath = Record<string, KVValue>;
/**
 * Object form of the arguments to `update()`.
 */
export type KVUpdateObject = {
    /**
     * The key to update.
     */
    key: string;
    /**
     * Maps dot-separated paths to their new values.
     */
    pathAndValueMap: KVUpdatePath;
    /**
     * Time-to-live for the key, in seconds.
     */
    ttl?: number | undefined;
    optConfig?: KVOptConfig | undefined;
};
/**
 * Maps each dot-separated path (e.g. `"profile.tags"`) to the value (or values)
 * to add at that path.
 */
export type KVAddPath = Record<string, KVValue | KVValue[]>;
/**
 * Options object form of the arguments to `list()`.
 */
export type KVListOptions = {
    /**
     * Return keys in descending order. A cursor preserves its
     * direction when omitted; an explicitly conflicting direction is rejected.
     */
    reverse?: boolean | undefined;
    /**
     * Prefix-based key filter. A trailing `*` is a wildcard; both `abc` and
     * `abc*` match keys starting with `abc`. Defaults to `*`, matching all keys.
     */
    pattern?: string | undefined;
    /**
     * When `true`, results contain `KVPair` objects with `key` and
     * `value`; when `false`, results contain only keys. Defaults to `false`.
     */
    returnValues?: boolean | undefined;
    /**
     * Maximum number of items to return in a single call.
     */
    limit?: number | undefined;
    /**
     * Pagination cursor from a previous call.
     */
    cursor?: string | undefined;
    /**
     * Skips the given number of items before the page starts. Maximum `5000`,
     * and cannot be combined with `cursor`. Prefer `cursor` — requests get slower and more expensive the
     * larger the offset.
     */
    offset?: number | undefined;
    /**
     * When `true`, the result includes a `total` count of every item
     * matching the query across all pages. The count is metered and its cost grows with the store —
     * request it once (on the first page) and avoid it in hot paths; to know whether more pages exist,
     * check for `cursor` instead.
     */
    includeTotal?: boolean | undefined;
    /**
     * A page can come back with fewer than `limit` items even when
     * more exist (for example when expired keys are excluded). When `true`, the page is filled up to
     * `limit` items when possible. Requires `limit`.
     */
    fetchUntilFull?: boolean | undefined;
    optConfig?: KVOptConfig | undefined;
};
/**
 * The options that switch `list()` from a flat array to a `KVListPage`. Any
 * one of them is enough — they are the same set the runtime treats as a
 * paginated request.
 */
export type KVListPaginationOptions = {
    limit: number;
} | {
    cursor: string;
} | {
    offset: number;
} | {
    includeTotal: boolean;
} | {
    fetchUntilFull: boolean;
};
/**
 * The `stream: true` form of `list()`: returns an async iterator of
 * `KVListPage`s for `for await ... of` instead of a promise. Cannot be
 * combined with `offset`; pass `cursor` to resume from a position.
 */
export type KVListStreamOptions = {
    /**
     * Stream page envelopes as they are fetched.
     */
    stream: true;
};
/**
 * A page of paginated results from `list()` when `limit` or `cursor` is used.
 */
export type KVListPage<T = unknown> = {
    /**
     * The keys (or `KVPair` objects when `returnValues` is `true`) for this page.
     */
    items: T[];
    /**
     * Pagination cursor for the next page. Present only when there are more
     * results to fetch; pass it to the next `list()` call.
     */
    cursor?: string | undefined;
    /**
     * Total count of items matching the query across all pages. Present only
     * when the page was requested with `includeTotal`.
     */
    total?: number | undefined;
};
/**
 * Per-call configuration accepted by every `puter.kv` operation.
 */
export type KVOptConfig = {
    /**
     * Address another app's namespace instead of this app's own. Requires an
     * `app-data:<appUuid>:kv:<op>` permission, which `puter.perms.requestAppData()` asks the user for.
     */
    appUuid?: string | undefined;
    /**
     * Mark the entry private to this app: invisible and untouchable
     * to any other app the user later grants access to this namespace.
     *
     * Honoured by both forms of `set()` — one key, or a batch, where it marks every entry in the batch.
     * `set` writes the whole entry, so writing the key again without the flag makes it shareable.
     * Rejected when combined with `appUuid`, since only an entry's owner may mark it private.
     *
     * Use it for anything another app should never read, such as a cached OAuth token, since a user
     * granting access cannot see what a namespace holds.
     */
    disableSharing?: boolean | undefined;
};
