/** @typedef {import('./types.js').KVOptConfig} KVOptConfig */
/** @typedef {import('./types.js').KVValue} KVValue */
/**
 * Removes values from a key by one or more dot-separated paths (e.g.
 * `"profile.bio"`), returning the updated value. An `optConfig` object may
 * trail the paths.
 *
 * @this {import('./index.js').KVModule}
 * @param {string} key
 * @param {...(string | KVOptConfig)} pathsAndOptConfig
 * @returns {Promise<KVValue>}
 */
export function remove(this: import("./index.js").KVModule, key: string, ...pathsAndOptConfig: (string | KVOptConfig)[]): Promise<KVValue>;
export type KVOptConfig = import("./types.js").KVOptConfig;
export type KVValue = import("./types.js").KVValue;
