/**
 * @overload
 * @param {string} key
 * @param {number} timestampSeconds
 * @param {KVOptConfig} [optConfig]
 * @returns {Promise<boolean>}
 */
export function expireAt(key: string, timestampSeconds: number, optConfig?: import("./types.js").KVOptConfig | undefined): Promise<boolean>;
export type KVOptConfig = import("./types.js").KVOptConfig;
