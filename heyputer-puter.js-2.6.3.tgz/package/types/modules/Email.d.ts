/**
 * Transactional email from your app (the `puter-email` driver interface).
 *
 * Every send must be authorized by a worker: either the worker calls
 * directly (`me.puter.email.sendTransactional(...)`), or a user calls with
 * their own token and passes the worker's token as `emailAccessToken` — the
 * caller is the one billed and rate-limited. In a worker handler:
 *
 *   router.post('/notify', async ({ request, user }) => {
 *       const { to, subject, text } = await request.json();
 *       return await user.puter.email.sendTransactional({
 *           to, subject, text,
 *           emailAccessToken: me.puter.authToken,
 *           // Inline or Puter-FS attachments:
 *           attachments: [
 *               { filename, content, contentType },  // content = base64
 *               { path: '~/Documents/report.pdf' },  // streamed server-side
 *           ],
 *       });
 *   });
 *
 * Positional form: `await puter.email.sendTransactional(to, subject, body)`.
 *
 * Mail goes out from a Puter-controlled address, labelled with the app's
 * title. Every mail automatically gets an unsubscribe / report-abuse
 * footer. Unsubscribing is per app: a recipient who opts out stops hearing
 * from the app they opted out of, and still hears from the other apps the
 * same account runs. Opted-out recipients are dropped from that app's
 * future sends — they come back in the result's `suppressed` array — and a
 * send whose `to` list is entirely opted out is rejected.
 *
 * Each recipient gets a private delivery. A recipient whose delivery
 * fails comes back in the result's `failed` array (everyone else got
 * their copy — retry with just those addresses); the call only rejects
 * when no recipient could be delivered.
 *
 * `send()` is the previous name of this method and still works; it will be
 * removed once existing apps have moved to `sendTransactional()`.
 */
export class EmailModule extends PuterModule {
    /**
     * Sends one transactional email. The positional form is shorthand for a
     * plain-text body; everything else (html, cc/bcc, attachments,
     * `emailAccessToken`) goes through the options form.
     *
     * @type {EmailSendMethod}
     */
    sendTransactional: EmailSendMethod;
    /**
     * Legacy name for {@link EmailModule.sendTransactional}; same arguments,
     * same result.
     *
     * @deprecated Use `sendTransactional()`.
     * @type {EmailSendMethod}
     */
    send: EmailSendMethod;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../lib/types.js').OmitMembers<
 *     typeof EmailModule,
 *     'puter' | 'authToken'
 * >} EmailConstructor
 */
export const Email: EmailConstructor;
export default Email;
/**
 * One attachment: either inline base64 `content`, or a Puter FS reference
 * (`path`/`uid`) read server-side with the caller's — falling back to the
 * authorizing worker's — file permissions. FS references are streamed from
 * storage and never travel through the request, so prefer them for anything
 * larger than a few hundred kilobytes.
 */
export type EmailAttachment = {
    /**
     * Required with `content`; defaults to the file's name for FS refs.
     */
    filename?: string | undefined;
    /**
     * Base64 file body. Mutually exclusive with `path`/`uid`.
     */
    content?: string | undefined;
    /**
     * Puter FS path (supports `~/`). Mutually exclusive with `content`.
     */
    path?: string | undefined;
    /**
     * Puter FS entry uid. Mutually exclusive with `content`.
     */
    uid?: string | undefined;
    /**
     * MIME type of the attachment.
     */
    contentType?: string | undefined;
};
/**
 * The options form of `sendTransactional()`.
 */
export type EmailSendOptions = {
    /**
     * Recipient address(es).
     */
    to: string | string[];
    subject: string;
    /**
     * Plain-text body. At least one of `text` / `html` is required.
     */
    text?: string | undefined;
    /**
     * HTML body.
     */
    html?: string | undefined;
    cc?: string | string[] | undefined;
    bcc?: string | string[] | undefined;
    replyTo?: string | undefined;
    /**
     * A worker's auth token authorizing the send when the caller is
     * not itself a worker (inside a worker: `me.puter.authToken`). The caller stays the billed and
     * rate-limited identity.
     */
    emailAccessToken?: string | undefined;
    attachments?: EmailAttachment[] | undefined;
};
/**
 * What one `sendTransactional()` resolves to.
 */
export type EmailSendResult = {
    /**
     * First transport message id reported for this send, when available.
     */
    messageId: string | null;
    /**
     * Total charge for this send, in microcents.
     */
    cost: number;
    /**
     * Recipients omitted because they opted out of this app's mail.
     */
    suppressed: string[];
    /**
     * Recipients whose delivery attempt failed. Everyone else got their copy —
     * retry with just these addresses. A send where every delivery fails rejects instead.
     */
    failed: string[];
};
/**
 * The call shapes shared by `sendTransactional()` and its legacy alias.
 */
export type EmailSendMethod = {
    (to: string | string[], subject: string, body: string): Promise<EmailSendResult>;
    (options: EmailSendOptions): Promise<EmailSendResult>;
};
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type EmailConstructor = import("../lib/types.js").OmitMembers<typeof EmailModule, "puter" | "authToken">;
import { PuterModule } from '../lib/PuterModule.js';
