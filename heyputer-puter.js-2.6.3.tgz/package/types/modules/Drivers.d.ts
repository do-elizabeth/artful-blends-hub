/**
 * A driver interface bound to an SDK instance, as returned by
 * `puter.drivers.get()`. Calls resolve the response envelope rather than the
 * unwrapped result — see `driverCallEnvelope`.
 */
export class Driver {
    /**
     * @param {import('../index.js').Puter} puter
     * @param {string} ifaceName
     */
    constructor(puter: import("../index.js").Puter, ifaceName: string);
    puter: import("../index.js").Puter;
    iface_name: string;
    /**
     * @param {string} methodName
     * @param {Record<string, unknown>} [parameters]
     * @returns {Promise<unknown>}
     */
    call(methodName: string, parameters?: Record<string, unknown>): Promise<unknown>;
}
/**
 * The `puter.drivers` module: call driver interfaces directly.
 */
export class DriversModule {
    /** @param {import('../index.js').Puter} puter */
    constructor(puter: import("../index.js").Puter);
    puter: import("../index.js").Puter;
    drivers_: {};
    _init({ puter }: {
        puter: any;
    }): void;
    /** @returns {Promise<Record<string, unknown>>} */
    list(): Promise<Record<string, unknown>>;
    /**
     * Returns a handle for an interface. Cached per interface, so repeated
     * `get()` calls hand back the same object.
     *
     * @param {string} ifaceName
     * @returns {Promise<Driver>}
     */
    get(ifaceName: string): Promise<Driver>;
    /**
     * Calls a driver method. The interface resolves to its default
     * implementation on the backend, and a method with the same name as its
     * interface can be left out:
     *
     *   puter.drivers.call('ipgeo', { ip: '1.2.3.4' })
     *
     * is the same as:
     *
     *   puter.drivers.call('ipgeo', 'ipgeo', { ip: '1.2.3.4' })
     *
     * @param {...unknown} args `(iface, method, parameters)`, or `(iface,
     *   parameters)` for the method named after its interface.
     * @returns {Promise<unknown>}
     */
    call(...args: unknown[]): Promise<unknown>;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the driver cache omitted.
 *
 * @typedef {import('../lib/types.js').OmitMembers<
 *     typeof DriversModule,
 *     'puter' | 'drivers_' | '_init'
 * >} DriversConstructor
 */
export const Drivers: DriversConstructor;
export default Drivers;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the driver cache omitted.
 */
export type DriversConstructor = import("../lib/types.js").OmitMembers<typeof DriversModule, "puter" | "drivers_" | "_init">;
