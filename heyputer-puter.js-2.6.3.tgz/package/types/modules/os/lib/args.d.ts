export function parseCallbackOptions(args: unknown[]): {
    success?: Function;
    error?: Function;
    query?: Record<string, string>;
};
