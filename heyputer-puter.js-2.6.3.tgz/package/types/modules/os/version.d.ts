/**
 * @overload
 * @param {VersionCallbacks} [options]
 * @returns {Promise<VersionInfo>}
 */
export function version(options?: import("../../lib/types.js").RequestCallbacks<Record<string, unknown>> | undefined): Promise<VersionInfo>;
/**
 * @overload
 * @param {(value: VersionInfo) => void} success
 * @param {(reason: unknown) => void} [error]
 * @returns {Promise<VersionInfo>}
 */
export function version(success: (value: VersionInfo) => void, error?: ((reason: unknown) => void) | undefined): Promise<VersionInfo>;
export type VersionInfo = Record<string, unknown>;
export type VersionCallbacks = import("../../lib/types.js").RequestCallbacks<VersionInfo>;
