/**
 * @overload
 * @param {UserCallbacks & { query?: Record<string, string> }} [options]
 * @returns {Promise<User>}
 */
export function user(options?: (import("../../lib/types.js").RequestCallbacks<import("../Auth.js").User> & {
    query?: Record<string, string>;
}) | undefined): Promise<User>;
/**
 * @overload
 * @param {(value: User) => void} success
 * @param {(reason: unknown) => void} [error]
 * @returns {Promise<User>}
 */
export function user(success: (value: User) => void, error?: ((reason: unknown) => void) | undefined): Promise<User>;
export type User = import("../Auth.js").User;
export type UserCallbacks = import("../../lib/types.js").RequestCallbacks<User>;
