/** @typedef {import('../../index.js').Puter} Puter */
/**
 * The `puter.os` module.
 *
 * Method implementations live in the sibling files as `this`-context
 * functions whose JSDoc is the source of truth for the public signatures —
 * `types/` is generated from it, never edited by hand.
 */
export class OSModule extends PuterModule {
    user: typeof user;
    version: typeof version;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof OSModule,
 *     'puter' | 'authToken'
 * >} OSConstructor
 */
export const OS: OSConstructor;
export default OS;
export type Puter = import("../../index.js").Puter;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type OSConstructor = import("../../lib/types.js").OmitMembers<typeof OSModule, "puter" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { user } from './user.js';
import { version } from './version.js';
