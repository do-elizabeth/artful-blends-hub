/** @typedef {import('./index.js').PermsModule} PermsModule */
/** @typedef {import('../../index.js').Puter} Puter */
/** @typedef {import('./types.js').PermsAccess} PermsAccess */
/** @typedef {import('./types.js').PermsFolderName} PermsFolderName */
/**
 * Where one of the user's special folders lives. The one place the path is
 * spelled out, so a request and its matching `check` can't name it differently.
 *
 * @param {string} username
 * @param {string} folderName
 * @returns {string}
 */
export function folderPathFor(username: string, folderName: string): string;
/**
 * Whether the folder can be read already. Being able to stat it is the proof:
 * read access can also come from an ACL grant that no `fs:` permission string
 * names, so the permission tables alone would under-report it.
 *
 * @param {Puter} puter
 * @param {string} folderPath
 * @returns {Promise<boolean>}
 */
export function folderReadable(puter: Puter, folderPath: string): Promise<boolean>;
/**
 * Resolve a folder request to its path, prompting only when the access isn't
 * already held.
 *
 * @param {Puter} puter
 * @param {string} folderName
 * @param {PermsAccess} accessLevel
 * @returns {Promise<string | undefined>}
 */
export function requestFolderPath(puter: Puter, folderName: string, accessLevel: PermsAccess): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name, access })`.
 * @this {PermsModule}
 * @param {string} folderName
 * @param {PermsAccess} accessLevel
 * @returns {Promise<string | undefined>}
 */
export function requestFolder_(this: import("./index.js").PermsModule, folderName: string, accessLevel: PermsAccess): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Desktop' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestReadDesktop(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Desktop', access: 'write' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestWriteDesktop(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Documents' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestReadDocuments(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Documents', access: 'write' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestWriteDocuments(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Pictures' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestReadPictures(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Pictures', access: 'write' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestWritePictures(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Videos' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestReadVideos(this: import("./index.js").PermsModule): Promise<string | undefined>;
/**
 * @deprecated Use `request('folder', { name: 'Videos', access: 'write' })`.
 * @this {PermsModule}
 * @returns {Promise<string | undefined>}
 */
export function requestWriteVideos(this: import("./index.js").PermsModule): Promise<string | undefined>;
export type PermsModule = import("./index.js").PermsModule;
export type Puter = import("../../index.js").Puter;
export type PermsAccess = import("./types.js").PermsAccess;
export type PermsFolderName = import("./types.js").PermsFolderName;
