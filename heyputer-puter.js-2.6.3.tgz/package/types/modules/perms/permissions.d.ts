/** @typedef {import('./index.js').PermsModule} PermsModule */
/** @typedef {import('../../index.js').Puter} Puter */
/** @typedef {import('./types.js').PermsAccess} PermsAccess */
/** @typedef {import('./types.js').PermsCreateKind} PermsCreateKind */
/**
 * Ask for a raw permission string, or several under one prompt. Unsupported
 * strings are denied silently. Stays on `puter.ui`, which owns the IPC.
 *
 * @param {Puter} puter
 * @param {string[]} permissions
 * @param {PermsCreateKind} [create] - Forwarded only when set, so the message
 *   is unchanged when nothing asked to create a path.
 * @returns {Promise<boolean>}
 */
export function requestPermissions(puter: Puter, permissions: string[], create?: PermsCreateKind): Promise<boolean>;
/**
 * @deprecated Use {@link import('./request.js').request} instead.
 * @this {PermsModule}
 * @param {...unknown} args
 * @returns {Promise<boolean>}
 */
export function requestPermission(this: import("./index.js").PermsModule, ...args: unknown[]): Promise<boolean>;
/**
 * Request access to the user's email address, returning it when granted.
 *
 * @deprecated Use `request('email')`.
 * @this {PermsModule}
 * @returns {Promise<string | null | undefined>}
 */
export function requestEmail(this: import("./index.js").PermsModule): Promise<string | null | undefined>;
/**
 * @deprecated Use `request('apps')`.
 * @this {PermsModule}
 * @returns {Promise<boolean>}
 */
export function requestReadApps(this: import("./index.js").PermsModule): Promise<boolean>;
/**
 * @deprecated Use `request('apps', { access: 'write' })`.
 * @this {PermsModule}
 * @returns {Promise<boolean>}
 */
export function requestManageApps(this: import("./index.js").PermsModule): Promise<boolean>;
/**
 * @deprecated Use `request('subdomains')`.
 * @this {PermsModule}
 * @returns {Promise<boolean>}
 */
export function requestReadSubdomains(this: import("./index.js").PermsModule): Promise<boolean>;
/**
 * @deprecated Use `request('subdomains', { access: 'write' })`.
 * @this {PermsModule}
 * @returns {Promise<boolean>}
 */
export function requestManageSubdomains(this: import("./index.js").PermsModule): Promise<boolean>;
export type PermsModule = import("./index.js").PermsModule;
export type Puter = import("../../index.js").Puter;
export type PermsAccess = import("./types.js").PermsAccess;
export type PermsCreateKind = import("./types.js").PermsCreateKind;
