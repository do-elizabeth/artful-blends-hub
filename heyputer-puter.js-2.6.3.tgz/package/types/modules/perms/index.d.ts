/**
 * The `puter.perms` module.
 *
 * Method implementations live in the sibling files as `this`-context
 * functions whose JSDoc is the source of truth for the public signatures —
 * `types/` is generated from it, never edited by hand.
 */
export class PermsModule extends PuterModule {
    grantApp: typeof grantApp;
    grantAppAnyUser: typeof grantAppAnyUser;
    grantOrigin: typeof grantOrigin;
    revokeApp: typeof revokeApp;
    revokeAppAnyUser: typeof revokeAppAnyUser;
    revokeOrigin: typeof revokeOrigin;
    request: typeof request;
    check: typeof check;
    /** @deprecated Use `request('email')`. */
    requestEmail: typeof requestEmail;
    /** @deprecated Use `request('appData', { app, scopes })`. */
    requestAppData: typeof requestAppData;
    /** @deprecated Use {@link request}. */
    requestPermission: typeof requestPermission;
    /** @deprecated Use `request('folder', { name, access })`. */
    requestFolder_: typeof requestFolder_;
    /** @deprecated Use `request('folder', { name: 'Desktop' })`. */
    requestReadDesktop: typeof requestReadDesktop;
    /** @deprecated Use `request('folder', { name: 'Desktop', access: 'write' })`. */
    requestWriteDesktop: typeof requestWriteDesktop;
    /** @deprecated Use `request('folder', { name: 'Documents' })`. */
    requestReadDocuments: typeof requestReadDocuments;
    /** @deprecated Use `request('folder', { name: 'Documents', access: 'write' })`. */
    requestWriteDocuments: typeof requestWriteDocuments;
    /** @deprecated Use `request('folder', { name: 'Pictures' })`. */
    requestReadPictures: typeof requestReadPictures;
    /** @deprecated Use `request('folder', { name: 'Pictures', access: 'write' })`. */
    requestWritePictures: typeof requestWritePictures;
    /** @deprecated Use `request('folder', { name: 'Videos' })`. */
    requestReadVideos: typeof requestReadVideos;
    /** @deprecated Use `request('folder', { name: 'Videos', access: 'write' })`. */
    requestWriteVideos: typeof requestWriteVideos;
    /** @deprecated Use `request('apps')`. */
    requestReadApps: typeof requestReadApps;
    /** @deprecated Use `request('apps', { access: 'write' })`. */
    requestManageApps: typeof requestManageApps;
    /** @deprecated Use `request('subdomains')`. */
    requestReadSubdomains: typeof requestReadSubdomains;
    /** @deprecated Use `request('subdomains', { access: 'write' })`. */
    requestManageSubdomains: typeof requestManageSubdomains;
    /** @deprecated Use `request('appRootDir', { app })`. */
    requestReadAppRootDir: typeof requestReadAppRootDir;
    /** @deprecated Use `request('appRootDir', { app, access: 'write' })`. */
    requestWriteAppRootDir: typeof requestWriteAppRootDir;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof PermsModule,
 *     'puter' | 'authToken'
 * >} PermsConstructor
 */
export const Perms: PermsConstructor;
export default Perms;
export type Puter = import("../../index.js").Puter;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type PermsConstructor = import("../../lib/types.js").OmitMembers<typeof PermsModule, "puter" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { grantApp } from './grants.js';
import { grantAppAnyUser } from './grants.js';
import { grantOrigin } from './grants.js';
import { revokeApp } from './grants.js';
import { revokeAppAnyUser } from './grants.js';
import { revokeOrigin } from './grants.js';
import { request } from './request.js';
import { check } from './request.js';
import { requestEmail } from './permissions.js';
import { requestAppData } from './appData.js';
import { requestPermission } from './permissions.js';
import { requestFolder_ } from './folders.js';
import { requestReadDesktop } from './folders.js';
import { requestWriteDesktop } from './folders.js';
import { requestReadDocuments } from './folders.js';
import { requestWriteDocuments } from './folders.js';
import { requestReadPictures } from './folders.js';
import { requestWritePictures } from './folders.js';
import { requestReadVideos } from './folders.js';
import { requestWriteVideos } from './folders.js';
import { requestReadApps } from './permissions.js';
import { requestManageApps } from './permissions.js';
import { requestReadSubdomains } from './permissions.js';
import { requestManageSubdomains } from './permissions.js';
import { requestReadAppRootDir } from './appRootDir.js';
import { requestWriteAppRootDir } from './appRootDir.js';
