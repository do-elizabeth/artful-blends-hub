/**
 * @overload
 * @param {'email'} resource
 * @returns {Promise<string | null | undefined>}
 */
export function request(resource: "email"): Promise<string | null | undefined>;
/**
 * @overload
 * @param {'folder'} resource
 * @param {import('./types.js').PermsFolderRequest} details
 * @returns {Promise<string | undefined>}
 */
export function request(resource: "folder", details: import("./types.js").PermsFolderRequest): Promise<string | undefined>;
/**
 * @overload
 * @param {'apps' | 'subdomains'} resource
 * @param {import('./types.js').PermsAccessRequest} [details]
 * @returns {Promise<boolean>}
 */
export function request(resource: "apps" | "subdomains", details?: import("./types.js").PermsAccessRequest | undefined): Promise<boolean>;
/**
 * @overload
 * @param {'appData'} resource
 * @param {import('./types.js').PermsAppDataRequest} details
 * @returns {Promise<boolean>}
 */
export function request(resource: "appData", details: import("./types.js").PermsAppDataRequest): Promise<boolean>;
/**
 * @overload
 * @param {'appRootDir'} resource
 * @param {import('./types.js').PermsAppRootDirRequest} details
 * @returns {Promise<Record<string, unknown> | undefined>}
 */
export function request(resource: "appRootDir", details: import("./types.js").PermsAppRootDirRequest): Promise<Record<string, unknown> | undefined>;
/**
 * @overload
 * @param {'permission'} resource
 * @param {import('./types.js').PermsPermissionRequest} details
 * @returns {Promise<boolean>}
 */
export function request(resource: "permission", details: import("./types.js").PermsPermissionRequest): Promise<boolean>;
/**
 * @overload
 * @param {import('./types.js').PermsBatchEntry[]} requests
 * @returns {Promise<unknown[]>}
 */
export function request(requests: import("./types.js").PermsBatchEntry[]): Promise<unknown[]>;
/**
 * @overload
 * @param {string} permission
 * @returns {Promise<boolean>}
 */
export function request(permission: string): Promise<boolean>;
/**
 * @overload
 * @param {'email'} resource
 * @returns {Promise<boolean>}
 */
export function check(resource: "email"): Promise<boolean>;
/**
 * @overload
 * @param {'folder'} resource
 * @param {import('./types.js').PermsFolderRequest} details
 * @returns {Promise<boolean>}
 */
export function check(resource: "folder", details: import("./types.js").PermsFolderRequest): Promise<boolean>;
/**
 * @overload
 * @param {'apps' | 'subdomains'} resource
 * @param {import('./types.js').PermsAccessRequest} [details]
 * @returns {Promise<boolean>}
 */
export function check(resource: "apps" | "subdomains", details?: import("./types.js").PermsAccessRequest | undefined): Promise<boolean>;
/**
 * @overload
 * @param {'appData'} resource
 * @param {import('./types.js').PermsAppDataRequest} details
 * @returns {Promise<boolean>}
 */
export function check(resource: "appData", details: import("./types.js").PermsAppDataRequest): Promise<boolean>;
/**
 * @overload
 * @param {'appRootDir'} resource
 * @param {import('./types.js').PermsAppRootDirRequest} details
 * @returns {Promise<boolean>}
 */
export function check(resource: "appRootDir", details: import("./types.js").PermsAppRootDirRequest): Promise<boolean>;
/**
 * @overload
 * @param {'permission'} resource
 * @param {import('./types.js').PermsPermissionRequest} details
 * @returns {Promise<boolean>}
 */
export function check(resource: "permission", details: import("./types.js").PermsPermissionRequest): Promise<boolean>;
/**
 * @overload
 * @param {import('./types.js').PermsBatchEntry[]} requests
 * @returns {Promise<boolean[]>}
 */
export function check(requests: import("./types.js").PermsBatchEntry[]): Promise<boolean[]>;
/**
 * @overload
 * @param {string} permission
 * @returns {Promise<boolean>}
 */
export function check(permission: string): Promise<boolean>;
export type PermsModule = import("./index.js").PermsModule;
export type Puter = import("../../index.js").Puter;
export type PermsAccess = import("./types.js").PermsAccess;
export type PermsResource = import("./types.js").PermsResource;
export type PermsRequestDetails = import("./types.js").PermsRequestDetails;
/**
 * Per-call scratch space. `whoami` is cached here so a ten-entry batch fetches
 * it once, with `reread` for the one caller that needs it fresh: a grant is
 * what puts the email on it, so the copy read before the prompt doesn't carry
 * the address the prompt just released.
 */
export type PermsContext = {
    puter: Puter;
    whoami: () => Promise<Record<string, any>>;
    reread: () => Promise<Record<string, any>>;
};
/**
 * One entry's question, handed to that resource's `check` and `resolve`.
 */
export type PermsQuery = {
    ctx: PermsContext;
    details: Record<string, unknown>;
    /**
     * - What this entry needs, already resolved.
     */
    permissions: string[];
    /**
     * - Answered from
     * the call's one pooled permission read.
     */
    holds: (permissions: string[]) => Promise<boolean>;
    /**
     * - Whether this is a `request`. A resource whose
     * check would otherwise repeat work the request is about to do anyway can spend
     * the round trip once and hand the result on through `scratch`.
     */
    prompt: boolean;
    /**
     * - Per-entry, passed from `check`
     * to `resolve`.
     */
    scratch: Record<string, unknown>;
};
/**
 * Per resource: the permission strings it needs (`permissions`, which also
 * validates the details), whether they are already held (`check`), and the
 * value once held (`resolve`). `pooled: false` marks a resource whose `check`
 * asks the server itself, so its strings stay out of the pooled read.
 */
export type PermsResourceHandler = {
    permissions: (query: {
        ctx: PermsContext;
        details: Record<string, unknown>;
    }) => Promise<string[]>;
    check: (query: PermsQuery) => Promise<boolean>;
    resolve: (query: {
        ctx: PermsContext;
        details: Record<string, unknown>;
        scratch: Record<string, unknown>;
    }, held: boolean) => Promise<unknown>;
    pooled?: boolean | undefined;
};
