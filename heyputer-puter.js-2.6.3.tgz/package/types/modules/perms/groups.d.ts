/** @typedef {import('./index.js').PermsModule} PermsModule */
/** @typedef {Promise<Record<string, unknown>>} PermResult */
/**
 * Creates a new group.
 * @this {PermsModule}
 * @param {Record<string, unknown>} [metadata]
 * @param {Record<string, unknown>} [extra]
 * @returns {PermResult}
 */
export function createGroup(this: import("./index.js").PermsModule, metadata?: Record<string, unknown>, extra?: Record<string, unknown>): PermResult;
/**
 * Adds users to a group by username.
 * @this {PermsModule}
 * @param {string} uid
 * @param {string[]} usernames
 * @returns {PermResult}
 */
export function addUsersToGroup(this: import("./index.js").PermsModule, uid: string, usernames: string[]): PermResult;
/**
 * Removes users from a group by username.
 * @this {PermsModule}
 * @param {string} uid
 * @param {string[]} usernames
 * @returns {PermResult}
 */
export function removeUsersFromGroup(this: import("./index.js").PermsModule, uid: string, usernames: string[]): PermResult;
/**
 * Lists the caller's groups.
 * @this {PermsModule}
 * @returns {PermResult}
 */
export function listGroups(this: import("./index.js").PermsModule): PermResult;
export type PermsModule = import("./index.js").PermsModule;
export type PermResult = Promise<Record<string, unknown>>;
