export function emailPermission(userUuid: string): string;
export function appsPermission(userUuid: string, access: PermsAccess): string;
export function subdomainsPermission(userUuid: string, access: PermsAccess): string;
export function fsPermission(path: string, access: PermsAccess): string;
export function appRootDirPermission(appUid: string, access: PermsAccess): string;
export type PermsAccess = import("../types.js").PermsAccess;
