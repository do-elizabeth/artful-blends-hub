/**
 * Shared request helper for the grant/revoke/group endpoints. These endpoints
 * return a parsed result object (with `error: true` set on failure) rather
 * than rejecting — preserved for backward compatibility, so callers keep
 * inspecting `result.error` instead of catching.
 *
 * @param {import('../../../index.js').Puter} puter
 * @param {string} route
 * @param {Record<string, unknown>} [body] - When present the request is a POST.
 * @returns {Promise<Record<string, unknown>>}
 */
export function req(puter: import("../../../index.js").Puter, route: string, body?: Record<string, unknown>): Promise<Record<string, unknown>>;
