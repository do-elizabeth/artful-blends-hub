/** @typedef {import('../types.js').PermsAccess} PermsAccess */
/** @typedef {import('../types.js').PermsFolderName} PermsFolderName */
/** The special folders a permission can be requested for by name. */
export const FOLDER_NAMES: string[];
export function invalidArgument(message: string): PuterJSError;
export function assertAccess(accessLevel: unknown): PermsAccess;
export function assertFolderName(folderName: unknown): PermsFolderName;
export type PermsAccess = import("../types.js").PermsAccess;
export type PermsFolderName = import("../types.js").PermsFolderName;
import { PuterJSError } from '../../../lib/PuterJSError.js';
