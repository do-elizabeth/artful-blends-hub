/**
 * Which of these permissions the caller holds, without prompting. One round
 * trip however many are asked about, so a whole batch pools into one call.
 *
 * Failures are thrown, not folded into "not held": "denied" and "never ran"
 * differ, and a caller that can't tell them apart would prompt someone who has
 * already granted it.
 *
 * @param {import('../../../index.js').Puter} puter
 * @param {string[]} permissions
 * @returns {Promise<Record<string, boolean>>}
 */
export function checkPermissions(puter: import("../../../index.js").Puter, permissions: string[]): Promise<Record<string, boolean>>;
