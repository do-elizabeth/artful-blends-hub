/**
 * Build the permission strings for a request. Exported for the unit tests, which
 * assert the mapping without going near the IPC layer.
 *
 * @param {string} appUid
 * @param {{ kv?: AppDataKvScope | AppDataKvScope[], fs?: AppDataFsScope | AppDataFsScope[] }} scopes
 * @returns {string[]}
 */
export function appDataPermissions(appUid: string, scopes: {
    kv?: AppDataKvScope | AppDataKvScope[];
    fs?: AppDataFsScope | AppDataFsScope[];
}): string[];
/**
 * The permission strings a cross-app data request needs, shared with `check`.
 *
 * @param {import('../../index.js').Puter} puter
 * @param {string | { uid: string } | { name: string }} appIdentifier
 * @param {AppDataScopes} scopes
 * @returns {Promise<string[]>} The permissions to ask for, or an empty list
 * when the request names this app's own data.
 */
export function appDataRequest(puter: import("../../index.js").Puter, appIdentifier: string | {
    uid: string;
} | {
    name: string;
}, scopes: AppDataScopes): Promise<string[]>;
/**
 * Ask the user to let this app use another app's KV namespace and AppData
 * directory. Scopes take a shorthand for both stores, `store:name` pairs, or a
 * per-store object. `delete` is separate from `write` and must be asked for.
 *
 *     await puter.perms.request('appData', { app: 'contacts', scopes: 'read' });
 *
 * @this {PermsModule}
 * @param {string | { uid: string } | { name: string }} appIdentifier
 * @param {AppDataScopes} scopes
 * @returns {Promise<boolean>} `true` if the app may now use that data.
 */
export function requestAppData(this: import("./index.js").PermsModule, appIdentifier: string | {
    uid: string;
} | {
    name: string;
}, scopes: AppDataScopes): Promise<boolean>;
export type PermsModule = import("./index.js").PermsModule;
export type AppDataScopes = import("./types.js").AppDataScopes;
export type AppDataKvScope = import("./types.js").AppDataKvScope;
export type AppDataFsScope = import("./types.js").AppDataFsScope;
