/**
 * The uid out of either accepted form of app identifier.
 *
 * @param {unknown} appUidOrObject
 * @returns {string}
 */
export function appUidOf(appUidOrObject: unknown): string;
/**
 * Ask the server for the app's root directory, which it provisions on the first
 * ask. Resolves the fs item, or a result with `error: true` when the caller may
 * not claim it.
 *
 * @param {Puter} puter
 * @param {string} appUid
 * @param {PermsAccess} access
 * @returns {Promise<Record<string, unknown>>}
 */
export function statAppRootDir(puter: Puter, appUid: string, access: PermsAccess): Promise<Record<string, unknown>>;
/**
 * Whether the caller may claim that app's root directory. Uses the route's
 * read-only mode, so unlike {@link statAppRootDir} it doesn't provision the
 * directory just for being asked about it.
 *
 * A refusal is the answer, and comes back as `false`. Anything else means the
 * question couldn't be asked, which is not the same as "no", so it throws.
 *
 * @param {Puter} puter
 * @param {string} appUid
 * @param {PermsAccess} access
 * @returns {Promise<boolean>}
 */
export function checkAppRootDir(puter: Puter, appUid: string, access: PermsAccess): Promise<boolean>;
/**
 * Claim the directory, re-asking with a bounded backoff while the server still
 * refuses. A fresh grant may not have reached the permission cache yet, so the
 * first refusal after one isn't final.
 *
 * @param {Puter} puter
 * @param {string} appUid
 * @param {PermsAccess} access
 * @returns {Promise<Record<string, unknown> | undefined>} The fs item, or
 * `undefined` if the server never allowed it.
 */
export function pollAppRootDir(puter: Puter, appUid: string, access: PermsAccess): Promise<Record<string, unknown> | undefined>;
/**
 * Requests access at the given level to the root directory of one of the
 * user's apps. Tries the request first; if it fails, prompts for the
 * permission and retries (with a short backoff to ride out server-side cache
 * invalidation), returning the fs item on success or `undefined` if denied.
 *
 * @param {Puter} puter
 * @param {PermsAccess} access
 * @param {string | { uid: string }} appUidOrObject
 * @returns {Promise<Record<string, unknown> | undefined>}
 */
export function requestAppRootDirAccess(puter: Puter, access: PermsAccess, appUidOrObject: string | {
    uid: string;
}): Promise<Record<string, unknown> | undefined>;
/**
 * @deprecated Use `request('appRootDir', { app })`.
 * @this {PermsModule}
 * @param {string | { uid: string }} appUid
 * @returns {Promise<Record<string, unknown> | undefined>}
 */
export function requestReadAppRootDir(this: import("./index.js").PermsModule, appUid: string | {
    uid: string;
}): Promise<Record<string, unknown> | undefined>;
/**
 * @deprecated Use `request('appRootDir', { app, access: 'write' })`.
 * @this {PermsModule}
 * @param {string | { uid: string }} appUid
 * @returns {Promise<Record<string, unknown> | undefined>}
 */
export function requestWriteAppRootDir(this: import("./index.js").PermsModule, appUid: string | {
    uid: string;
}): Promise<Record<string, unknown> | undefined>;
export type PermsModule = import("./index.js").PermsModule;
export type Puter = import("../../index.js").Puter;
export type PermsAccess = import("./types.js").PermsAccess;
