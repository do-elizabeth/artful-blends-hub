/** @typedef {import('./index.js').PermsModule} PermsModule */
/** @typedef {Promise<Record<string, unknown>>} PermResult */
/**
 * Grants a permission to an app.
 * @this {PermsModule}
 * @param {string} appUid
 * @param {string} permission
 * @returns {PermResult}
 */
export function grantApp(this: import("./index.js").PermsModule, appUid: string, permission: string): PermResult;
/**
 * Grants a permission to an app for any user (developer grant).
 * @this {PermsModule}
 * @param {string} appUid
 * @param {string} permission
 * @returns {PermResult}
 */
export function grantAppAnyUser(this: import("./index.js").PermsModule, appUid: string, permission: string): PermResult;
/**
 * Grants a permission to an origin.
 * @this {PermsModule}
 * @param {string} origin
 * @param {string} permission
 * @returns {PermResult}
 */
export function grantOrigin(this: import("./index.js").PermsModule, origin: string, permission: string): PermResult;
/**
 * Revokes a permission from an app. `'*'` revokes every permission the user has
 * granted it, which is what uninstalling an app does.
 * @this {PermsModule}
 * @param {string} appUid
 * @param {string} permission
 * @returns {PermResult}
 */
export function revokeApp(this: import("./index.js").PermsModule, appUid: string, permission: string): PermResult;
/**
 * Revokes an app's any-user (developer) permission.
 * @this {PermsModule}
 * @param {string} appUid
 * @param {string} permission
 * @returns {PermResult}
 */
export function revokeAppAnyUser(this: import("./index.js").PermsModule, appUid: string, permission: string): PermResult;
/**
 * Revokes a permission from an origin.
 * @this {PermsModule}
 * @param {string} origin
 * @param {string} permission
 * @returns {PermResult}
 */
export function revokeOrigin(this: import("./index.js").PermsModule, origin: string, permission: string): PermResult;
export type PermsModule = import("./index.js").PermsModule;
export type PermResult = Promise<Record<string, unknown>>;
