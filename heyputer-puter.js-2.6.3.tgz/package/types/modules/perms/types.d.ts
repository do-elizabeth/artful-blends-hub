/**
 * An access level a request can ask for. `write` implies `read`.
 */
export type PermsAccess = "read" | "write";
/**
 * A special folder a `'folder'` request can name. Trash and AppData are
 * deliberately absent: nothing should ask for blanket access to either, and
 * another app's AppData is reached through `'appData'` instead.
 */
export type PermsFolderName = "Desktop" | "Documents" | "Pictures" | "Videos";
/**
 * What a `request`/`check` call is about; decides the details and the result.
 */
export type PermsResource = "email" | "folder" | "apps" | "subdomains" | "appData" | "appRootDir" | "permission";
/**
 * Details for a resource that only takes an access level — `'apps'` and
 * `'subdomains'`.
 */
export type PermsAccessRequest = {
    /**
     * - Defaults to `'read'`. `write` implies read.
     */
    access?: PermsAccess | undefined;
};
/**
 * Details for `'folder'`.
 */
export type PermsFolderRequest = {
    /**
     * - Desktop, Documents, Pictures, or Videos.
     */
    name: PermsFolderName;
    /**
     * - Defaults to `'read'`.
     */
    access?: PermsAccess | undefined;
};
/**
 * Details for `'appData'` — another app's key-value namespace and AppData files.
 */
export type PermsAppDataRequest = {
    /**
     * - The target app,
     * by uid or by registered name.
     */
    app: string | {
        uid: string;
    } | {
        name: string;
    };
    /**
     * - What this app wants to do with that data.
     */
    scopes: AppDataScopes;
};
/**
 * Details for `'appRootDir'` — the root directory of one of the user's own apps.
 */
export type PermsAppRootDirRequest = {
    /**
     * - The app, by uid or an object with one.
     */
    app: string | {
        uid: string;
    };
    /**
     * - Defaults to `'read'`.
     */
    access?: PermsAccess | undefined;
};
/**
 * What kind of entry `create` should make when its path is missing. `true`
 * picks a kind from the basename (a dot beyond one leading one means a file);
 * `'dir'`/`'file'` force it.
 */
export type PermsCreateKind = boolean | "dir" | "file";
/**
 * Details for `'permission'`, the raw-permission-string escape hatch. Several
 * at once go under a single prompt.
 */
export type PermsPermissionRequest = {
    /**
     * - One permission string.
     */
    permission?: string | undefined;
    /**
     * - Several, instead of `permission`.
     */
    permissions?: string[] | undefined;
    /**
     * - For an `fs:` permission naming a
     * missing path, create it after approval. See `puter.perms.request`.
     */
    create?: PermsCreateKind | undefined;
};
/**
 * Every details shape a `request`/`check` call accepts; the resource decides
 * which one applies — see the per-resource overloads.
 */
export type PermsRequestDetails = PermsAccessRequest | PermsFolderRequest | PermsAppDataRequest | PermsAppRootDirRequest | PermsPermissionRequest;
/**
 * One batch entry: the resource, with its own details in the same object, so
 * one array can carry entries that each take different fields.
 */
export type PermsBatchEntry = {
    resource: "email";
} | ({
    resource: "folder";
} & PermsFolderRequest) | ({
    resource: "apps" | "subdomains";
} & PermsAccessRequest) | ({
    resource: "appData";
} & PermsAppDataRequest) | ({
    resource: "appRootDir";
} & PermsAppRootDirRequest) | ({
    resource: "permission";
} & PermsPermissionRequest);
/**
 * The stores an `app-data` scope can name.
 */
export type AppDataStore = "kv" | "fs";
/**
 * The three access classes. `delete` is orthogonal to `write`: neither implies
 * the other, so an app that only adds data cannot remove any.
 */
export type AppDataClass = "read" | "write" | "delete";
/**
 * A key-value scope: an access class, or one concrete operation. Classes are
 * the coarser form — `read` covers `get`/`list`, `write` covers
 * `set`/`add`/`incr`/`decr`/`update`, and `delete` covers
 * `del`/`remove`/`expire`/`expireAt`.
 *
 * `flush` is deliberately absent — it empties a whole namespace and no scope
 * reaches it.
 */
export type AppDataKvScope = AppDataClass | "get" | "list" | "set" | "add" | "incr" | "decr" | "update" | "del" | "remove" | "expire" | "expireAt";
/**
 * A file scope. Classes only, with no per-operation form: ACL checks a mode,
 * not an operation, so there is nothing finer to name.
 */
export type AppDataFsScope = AppDataClass;
/**
 * One `'<store>:<name>'` pair, as the array form takes them.
 */
export type AppDataScopePair = `kv:${AppDataKvScope}` | `fs:${AppDataFsScope}`;
/**
 * What an `'appData'` request accepts. A bare class applies to both stores; the array
 * form spells out the store on every entry; the object form groups by store.
 * There is no bare-name array — an entry with no store would be ambiguous
 * between the two.
 */
export type AppDataScopes = AppDataClass | AppDataScopePair[] | {
    kv?: AppDataKvScope | AppDataKvScope[];
    fs?: AppDataFsScope | AppDataFsScope[];
};
