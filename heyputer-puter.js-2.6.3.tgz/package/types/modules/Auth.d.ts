/**
 * Puter user details, as returned by `getUser()`.
 *
 * @typedef {Object} User
 * @property {string} uuid Unique identifier of the user.
 * @property {string} username The user's username.
 * @property {boolean | number} [email_confirmed] Whether the user's email address has been confirmed.
 * @property {number} [actual_free_storage] The user's free storage.
 * @property {string} [app_name] The current active app.
 * @property {number} [created_ts] When the account was created, in unix seconds. Only returned to user
 * tokens — apps acting on a user's behalf do not receive it.
 * @property {Record<string, unknown>} [feature_flags]
 * @property {boolean} [hasDevAccountAccess]
 * @property {boolean} [is_temp] Whether the user's account is temporary.
 * @property {number} [last_activity_ts] The user's last active timestamp.
 * @property {boolean} [otp]
 * @property {number} [paid_storage] The amount of paid storage.
 * @property {string} [referral_code] The user's referral code.
 * @property {boolean | number} [requires_email_confirmation] Whether the user's account needs email confirmation.
 * @property {boolean} [subscribed] Whether the user is subscribed.
 */
/**
 * Information about the user's resource allowance and consumption.
 *
 * @typedef {Object} AllowanceInfo
 * @property {number} monthUsageAllowance Total resource allowance for the month.
 * @property {number} remaining The remaining allowance that can be used.
 * @property {string} [unit] 'credits' when the server already scaled every monetary field to display credits; absent for raw amounts.
 */
/**
 * Total usage for a single application.
 *
 * @typedef {Object} AppUsage
 * @property {number} count Number of Puter API calls for the application.
 * @property {number} total Total resources consumed by the application.
 */
/**
 * Usage information for a single API.
 *
 * @typedef {Object} APIUsage
 * @property {number} cost Total resource consumed by this API.
 * @property {number} count Number of times the API is called.
 * @property {number} units Units of measurement for the API (e.g. tokens for AI calls, bytes for FS
 * operations).
 */
/**
 * The user's monthly resource usage in the Puter ecosystem. Resources are
 * measured in microcents (e.g. `$0.01` = `1,000,000`).
 *
 * @typedef {Object} MonthlyUsage
 * @property {AllowanceInfo} allowanceInfo The user's resource allowance and consumption.
 * @property {Record<string, AppUsage>} appTotals Total usage by application, keyed by application id.
 * @property {Record<string, APIUsage>} usage Usage information per API, keyed by API name.
 */
/**
 * Detailed resource usage statistics for a specific application. Resources are
 * measured in microcents (e.g. `$0.01` = `1,000,000`).
 *
 * @typedef {{ total: number } & Record<string, APIUsage>} DetailedAppUsage
 */
/**
 * The result of a sign-in operation.
 *
 * @typedef {Object} SignInResult
 * @property {boolean} success Whether the sign-in operation was successful.
 * @property {string} token The authentication token.
 * @property {string} [app_uid] Unique identifier of the application.
 * @property {string} [username] Username of the user who signed in.
 * @property {string} [error] Error message if the sign-in operation failed.
 * @property {string} [msg] Additional message about the sign-in operation.
 */
/**
 * The `puter.auth` module. Most Puter methods authenticate on their own; these
 * are for apps that drive the sign-in flow themselves.
 */
export class AuthModule extends PuterModule {
    /**
     * Signs the user in, opening a popup with the appropriate authentication
     * method. Must be called from a user gesture (such as a click) — without
     * one, a consent dialog is shown first so the popup can be opened from the
     * user's click on it. Resolves once the user has signed in.
     *
     * Rejects with `{ error: 'popup_blocked' }` if the browser blocked the
     * popup, `{ error: 'auth_window_closed' }` if the user closed it, or
     * `{ error: 'not_available_in_app' }` when called from an app — an app's
     * token comes from the Puter session that launched it.
     *
     * `request_auth` asks the popup to let the user re-pick their account even
     * when this site already holds a token for them — the GUI otherwise skips
     * that prompt for a site it has seen before. Implicit auth (a `puter.*`
     * call that finds no token) sets it, which is the behaviour its own popup
     * used to carry as `?request_auth=true`.
     *
     * @type {(options?: { attempt_temp_user_creation?: boolean, request_auth?: boolean }) => Promise<SignInResult>}
     */
    signIn: (options?: {
        attempt_temp_user_creation?: boolean;
        request_auth?: boolean;
    }) => Promise<SignInResult>;
    /**
     * Whether the user is currently signed in.
     *
     * @type {() => boolean}
     */
    isSignedIn: () => boolean;
    /**
     * Returns the signed-in user's basic information. Throws
     * `{ status: 401, message: 'Unauthorized' }` when no user is signed in.
     *
     * @type {{
     *   (options?: { success?: (value: User) => void, error?: (reason: unknown) => void }): Promise<User>,
     *   (success: (value: User) => void, error?: (reason: unknown) => void): Promise<User>,
     * }}
     */
    getUser: {
        (options?: {
            success?: (value: User) => void;
            error?: (reason: unknown) => void;
        }): Promise<User>;
        (success: (value: User) => void, error?: (reason: unknown) => void): Promise<User>;
    };
    /**
     * Signs the user out of this app by discarding its auth token.
     *
     * @type {() => void}
     */
    signOut: () => void;
    /**
     * Returns the signed-in user, straight from `/whoami` with no callback
     * forms. Rejects with `{ status: 401, message: 'Unauthorized' }` when no
     * user is signed in.
     *
     * @returns {Promise<User>}
     */
    whoami(): Promise<User>;
    /**
     * The user's resource usage for the current month, scoped to the calling
     * app. Amounts are in microcents ($0.01 = 1,000,000).
     *
     * @returns {Promise<MonthlyUsage>}
     */
    getMonthlyUsage(): Promise<MonthlyUsage>;
    /**
     * Per-API usage for one app the user has accessed, scoped to the calling
     * app. Amounts are in microcents ($0.01 = 1,000,000).
     *
     * @param {string} appId
     * @returns {Promise<DetailedAppUsage>}
     */
    getDetailedAppUsage(appId: string): Promise<DetailedAppUsage>;
    /**
     * Deployment-wide usage totals. The route behind this is administrative,
     * so an ordinary app's call is rejected — it is deliberately absent from
     * the public type declarations and the docs.
     *
     * @internal
     * @returns {Promise<{ total: number } & Record<string, unknown>>}
     */
    getGlobalUsage(): Promise<{
        total: number;
    } & Record<string, unknown>>;
    #private;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../lib/types.js').OmitMembers<
 *     typeof AuthModule,
 *     'puter' | 'authToken'
 * >} AuthConstructor
 */
export const Auth: AuthConstructor;
export default Auth;
/**
 * Puter user details, as returned by `getUser()`.
 */
export type User = {
    /**
     * Unique identifier of the user.
     */
    uuid: string;
    /**
     * The user's username.
     */
    username: string;
    /**
     * Whether the user's email address has been confirmed.
     */
    email_confirmed?: number | boolean | undefined;
    /**
     * The user's free storage.
     */
    actual_free_storage?: number | undefined;
    /**
     * The current active app.
     */
    app_name?: string | undefined;
    /**
     * When the account was created, in unix seconds. Only returned to user
     * tokens — apps acting on a user's behalf do not receive it.
     */
    created_ts?: number | undefined;
    feature_flags?: Record<string, unknown> | undefined;
    hasDevAccountAccess?: boolean | undefined;
    /**
     * Whether the user's account is temporary.
     */
    is_temp?: boolean | undefined;
    /**
     * The user's last active timestamp.
     */
    last_activity_ts?: number | undefined;
    otp?: boolean | undefined;
    /**
     * The amount of paid storage.
     */
    paid_storage?: number | undefined;
    /**
     * The user's referral code.
     */
    referral_code?: string | undefined;
    /**
     * Whether the user's account needs email confirmation.
     */
    requires_email_confirmation?: number | boolean | undefined;
    /**
     * Whether the user is subscribed.
     */
    subscribed?: boolean | undefined;
};
/**
 * Information about the user's resource allowance and consumption.
 */
export type AllowanceInfo = {
    /**
     * Total resource allowance for the month.
     */
    monthUsageAllowance: number;
    /**
     * The remaining allowance that can be used.
     */
    remaining: number;
    /**
     * 'credits' when the server already scaled every monetary field to display credits; absent for raw amounts.
     */
    unit?: string | undefined;
};
/**
 * Total usage for a single application.
 */
export type AppUsage = {
    /**
     * Number of Puter API calls for the application.
     */
    count: number;
    /**
     * Total resources consumed by the application.
     */
    total: number;
};
/**
 * Usage information for a single API.
 */
export type APIUsage = {
    /**
     * Total resource consumed by this API.
     */
    cost: number;
    /**
     * Number of times the API is called.
     */
    count: number;
    /**
     * Units of measurement for the API (e.g. tokens for AI calls, bytes for FS
     * operations).
     */
    units: number;
};
/**
 * The user's monthly resource usage in the Puter ecosystem. Resources are
 * measured in microcents (e.g. `$0.01` = `1,000,000`).
 */
export type MonthlyUsage = {
    /**
     * The user's resource allowance and consumption.
     */
    allowanceInfo: AllowanceInfo;
    /**
     * Total usage by application, keyed by application id.
     */
    appTotals: Record<string, AppUsage>;
    /**
     * Usage information per API, keyed by API name.
     */
    usage: Record<string, APIUsage>;
};
/**
 * Detailed resource usage statistics for a specific application. Resources are
 * measured in microcents (e.g. `$0.01` = `1,000,000`).
 */
export type DetailedAppUsage = {
    total: number;
} & Record<string, APIUsage>;
/**
 * The result of a sign-in operation.
 */
export type SignInResult = {
    /**
     * Whether the sign-in operation was successful.
     */
    success: boolean;
    /**
     * The authentication token.
     */
    token: string;
    /**
     * Unique identifier of the application.
     */
    app_uid?: string | undefined;
    /**
     * Username of the user who signed in.
     */
    username?: string | undefined;
    /**
     * Error message if the sign-in operation failed.
     */
    error?: string | undefined;
    /**
     * Additional message about the sign-in operation.
     */
    msg?: string | undefined;
};
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type AuthConstructor = import("../lib/types.js").OmitMembers<typeof AuthModule, "puter" | "authToken">;
import { PuterModule } from '../lib/PuterModule.js';
