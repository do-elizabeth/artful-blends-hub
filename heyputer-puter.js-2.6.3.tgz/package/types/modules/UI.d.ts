/**
 * An interface for interacting with another app. Returned by the UI methods
 * that launch or connect to one; it cannot be constructed directly.
 *
 * - `postMessage(message, transfer)` sends a message to the target app.
 * - `on('message', handler)` listens for messages from it.
 * - `on('close', handler)` fires when it closes.
 *
 * @extends {EventListener<{ message: unknown, close: AppConnectionCloseEvent }>}
 */
export class AppConnection extends EventListener<{
    message: unknown;
    close: AppConnectionCloseEvent;
}> {
    static from(values: any, puter: any, { messageTarget, appInstanceID }: {
        messageTarget: any;
        appInstanceID: any;
    }): AppConnection;
    constructor(puter: any, { target, usesSDK, messageTarget, appInstanceID }: {
        target: any;
        usesSDK: any;
        messageTarget: any;
        appInstanceID: any;
    });
    /**
     * Extra information the target app supplied when the connection was
     * established. Declared here because `from()` sets it on the instance.
     *
     * @type {(Record<string, unknown> & { launchResult?: LaunchAppResult }) | undefined}
     */
    response: (Record<string, unknown> & {
        launchResult?: LaunchAppResult;
    }) | undefined;
    messageTarget: any;
    appInstanceID: any;
    targetAppInstanceID: any;
    log: any;
    /**
     * Whether the target app uses the Puter SDK. If it doesn't, messaging is
     * unavailable.
     *
     * @returns {boolean}
     */
    get usesSDK(): boolean;
    /**
     * @overload
     * @param {unknown} message
     * @returns {void}
     */
    postMessage(message: unknown): void;
    /**
     * @overload
     * @param {unknown} message
     * @param {Transferable[]} transfer
     * @returns {void}
     */
    postMessage(message: unknown, transfer: Transferable[]): void;
    /**
     * @overload
     * @param {unknown} message
     * @param {{ transfer?: Transferable[] }} options
     * @returns {void}
     */
    postMessage(message: unknown, options: {
        transfer?: Transferable[];
    }): void;
    /**
     * Attempts to close the target app. An app may close apps it launched
     * itself; without that permission, or once already closed, this does
     * nothing beyond a console warning.
     *
     * @returns {void}
     */
    close(): void;
    #private;
}
/**
 * The UI API: tools for creating rich user interfaces and interacting with the
 * Puter desktop environment, including dialogs, window management, file
 * pickers, and desktop integration.
 *
 * @extends {EventListener<{
 *     localeChanged: { language: string },
 *     themeChanged: ThemeData,
 *     connection: ConnectionEvent,
 * }>}
 */
export class UIModule extends EventListener<{
    localeChanged: {
        language: string;
    };
    themeChanged: ThemeData;
    connection: ConnectionEvent;
}> {
    constructor(puter: any, { appInstanceID, parentInstanceID }: {
        appInstanceID: any;
        parentInstanceID: any;
    });
    itemWatchCallbackFunctions: any[];
    appInstanceID: any;
    parentInstanceID: any;
    get authToken(): any;
    puter: any;
    appID: any;
    env: any;
    util: any;
    messageTarget: Window | undefined;
    mouseX: number;
    mouseY: number;
    /**
     * Registers a function to run when the window is about to close. Not
     * called when the app exits through `puter.exit()`.
     *
     * @param {() => void} callback
     * @returns {void}
     */
    onWindowClose(callback: () => void): void;
    /**
     * Registers a handler for items this app was launched with.
     *
     * @deprecated Also fires when items are dropped on the app; handle the
     * `drop` event instead.
     * @param {(items: FSItem[]) => void} callback
     * @returns {void}
     */
    onItemsOpened(callback: (items: FSItem[]) => void): void;
    /**
     * Whether the app was launched to open one or more items — by
     * double-clicking a file, the 'Open With…' menu, and so on.
     *
     * @returns {boolean}
     */
    wasLaunchedWithItems(): boolean;
    /**
     * Registers a handler called with the items the app was launched with,
     * each a file or a directory.
     *
     * @param {(items: FSItem[]) => void} callback
     * @returns {void}
     */
    onLaunchedWithItems(callback: (items: FSItem[]) => void): void;
    /**
     * Asks the desktop to walk the user through confirming their email.
     * Resolves once the dialog closes.
     *
     * @returns {Promise<unknown>}
     */
    requestEmailConfirmation(): Promise<unknown>;
    /**
     * Asks the desktop to walk the user through clearing an account
     * verification gate (a 403 `*_required` code — email confirmation, phone
     * verification, or card verification). Resolves `true` once the gate is
     * cleared, `false` otherwise.
     *
     * @internal
     * @param {string} code - The gate's error code.
     * @returns {Promise<boolean>}
     */
    requestVerificationGate(code: string): Promise<boolean>;
    /**
     * Shows an alert dialog, blocking the parent window until the user picks a
     * button. Resolves to that button's `value`, or its `label` when no value
     * is set. `callback` is vestigial and never invoked.
     *
     * @param {string} [message]
     * @param {AlertButton[]} [buttons]
     * @param {AlertOptions} [options]
     * @param {unknown} [callback] ignored
     * @returns {Promise<string>}
     */
    alert(message?: string, buttons?: AlertButton[], options?: AlertOptions, callback?: unknown): Promise<string>;
    /**
     * Opens the developer payments account page. Resolves once the desktop
     * acknowledges the request.
     *
     * @returns {Promise<unknown>}
     */
    openDevPaymentsAccount(): Promise<unknown>;
    /**
     * Resolves to the instances of this app that are currently open.
     * `callback` is vestigial and never invoked.
     *
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    instancesOpen(callback?: unknown): Promise<unknown>;
    /**
     * Shows a dialog for sharing a link to social platforms. `callback` is
     * vestigial and never invoked.
     *
     * @param {string} url
     * @param {string} [message] prefilled post text, where the platform supports it
     * @param {{ left?: number, top?: number }} [options] dialog position; both default to 0
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    socialShare(url: string, message?: string, options?: {
        left?: number;
        top?: number;
    }, callback?: unknown): Promise<unknown>;
    /**
     * Shows a prompt dialog, blocking the parent window until the user
     * responds. Resolves to the entered value, or `false` if they cancel.
     * `callback` is vestigial and never invoked.
     *
     * @param {string} [message]
     * @param {string} [placeholder]
     * @param {{ defaultValue?: string }} [options]
     * @param {unknown} [callback] ignored
     * @returns {Promise<string | false>}
     */
    prompt(message?: string, placeholder?: string, options?: {
        defaultValue?: string;
    }, callback?: unknown): Promise<string | false>;
    /**
     * Shows a desktop notification. Resolves to its uid.
     *
     * @param {NotificationOptions} [options]
     * @returns {Promise<string>}
     */
    notify(options?: NotificationOptions): Promise<string>;
    /**
     * Shows a directory picker over the user's Puter storage. Resolves to one
     * `FSItem`, or an array of them when multiple selection is allowed.
     *
     * @param {{ multiple?: boolean }} [options]
     * @param {(value: FSItem | FSItem[]) => void} [callback]
     * @returns {Promise<FSItem | FSItem[]>}
     */
    showDirectoryPicker(options?: {
        multiple?: boolean;
    }, callback?: (value: FSItem | FSItem[]) => void): Promise<FSItem | FSItem[]>;
    /**
     * Shows a file picker over the user's Puter storage. Resolves to one
     * `FSItem`, or an array of them when multiple selection is allowed. The
     * returned promise also carries `undefinedOnCancel`, which resolves to
     * `undefined` instead of staying pending when the user cancels.
     *
     * @param {{ multiple?: boolean, accept?: string }} [options]
     * @param {(value: FSItem | FSItem[]) => void} [callback]
     * @returns {Promise<FSItem | FSItem[]>}
     */
    showOpenFilePicker(options?: {
        multiple?: boolean;
        accept?: string;
    }, callback?: (value: FSItem | FSItem[]) => void): Promise<FSItem | FSItem[]>;
    /**
     * Shows a font picker. Resolves to the chosen font. Accepts either a
     * default font name or an options object. `default` is a legacy alias for
     * `defaultFont`.
     *
     * @param {string | (FontPickerOptions & { default?: string })} [options]
     * @returns {Promise<{ fontFamily: string }>}
     */
    showFontPicker(options?: string | (FontPickerOptions & {
        default?: string;
    })): Promise<{
        fontFamily: string;
    }>;
    /**
     * Shows a color picker. Resolves to the chosen color. Accepts either a
     * default color or an options object. `default` and `defaultValue` are
     * legacy aliases for `defaultColor`.
     *
     * @param {string | (ColorPickerOptions & { default?: string, defaultValue?: string })} [options]
     * @returns {Promise<string>}
     */
    showColorPicker(options?: string | (ColorPickerOptions & {
        default?: string;
        defaultValue?: string;
    })): Promise<string>;
    /**
     * Floats a page of this app in a picture-in-picture window: a small
     * always-on-top window that stays in view while the user works in other
     * windows or tabs.
     *
     * Browsers only let a top-level page open a Document Picture-in-Picture
     * window, and an app runs in an iframe, so the desktop opens it on the
     * app's behalf and loads `url` in it. The page must come from this
     * app's own origin. Inside it, the app's main frame is one of
     * `window.parent.opener.frames` — probe them in a try/catch, since the
     * others belong to other origins and throw — so the two can share
     * objects directly, a MediaStream (which postMessage cannot carry)
     * included. BroadcastChannel works between them too.
     *
     * Call it from a user gesture; browsers refuse otherwise. One window
     * per app: asking again replaces the one that is up.
     *
     * @param {{url: string, width?: number, height?: number, onClose?: () => void}} options
     *   `url` is resolved against the app's own page. `width`/`height` size
     *   the window in CSS pixels (the browser may clamp them). `onClose`
     *   runs when the window goes away other than through
     *   {@link exitPictureInPicture} — the user closing it, typically.
     * @returns {Promise<void>} resolves once the window is up. Rejects with
     *   an error named as the DOM would name it: `NotSupportedError` (no
     *   Document PiP in this browser, or not running as a desktop app),
     *   `NotAllowedError` (no user gesture), `SecurityError` (`url` is not
     *   this app's origin), `TypeError` (`url` is not a URL).
     */
    requestPictureInPicture({ url, width, height, onClose }?: {
        url: string;
        width?: number;
        height?: number;
        onClose?: () => void;
    }): Promise<void>;
    /**
     * Closes the picture-in-picture window opened with
     * {@link requestPictureInPicture}, if one is up. Its `onClose` does not
     * run for this — you asked.
     *
     * @returns {Promise<boolean>} whether there was a window to close
     */
    exitPictureInPicture(): Promise<boolean>;
    /**
     * Asks the desktop to show its upgrade flow.
     *
     * @returns {Promise<unknown>}
     */
    requestUpgrade(): Promise<unknown>;
    /**
     * Shows a picker for choosing where to save a file, and saves `content`
     * there. Resolves to the saved `FSItem`; if the user cancels, the promise
     * stays pending (use `undefinedOnCancel` on it to resolve instead).
     *
     * @param {unknown} [content] the data to write; a URL to fetch when `type` is 'url',
     *   or the path of an existing file when 'move' or 'copy'
     * @param {string} [suggestedName] name to prefill in the dialog
     * @param {'url' | 'move' | 'copy'} [type] how `content` is read; inferred as 'url' for a URL
     * @returns {Promise<FSItem>}
     */
    showSaveFilePicker(content?: unknown, suggestedName?: string, type?: "url" | "move" | "copy"): Promise<FSItem>;
    /**
     * Sets a window title. `callback` is vestigial and never invoked.
     *
     * @param {string} title
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowTitle(title: string, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Sets a window's width. Values below 200 are clamped to 200. `callback` is vestigial and never invoked.
     *
     * @param {number} width
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowWidth(width: number, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Sets a window's height. Values below 200 are clamped to 200. `callback` is vestigial and never invoked.
     *
     * @param {number} height
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowHeight(height: number, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Sets a window's width and height. Values below 200 are clamped to 200. `callback` is vestigial and never invoked.
     *
     * @param {number} width
     * @param {number} height
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowSize(width: number, height: number, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Moves a window to a position on screen. `callback` is vestigial and never invoked.
     *
     * @param {number} x
     * @param {number} y
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowPosition(x: number, y: number, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Sets a window's vertical position. `callback` is vestigial and never invoked.
     *
     * @param {number} y
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowY(y: number, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Sets a window's horizontal position. `callback` is vestigial and never invoked.
     *
     * @param {number} x
     * @param {string | WindowHandle} [window_id] the window to target; defaults to the app's main window
     * @param {unknown} [callback] ignored
     * @returns {Promise<unknown>}
     */
    setWindowX(x: number, window_id?: string | WindowHandle, callback?: unknown): Promise<unknown>;
    /**
     * Shows the app's window.
     *
     * @returns {void}
     */
    showWindow(): void;
    /**
     * Hides the app's window.
     *
     * @returns {void}
     */
    hideWindow(): void;
    /**
     * Toggles the app's window between shown and hidden.
     *
     * @returns {void}
     */
    toggleWindow(): void;
    /**
     * Installs a menubar along the top of the window.
     *
     * @param {MenubarOptions} spec
     * @returns {void}
     */
    setMenubar(spec: MenubarOptions): void;
    /**
     * Asks the user to grant a permission to this app. Inside the Puter GUI
     * the request is relayed to the desktop; on the web the permission
     * dialog is shown in a popup window on the Puter origin.
     *
     * One prompt may cover several scopes: pass `permissions` instead of
     * `permission` and the user answers for the whole list at once.
     *
     * Access already granted resolves `true` without prompting.
     *
     * @param {{ permission?: string, permissions?: string[], create?: boolean | 'dir' | 'file' }} options
     *   `create`: for an `fs:` permission naming a path that doesn't exist,
     *   create it server-side after the user approves. See `puter.perms.request`.
     * @returns {Promise<boolean>} `true` only if the permission was granted.
     * @throws {{ message: string, code: 'invalid_argument' }} if `create` is
     *   set to anything but `true`, `false`, `'dir'`, or `'file'`.
     */
    requestPermission(options: {
        permission?: string;
        permissions?: string[];
        create?: boolean | "dir" | "file";
    }): Promise<boolean>;
    /**
     * Opens a dialog the user can use to send feedback to this app's
     * developer. The message is delivered by Puter (stored and emailed to the
     * developer); it never passes through the app. Requires the developer to
     * have opted in by setting `feedbackEnabled` on the app — otherwise the
     * dialog tells the user feedback is unavailable.
     *
     * In the `app` environment the Puter desktop renders the dialog; in the
     * `web` environment a puter.com popup hosts it (signing the user in first
     * if needed). Every other environment resolves `false`.
     *
     * @returns {Promise<boolean>} `true` when the user submitted feedback,
     *   `false` when the dialog was dismissed or feedback is unavailable.
     *   Never rejects. On a cross-origin-isolated page COOP severs the
     *   popup's link to the opener, so the promise resolves `false` while
     *   the popup stays open and the user may still submit — `false` means
     *   "not confirmed", not "not sent".
     */
    showFeedbackDialog(): Promise<boolean>;
    /**
     * Greys out a menubar item so it cannot be clicked.
     *
     * @param {string} item_id
     * @returns {void}
     */
    disableMenuItem(item_id: string): void;
    /**
     * Re-enables a menubar item disabled with `disableMenuItem`.
     *
     * @param {string} item_id
     * @returns {void}
     */
    enableMenuItem(item_id: string): void;
    /**
     * Sets a menubar item's icon. Must be a `data:image` URI.
     *
     * @param {string} item_id
     * @param {string} icon
     * @returns {void}
     */
    setMenuItemIcon(item_id: string, icon: string): void;
    /**
     * Sets the icon a menubar item shows while hovered or active. Must be a
     * `data:image` URI.
     *
     * @param {string} item_id
     * @param {string} icon
     * @returns {void}
     */
    setMenuItemIconActive(item_id: string, icon: string): void;
    /**
     * Shows or clears the check mark on a menubar item.
     *
     * @param {string} item_id
     * @param {boolean} checked
     * @returns {void}
     */
    setMenuItemChecked(item_id: string, checked: boolean): void;
    /**
     * Opens a context menu at the pointer. Item actions run on click.
     *
     * @param {ContextMenuOptions} spec
     * @returns {void}
     */
    contextMenu(spec: ContextMenuOptions): void;
    /**
     * Asynchronously extracts entries from DataTransferItems, like files and directories.
     *
     * @param {DataTransferItemList} dataTransferItems - List of data transfer items from a drag-and-drop operation.
     * @param {Object} [options={}] - Optional settings.
     * @param {boolean} [options.raw=false] - Determines if the file path should be processed.
     * @returns {Promise<Array<File|FileSystemEntry>>} - A promise that resolves to an array of File or FileSystemEntry objects.
     * @throws {Error} - Throws an error if there's an EncodingError and provides information about how to solve it.
     *
     * @example
     * const items = event.dataTransfer.items;
     * const entries = await getEntriesFromDataTransferItems(items, { raw: false });
     */
    getEntriesFromDataTransferItems: (dataTransferItems: DataTransferItemList, options?: {
        raw?: boolean | undefined;
    }) => Promise<Array<File | FileSystemEntry>>;
    /**
     * Asks the user to authenticate with their Puter account. Resolves once
     * they have; rejects if they cancel. Most APIs call this for you.
     *
     * @returns {Promise<void>}
     */
    authenticateWithPuter(): Promise<void>;
    /**
     * @overload
     * @param {LaunchAppOptions} options
     * @returns {Promise<AppConnection>}
     */
    /**
     * @overload
     * @param {string} [appName]
     * @param {Record<string, unknown>} [args]
     * @param {(connection: AppConnection) => void} [callback]
     * @returns {Promise<AppConnection>}
     */
    /**
     * Opens the named app in Puter with the given arguments, or takes a single
     * options object. Resolves to a connection to the launched app.
     *
     * @param {string | LaunchAppOptions} [nameOrOptions]
     * @param {Record<string, unknown>} [args]
     * @param {(connection: AppConnection) => void} [callback]
     * @returns {Promise<AppConnection>}
     */
    launchApp: (nameOrOptions?: string | LaunchAppOptions, args?: Record<string, unknown>, callback?: (connection: AppConnection) => void) => Promise<AppConnection>;
    connectToInstance: (app_name: any) => Promise<AppConnection>;
    /**
     * The connection to the app that launched this one, or `null` when there
     * is no parent app.
     *
     * @returns {AppConnection | null}
     */
    parentApp(): AppConnection | null;
    /**
     * Creates and shows a window. Resolves to a handle whose `id` the
     * `setWindow*` methods accept. `callback` is vestigial and never invoked.
     *
     * @param {WindowOptions} [options]
     * @param {unknown} [callback] ignored
     * @returns {Promise<WindowHandle>}
     */
    createWindow(options?: WindowOptions, callback?: unknown): Promise<WindowHandle>;
    menubar(): void;
    /**
     * @overload
     * @param {'localeChanged'} eventName
     * @param {(data: { language: string }) => void} callback
     * @returns {undefined}
     */
    on(eventName: "localeChanged", callback: (data: {
        language: string;
    }) => void): undefined;
    /**
     * @overload
     * @param {'themeChanged'} eventName
     * @param {(data: ThemeData) => void} callback
     * @returns {undefined}
     */
    on(eventName: "themeChanged", callback: (data: ThemeData) => void): undefined;
    /**
     * @overload
     * @param {'connection'} eventName
     * @param {(data: ConnectionEvent) => void} callback
     * @returns {undefined}
     */
    on(eventName: "connection", callback: (data: ConnectionEvent) => void): undefined;
    /**
     * Covers the screen with a spinner overlay. Nested calls share one
     * spinner, which goes away once every caller has hidden it.
     *
     * @param {string} [html] message under the spinner; defaults to "Working..."
     * @returns {void}
     */
    showSpinner(html?: string): void;
    /**
     * Hides the spinner shown by `showSpinner`.
     *
     * @returns {void}
     */
    hideSpinner(): void;
    isWorkingActive(): boolean;
    /**
     * Gets the current language/locale code (e.g., 'en', 'fr', 'es').
     *
     * @returns {Promise<string>} A promise that resolves with the current language code.
     *
     * @example
     * const currentLang = await puter.ui.getLanguage();
     * console.log(`Current language: ${currentLang}`); // e.g., "Current language: fr"
     */
    getLanguage(): Promise<string>;
    #private;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle, the legacy `authToken` accessor, and the desktop plumbing
 * omitted.
 *
 * @typedef {import('../lib/types.js').OmitMembers<
 *     typeof UIModule,
 *     'puter' | 'authToken' | 'util' | 'messageTarget'
 *     | 'itemWatchCallbackFunctions' | 'appInstanceID' | 'parentInstanceID'
 *     | 'mouseX' | 'mouseY'
 * >} UIConstructor
 */
export const UI: UIConstructor;
export default UI;
/**
 * A button shown in an `alert()` dialog.
 */
export type AlertButton = {
    /**
     * Text displayed on the button.
     */
    label: string;
    /**
     * Value returned when this button is pressed. Defaults to `label` if not set.
     */
    value?: string | undefined;
    /**
     * Visual style of the button.
     */
    type?: "primary" | "success" | "info" | "warning" | "danger" | undefined;
};
/**
 * Options that configure an `alert()` dialog.
 */
export type AlertOptions = {
    /**
     * Visual style of the alert
     * dialog.
     */
    type?: "primary" | "success" | "info" | "warning" | "danger" | undefined;
    /**
     * Icon URL shown in the dialog body. Takes precedence over `icon`.
     */
    body_icon?: string | undefined;
    /**
     * Icon URL shown in the dialog body, used when `body_icon` is not set.
     */
    icon?: string | undefined;
};
/**
 * Options that configure a `prompt()` dialog.
 */
export type PromptOptions = {
    /**
     * Value the input is pre-filled with.
     */
    defaultValue?: string | undefined;
};
/**
 * A single item in a context menu. The string `'-'` may be used in place of an
 * item to render a separator.
 */
export type ContextMenuItem = {
    /**
     * Text displayed for the menu item.
     */
    label: string;
    /**
     * Function executed when the item is clicked. Not required for items
     * with submenus.
     */
    action?: (() => void) | undefined;
    /**
     * Icon shown next to the label. Must be a base64-encoded image data URI
     * starting with `data:image`; other strings are ignored.
     */
    icon?: string | undefined;
    /**
     * Icon shown when the item is hovered or active. Must be a
     * base64-encoded image data URI starting with `data:image`; other strings are ignored.
     */
    icon_active?: string | undefined;
    /**
     * If `true`, the item is disabled and unclickable. Defaults to `false`.
     */
    disabled?: boolean | undefined;
    /**
     * Submenu items. Specifying this creates a submenu.
     */
    items?: (ContextMenuItem | "-")[] | undefined;
};
/**
 * A handle to a window created by `createWindow()`.
 */
export type WindowHandle = {
    /**
     * Identifier of the window, usable as the `window_id` argument to the
     * `setWindow*` methods.
     */
    id: string;
};
/**
 * Identifies a window: either a window id string or a window handle returned by
 * `createWindow()`.
 */
export type WindowIdentifier = string | WindowHandle;
/**
 * Options that configure a context menu.
 */
export type ContextMenuOptions = {
    /**
     * Menu items and separators. Use the string `'-'` to insert
     * a separator.
     */
    items: (ContextMenuItem | "-")[];
    /**
     * Forces the rendered menu's color theme. Only applies when
     * running standalone (`puter.env === 'web'`); ignored inside the Puter desktop (`puter.env === 'app'`).
     * When unset, the menu follows the system color-scheme preference.
     */
    theme?: "dark" | "light" | undefined;
    /**
     * X position of the menu, in pixels. Defaults to the cursor position.
     * Standalone only, with the same caveat as `theme`.
     */
    x?: number | undefined;
    /**
     * Y position of the menu, in pixels. Defaults to the cursor position.
     * Standalone only, with the same caveat as `theme`.
     */
    y?: number | undefined;
};
/**
 * Options that configure a window created by `createWindow()`.
 */
export type WindowOptions = {
    /**
     * If `true`, the window is placed at the center of the screen.
     */
    center?: boolean | undefined;
    /**
     * Content of the window.
     */
    content?: string | undefined;
    /**
     * If `true`, the parent window is blocked until this window
     * is closed.
     */
    disable_parent_window?: boolean | undefined;
    /**
     * If `true`, the window has a head containing the icon and close,
     * minimize, and maximize buttons.
     */
    has_head?: boolean | undefined;
    /**
     * Height of the window in pixels.
     */
    height?: number | undefined;
    /**
     * If `true`, the user can resize the window.
     */
    is_resizable?: boolean | undefined;
    /**
     * If `true`, the window is represented in the taskbar.
     */
    show_in_taskbar?: boolean | undefined;
    /**
     * Title of the window.
     */
    title?: string | undefined;
    /**
     * Width of the window in pixels.
     */
    width?: number | undefined;
};
/**
 * Options that configure `launchApp()`.
 */
export type LaunchAppOptions = {
    /**
     * Name of the app to launch. If not provided, a new instance of the current
     * app is launched.
     */
    name?: string | undefined;
    /**
     * Legacy spelling of `name`.
     */
    app_name?: string | undefined;
    /**
     * Arguments to pass to the app.
     */
    args?: Record<string, unknown> | undefined;
    /**
     * Paths of existing files to open with the launched app.
     */
    file_paths?: string[] | undefined;
    /**
     * `FSItem` objects to open with the launched app.
     */
    items?: FSItem[] | undefined;
    /**
     * A pseudonym to launch the app under.
     */
    pseudonym?: string | undefined;
    /**
     * If `true`, the app starts with its window hidden, for an app
     * launched to do work rather than to be looked at. It still appears in the taskbar, so the user can
     * show it (or close it) at any time, and it can show itself with `puter.ui.showWindow()`.
     */
    background?: boolean | undefined;
    callback?: ((connection: AppConnection) => void) | undefined;
};
/**
 * Theme data delivered with the `themeChanged` event.
 */
export type ThemeData = {
    /**
     * `primaryHue` is the hue of the theme color; `primarySaturation` and `primaryLightness` are
     * percentage strings including the `%` sign; `primaryAlpha` runs from `0` to `1`; `primaryColor` is a
     * CSS color value for text.
     */
    palette: {
        primaryHue: number;
        primarySaturation: string;
        primaryLightness: string;
        primaryAlpha: number;
        primaryColor: string;
    };
};
/**
 * A single item in a menubar menu. The string `'-'` may be used in place of an
 * item to render a separator.
 */
export type MenuItem = {
    /**
     * Text displayed for the menu item.
     */
    label: string;
    id?: string | undefined;
    /**
     * Function executed when the item is clicked.
     */
    action?: (() => void) | undefined;
    /**
     * Submenu items.
     */
    items?: ("-" | MenuItem)[] | undefined;
    /**
     * URL or data URI of an icon shown next to the label.
     */
    icon?: string | undefined;
    /**
     * URL or data URI of an icon shown when the item is hovered or active.
     * Falls back to `icon` if not provided.
     */
    icon_active?: string | undefined;
    /**
     * If `true`, renders a checkmark next to the item. Use for toggleable
     * options.
     */
    checked?: boolean | undefined;
    /**
     * If `true`, the item is visible but cannot be clicked.
     */
    disabled?: boolean | undefined;
};
/**
 * Options that configure the menubar set by `setMenubar()`.
 */
export type MenubarOptions = {
    /**
     * Menu items and separators. Use the string `'-'` to insert a
     * separator.
     */
    items: (MenuItem | "-")[];
    /**
     * Forces the rendered menubar's color theme. Only applies when
     * running standalone (`puter.env === 'web'`); ignored inside the Puter desktop (`puter.env === 'app'`).
     * When unset, the menubar follows the system color-scheme preference.
     */
    theme?: "dark" | "light" | undefined;
};
/**
 * Options that configure `showOpenFilePicker()`.
 */
export type FilePickerOptions = {
    /**
     * If `true`, the user can select multiple files. Defaults to `false`.
     */
    multiple?: boolean | undefined;
    /**
     * MIME types or file extensions accepted by the picker. Defaults
     * to `*​/*`. For example `'image/*'`, or `['.jpg', '.png']`.
     */
    accept?: string | string[] | undefined;
    /**
     * Initial directory to open the picker in. Defaults to the user's Desktop.
     * The special prefix `%appdata%` resolves to the app's private appdata directory.
     */
    path?: string | undefined;
};
/**
 * Options that configure `showColorPicker()`.
 */
export type ColorPickerOptions = {
    /**
     * The color initially selected when the picker opens.
     */
    defaultColor?: string | undefined;
};
/**
 * Options that configure `showFontPicker()`.
 */
export type FontPickerOptions = {
    /**
     * The font initially selected when the picker opens.
     */
    defaultFont?: string | undefined;
};
/**
 * Options that configure `showDirectoryPicker()`.
 */
export type DirectoryPickerOptions = {
    /**
     * If `true`, the user can select multiple directories. Defaults to
     * `false`.
     */
    multiple?: boolean | undefined;
};
/**
 * Options that configure a notification shown by `notify()`.
 */
export type NotificationOptions = {
    /**
     * Title shown in the notification.
     */
    title?: string | undefined;
    /**
     * Body text shown under the title.
     */
    text?: string | undefined;
    /**
     * Icon URL or Puter icon name (for example `bell.svg`).
     */
    icon?: string | undefined;
    /**
     * Visual style used to pick a
     * default icon and accent color when no `icon` is provided.
     */
    type?: "error" | "success" | "info" | "warning" | "default" | undefined;
    /**
     * Time in milliseconds before the notification auto-dismisses. Defaults
     * to `5000`; set to `0` to keep it until dismissed.
     */
    duration?: number | undefined;
    /**
     * If `true`, renders the icon as a circle.
     */
    round_icon?: boolean | undefined;
    /**
     * Alias for `round_icon`.
     */
    roundIcon?: boolean | undefined;
    /**
     * Optional ID to associate with the notification.
     */
    uid?: string | undefined;
    /**
     * Optional value stored on the notification element.
     */
    value?: unknown;
};
/**
 * Data passed to the `close` handler on an `AppConnection`.
 */
export type AppConnectionCloseEvent = {
    /**
     * Instance ID of the app that closed.
     */
    appInstanceID: string;
    statusCode?: number | undefined;
};
/**
 * Data passed to the `connection` event handler when another app requests a
 * connection to your app.
 */
export type ConnectionEvent = {
    /**
     * Connection to the app that initiated the request.
     */
    conn: AppConnection;
    /**
     * Call `accept(value)` to accept the connection; `value`
     * is sent back to the requester.
     */
    accept: (value?: unknown) => void;
    /**
     * Call `reject(value)` to reject the connection; `value`
     * is sent back to the requester.
     */
    reject: (value?: unknown) => void;
};
/**
 * The outcome the desktop reports back from a `launchApp()` request.
 */
export type LaunchAppResult = {
    launched: boolean;
    requestedAppName?: string | null | undefined;
    openedAppName?: string | null | undefined;
    appInstanceID?: string | null | undefined;
    appUid?: string | null | undefined;
    redirectedToFallback?: boolean | undefined;
    deniedPrivateAccess?: boolean | undefined;
    privateAccess?: {
        hasAccess: boolean;
        fallbackAppName?: string;
        fallbackArgs?: Record<string, unknown>;
        reason?: string;
    } | undefined;
};
/**
 * A promise from a picker that also exposes `undefinedOnCancel`, which
 * resolves to `undefined` instead of staying pending when the user cancels.
 */
export type CancelAwarePromise<T> = Promise<T> & {
    undefinedOnCancel?: Promise<T | undefined>;
};
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle, the legacy `authToken` accessor, and the desktop plumbing
 * omitted.
 */
export type UIConstructor = import("../lib/types.js").OmitMembers<typeof UIModule, "puter" | "authToken" | "util" | "messageTarget" | "itemWatchCallbackFunctions" | "appInstanceID" | "parentInstanceID" | "mouseX" | "mouseY">;
import EventListener from '../lib/EventListener.js';
import FSItem from './FSItem.js';
