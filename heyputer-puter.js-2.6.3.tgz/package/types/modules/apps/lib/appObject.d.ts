export function toAppObject(raw: AppAttributes): Record<string, unknown>;
export type AppAttributes = import("../types.js").CreateAppOptions | import("../types.js").UpdateAppAttributes;
