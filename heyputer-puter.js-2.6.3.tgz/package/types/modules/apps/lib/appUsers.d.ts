export function addUserIteration(puter: Puter, app: App): App;
export function addUserIterationToApps(puter: Puter, apps: App[]): App[];
export type Puter = import("../../../index.js").Puter;
export type App = import("../types.js").App;
