export function invalidRequest(message: string): PuterJSError;
import { PuterJSError } from '../../../lib/PuterJSError.js';
