/** @typedef {import('./types.js').App} App */
/** @typedef {import('./types.js').UpdateAppAttributes} UpdateAppAttributes */
/**
 * Updates attributes of the app with the given name.
 *
 * @this {import('./index.js').AppsModule}
 * @param {string} name
 * @param {UpdateAppAttributes} attributes
 * @returns {Promise<App>}
 */
export function update(this: import("./index.js").AppsModule, name: string, attributes: UpdateAppAttributes): Promise<App>;
export type App = import("./types.js").App;
export type UpdateAppAttributes = import("./types.js").UpdateAppAttributes;
