/**
 * @overload
 * @param {string} name
 * @param {string} indexURL
 * @param {string} [title]
 * @returns {Promise<CreateAppResult>}
 */
export function create(name: string, indexURL: string, title?: string | undefined): Promise<CreateAppResult>;
/**
 * @overload
 * @param {CreateAppOptions} options
 * @returns {Promise<CreateAppResult>}
 */
export function create(options: CreateAppOptions): Promise<CreateAppResult>;
export type CreateAppOptions = import("./types.js").CreateAppOptions;
export type CreateAppResult = import("./types.js").CreateAppResult;
