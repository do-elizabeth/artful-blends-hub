/**
 * @overload
 * @param {AppListOptions & import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<import('../../lib/types.js').ListPage<App>>}
 */
export function list(options: AppListOptions & import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<import("../../lib/types.js").ListPage<App>>;
/**
 * @overload
 * @param {AppListOptions & import('../../lib/types.js').ListPaginationOptions & ({ cursor: string | null } | { offset: number } | { includeTotal: true })} options
 * @returns {Promise<import('../../lib/types.js').ListPage<App>>}
 */
export function list(options: AppListOptions & import("../../lib/types.js").ListPaginationOptions & ({
    cursor: string | null;
} | {
    offset: number;
} | {
    includeTotal: true;
})): Promise<import("../../lib/types.js").ListPage<App>>;
/**
 * @overload
 * @param {AppListOptions & { limit?: number }} [options]
 * @returns {Promise<App[]>}
 */
export function list(options?: (import("./types.js").AppListOptions & {
    limit?: number;
}) | undefined): Promise<App[]>;
export type App = import("./types.js").App;
export type AppListOptions = import("./types.js").AppListOptions;
