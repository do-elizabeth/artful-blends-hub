/**
 * Deletes the app with the given name. Resolves to `{ success: true, uid }`
 * with the `uid` of the deleted app.
 *
 * @this {import('./index.js').AppsModule}
 * @param {string} name
 * @returns {Promise<{ success: boolean, uid: string }>}
 */
export function del(this: import("./index.js").AppsModule, name: string): Promise<{
    success: boolean;
    uid: string;
}>;
