/** @typedef {import('../../index.js').Puter} Puter */
/**
 * The `puter.apps` module.
 *
 * Method implementations live in the sibling files as `this`-context
 * functions whose JSDoc (including the per-form `@overload` declarations) is
 * the source of truth for the public signatures — `types/` is generated from
 * it, never edited by hand.
 */
export class AppsModule extends PuterModule {
    list: typeof list;
    create: typeof create;
    update: typeof update;
    get: typeof get;
    delete: typeof del;
    checkName: typeof checkName;
    getDeveloperProfile: typeof getDeveloperProfile;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof AppsModule,
 *     'puter' | 'authToken'
 * >} AppsConstructor
 */
export const Apps: AppsConstructor;
export default Apps;
export type Puter = import("../../index.js").Puter;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type AppsConstructor = import("../../lib/types.js").OmitMembers<typeof AppsModule, "puter" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { list } from './list.js';
import { create } from './create.js';
import { update } from './update.js';
import { get } from './get.js';
import { del } from './delete.js';
import { checkName } from './checkName.js';
import { getDeveloperProfile } from './getDeveloperProfile.js';
