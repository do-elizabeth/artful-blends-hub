/**
 * @overload
 * @param {ProfileCallbacks} [options]
 * @returns {Promise<DeveloperProfile>}
 */
export function getDeveloperProfile(options?: import("../../lib/types.js").RequestCallbacks<Record<string, unknown>> | undefined): Promise<DeveloperProfile>;
/**
 * @overload
 * @param {(value: DeveloperProfile) => void} success
 * @param {(reason: unknown) => void} [error]
 * @returns {Promise<DeveloperProfile>}
 */
export function getDeveloperProfile(success: (value: DeveloperProfile) => void, error?: ((reason: unknown) => void) | undefined): Promise<DeveloperProfile>;
export type DeveloperProfile = Record<string, unknown>;
export type ProfileCallbacks = import("../../lib/types.js").RequestCallbacks<DeveloperProfile>;
