/** @typedef {import('./types.js').App} App */
/** @typedef {import('./types.js').AppListOptions} AppListOptions */
/**
 * Returns the app with the given name. Rejects if the app does not exist.
 * The options object (`stats_period`, `icon_size`) may be passed as the second
 * argument, or as the sole argument.
 *
 * @this {import('./index.js').AppsModule}
 * @param {string | AppListOptions} nameOrOptions
 * @param {AppListOptions} [options]
 * @returns {Promise<App>}
 */
export function get(this: import("./index.js").AppsModule, nameOrOptions: string | AppListOptions, options?: AppListOptions): Promise<App>;
export type App = import("./types.js").App;
export type AppListOptions = import("./types.js").AppListOptions;
