/** @typedef {import('./types.js').CheckAppNameResult} CheckAppNameResult */
/**
 * Checks whether an app name is available to the user.
 *
 * @this {import('./index.js').AppsModule}
 * @param {string} name
 * @returns {Promise<CheckAppNameResult>}
 */
export function checkName(this: import("./index.js").AppsModule, name: string): Promise<CheckAppNameResult>;
export type CheckAppNameResult = import("./types.js").CheckAppNameResult;
