export namespace wispInfo {
    let server: string;
    let handler: undefined;
}
/** @typedef {import('./types.js').SocketEvent} SocketEvent */
/**
 * The payload each socket event carries.
 *
 * @typedef {Object} PSocketEventMap
 * @property {void} open Fires when the socket is initialized and ready to send data.
 * @property {Uint8Array} data Fires when the remote server sends data over the socket.
 * @property {Error} error Fires when the socket hits an error; a `close` follows shortly after. The
 * human-readable reason is on `error.message`.
 * @property {boolean} close Fires when the socket is closed. `true` if it closed due to an error.
 * @property {void} drain Fires when the write buffer has been flushed.
 * @property {Uint8Array} tlsdata The `PTLSSocket` spelling of `data`.
 * @property {void} tlsopen The `PTLSSocket` spelling of `open`.
 * @property {boolean} tlsclose The `PTLSSocket` spelling of `close`.
 */
/**
 * A raw TCP socket in the browser, tunnelled over the Wisp relay. Construct it
 * with `puter.net.Socket(hostname, port)`; the connection is established
 * asynchronously, so write once `'open'` has fired.
 *
 * @extends {EventListener<PSocketEventMap>}
 */
export class PSocket extends EventListener<PSocketEventMap> {
    /**
     * @param {string} host hostname or IP address of the server to connect to
     * @param {number} port port to connect to on that server
     */
    constructor(host: string, port: number);
    _events: Map<any, any>;
    _streamID: any;
    /**
     * Registers a handler for a socket event, the same as `on`.
     *
     * @template {SocketEvent} K
     * @param {[event: K, handler: (data: PSocketEventMap[K]) => void]} args
     * @returns {void}
     */
    addListener<K extends SocketEvent>(event: K, handler: (data: PSocketEventMap[K]) => void): void;
    /**
     * Writes data to the socket, invoking `callback` once it has been handed
     * to the relay. Throws if `data` is not a string, `ArrayBuffer`, or typed
     * array.
     *
     * @param {ArrayBuffer | ArrayBufferView | string} data
     * @param {() => void} [callback]
     * @returns {void}
     */
    write(data: ArrayBuffer | ArrayBufferView | string, callback?: () => void): void;
    /**
     * Closes the TCP connection.
     *
     * @returns {void}
     */
    close(): void;
}
export type SocketEvent = import("./types.js").SocketEvent;
/**
 * The payload each socket event carries.
 */
export type PSocketEventMap = {
    /**
     * Fires when the socket is initialized and ready to send data.
     */
    open: void;
    /**
     * Fires when the remote server sends data over the socket.
     */
    data: Uint8Array;
    /**
     * Fires when the socket hits an error; a `close` follows shortly after. The
     * human-readable reason is on `error.message`.
     */
    error: Error;
    /**
     * Fires when the socket is closed. `true` if it closed due to an error.
     */
    close: boolean;
    /**
     * Fires when the write buffer has been flushed.
     */
    drain: void;
    /**
     * The `PTLSSocket` spelling of `data`.
     */
    tlsdata: Uint8Array;
    /**
     * The `PTLSSocket` spelling of `open`.
     */
    tlsopen: void;
    /**
     * The `PTLSSocket` spelling of `close`.
     */
    tlsclose: boolean;
};
import EventListener from '../../lib/EventListener.js';
