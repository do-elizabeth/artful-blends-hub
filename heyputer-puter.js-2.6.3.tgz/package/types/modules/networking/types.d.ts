/**
 * Names of events emitted by a socket. Plain `PSocket` uses `'open'`,
 * `'data'`, `'close'`, `'error'`; `PTLSSocket` uses the `'tls'`-prefixed
 * variants.
 */
export type SocketEvent = "open" | "data" | "error" | "close" | "drain" | "tlsdata" | "tlsopen" | "tlsclose";
/**
 * The `puter.net` networking API. Establishes network connections directly
 * from the frontend without a server or proxy, and bypasses CORS
 * restrictions.
 */
export type Networking = {
    /**
     * Mints a relay URL (server plus single-use
     * token) for speaking the Wisp v1 protocol directly.
     */
    generateWispV1URL: () => Promise<string>;
    /**
     * Constructor for a raw TCP `Socket`.
     */
    Socket: typeof import("./PSocket.js").PSocket;
    /**
     * Constructor for a
     * TLS-protected `TLSSocket`.
     */
    tls: {
        TLSSocket: typeof import("./PTLS.js").PTLSSocket;
    };
    /**
     * Fetch an http/https resource without being bound by CORS restrictions.
     */
    fetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
};
