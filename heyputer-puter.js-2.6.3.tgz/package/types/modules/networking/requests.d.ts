export function pFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>;
