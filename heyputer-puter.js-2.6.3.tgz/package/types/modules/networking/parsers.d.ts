/**
 * @typedef {{packetType: number, streamID: number, streamType?: number, port?: number, hostname?: string, payload?: Uint8Array, reason?: number, remainingBuffer?: number}} ParsedWispPacket
 */
/**
 * Parses a wisp packet fully
 *
 * @param {Uint8Array} data
 * @returns {ParsedWispPacket} Packet Info
 */
export function parseIncomingPacket(data: Uint8Array): ParsedWispPacket;
/**
 * creates a wisp packet fully
 *
 * @param {ParsedWispPacket} instructions
 * @returns {Uint8Array} Constructed Packet
 */
export function createWispPacket(instructions: ParsedWispPacket): Uint8Array;
export const CONNECT: 1;
export const DATA: 2;
export const CONTINUE: 3;
export const CLOSE: 4;
export const INFO: 5;
export const TCP: 1;
export const UDP: 2;
export const textde: TextDecoder;
export const errors: {
    1: string;
    3: string;
    65: string;
    66: string;
    67: string;
    68: string;
    71: string;
    72: string;
    73: string;
};
export type ParsedWispPacket = {
    packetType: number;
    streamID: number;
    streamType?: number;
    port?: number;
    hostname?: string;
    payload?: Uint8Array;
    reason?: number;
    remainingBuffer?: number;
};
