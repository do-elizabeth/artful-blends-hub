/**
 * A TLS-protected TCP socket in the browser. Same interface as `PSocket`, but
 * the connection is encrypted and its events are `'tls'`-prefixed. Construct
 * it with `puter.net.tls.TLSSocket(hostname, port)`.
 */
export class PTLSSocket extends PSocket {
    /** @param {...unknown} args a `(host, port)` pair, as `PSocket` takes */
    constructor(...args: unknown[]);
    writer: any;
    /**
     * Registers a handler for a socket event. `'data'`, `'open'` and
     * `'close'` are accepted as aliases of the `tls`-prefixed events, so the
     * same handler code works against either socket type.
     *
     * @template {import('./types.js').SocketEvent} K
     * @param {K} event
     * @param {(data: import('./PSocket.js').PSocketEventMap[K]) => void} callback
     * @returns {this | undefined}
     */
    on<K extends import("./types.js").SocketEvent>(event: K, callback: (data: import("./PSocket.js").PSocketEventMap[K]) => void): this | undefined;
}
import { PSocket } from './PSocket.js';
