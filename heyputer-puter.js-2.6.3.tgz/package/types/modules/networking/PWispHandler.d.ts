export class PWispHandler {
    constructor(wispURL: any, puterAuth: any);
    _ws: any;
    _nextStreamID: number;
    _bufferMax: any;
    _ready: boolean;
    onReady: undefined;
    onError: undefined;
    streamMap: Map<any, any>;
    _fail(error: any): void;
    _continue(streamID: any): void;
    register(host: any, port: any, callbacks: any): number;
    write(streamID: any, data: any): void;
    close(streamID: any): void;
}
