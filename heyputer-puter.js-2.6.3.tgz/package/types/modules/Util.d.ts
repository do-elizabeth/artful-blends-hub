/**
 * The Util module exposes utilities within puter.js itself.
 * These utilities may be used internally by other modules.
 */
export default class Util {
    rpc: UtilRPC;
}
/**
 * The lower-level RPC interface used to talk to iframes: it swaps functions in
 * a value for callback ids so the value survives `postMessage`, and resolves
 * them back on the other side.
 */
export class UtilRPC {
    callbackManager: CallbackManager;
    /**
     * A dehydrator that replaces functions in a value with callback ids this
     * side can later resolve, so the value survives `postMessage`.
     *
     * @returns {{ dehydrate: (value: unknown) => unknown }}
     */
    getDehydrator(): {
        dehydrate: (value: unknown) => unknown;
    };
    /**
     * A hydrator that turns callback ids in a dehydrated value back into
     * functions which post to `target`.
     *
     * @param {{ target: Window | Worker | MessagePort }} config
     * @returns {{ hydrate: (value: unknown) => unknown }}
     */
    getHydrator({ target }: {
        target: Window | Worker | MessagePort;
    }): {
        hydrate: (value: unknown) => unknown;
    };
    /**
     * Registers a function under a callback id the other side can invoke.
     *
     * @param {(value: unknown) => void} resolve
     * @returns {string}
     */
    registerCallback(resolve: (value: unknown) => void): string;
    /**
     * Invokes a registered callback on `target` by id.
     *
     * @param {Window | Worker | MessagePort} target
     * @param {string} id
     * @param {...unknown} args
     * @returns {void}
     */
    send(target: Window | Worker | MessagePort, id: string, ...args: unknown[]): void;
}
import { CallbackManager } from '../lib/xdrpc.js';
