/**
 * Shows an email confirmation dialog to the user.
 * Call only when puter.env === 'web' (caller's responsibility).
 * @param {string} message - The message to display
 */
export function showEmailConfirmationDialog(message: string): void;
export default EmailConfirmationDialog;
declare class EmailConfirmationDialog extends HTMLElement {
    constructor(message: any);
    message: any;
    connectedCallback(): void;
    open(): void;
    close(): void;
}
