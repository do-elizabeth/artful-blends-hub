/** @typedef {import('../../index.js').Puter} Puter */
/**
 * `txt2speech` is callable directly and carries the engine/voice listers.
 * @typedef {typeof txt2speech & {
 *     listEngines: typeof listEngines,
 *     listVoices: typeof listVoices,
 * }} Txt2Speech
 */
/**
 * The `puter.ai` module.
 *
 * Method implementations live in the sibling files as `this`-context
 * functions whose JSDoc (including the per-form `@overload` declarations) is
 * the source of truth for the public signatures — `types/` is generated from
 * it, never edited by hand.
 */
export class AIModule extends PuterModule {
    /** @type {Txt2Speech} */
    txt2speech: Txt2Speech;
    /**
     * SDK-wide switch for response-format normalization. Left unset (the
     * default), the release-date policy applies: models released on or
     * after September 1, 2026 return the OpenAI-style shape, older models
     * keep their vendor-native shape. Set it to `true` to normalize every
     * `chat()` call regardless of release date, or `false` to disable
     * normalization for every call. A `normalize` option on an individual
     * `chat()` call overrides this in either direction.
     *
     * @type {boolean | undefined}
     */
    normalize: boolean | undefined;
    chat: typeof chat;
    img2txt: typeof img2txt;
    speech2txt: typeof speech2txt;
    speech2speech: typeof speech2speech;
    txt2img: typeof txt2img;
    txt2vid: typeof txt2vid;
    listModels: typeof listModels;
    listModelProviders: typeof listModelProviders;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof AIModule,
 *     'puter' | 'authToken'
 * >} AIConstructor
 */
export const AI: AIConstructor;
export type Puter = import("../../index.js").Puter;
/**
 * `txt2speech` is callable directly and carries the engine/voice listers.
 */
export type Txt2Speech = typeof txt2speech & {
    listEngines: typeof listEngines;
    listVoices: typeof listVoices;
};
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type AIConstructor = import("../../lib/types.js").OmitMembers<typeof AIModule, "puter" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { chat } from './chat.js';
import { img2txt } from './ocr.js';
import { speech2txt } from './stt.js';
import { speech2speech } from './sts.js';
import { txt2img } from './image.js';
import { txt2vid } from './video.js';
import { listModels } from './models.js';
import { listModelProviders } from './models.js';
import { txt2speech } from './tts.js';
import { listEngines } from './tts.js';
import { listVoices } from './tts.js';
