/**
 * @overload
 * @param {string} prompt
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(prompt: string, testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {string} prompt
 * @param {StreamingChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<AsyncIterable<ChatResponseChunk>>}
 */
export function chat(prompt: string, options: StreamingChatOptions, testMode?: boolean | undefined): Promise<AsyncIterable<ChatResponseChunk>>;
/**
 * @overload
 * @param {string} prompt
 * @param {ChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(prompt: string, options: ChatOptions, testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {string} prompt
 * @param {string | File} imageURL
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(prompt: string, imageURL: string | File, testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {string} prompt
 * @param {string[]} imageURLArray
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(prompt: string, imageURLArray: string[], testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {string} prompt
 * @param {string | File} imageURL
 * @param {StreamingChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<AsyncIterable<ChatResponseChunk>>}
 */
export function chat(prompt: string, imageURL: string | File, options: StreamingChatOptions, testMode?: boolean | undefined): Promise<AsyncIterable<ChatResponseChunk>>;
/**
 * @overload
 * @param {string} prompt
 * @param {string | File} imageURL
 * @param {ChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(prompt: string, imageURL: string | File, options: ChatOptions, testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {string} prompt
 * @param {string[]} imageURLArray
 * @param {StreamingChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<AsyncIterable<ChatResponseChunk>>}
 */
export function chat(prompt: string, imageURLArray: string[], options: StreamingChatOptions, testMode?: boolean | undefined): Promise<AsyncIterable<ChatResponseChunk>>;
/**
 * @overload
 * @param {string} prompt
 * @param {string[]} imageURLArray
 * @param {ChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(prompt: string, imageURLArray: string[], options: ChatOptions, testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {ChatMessage[]} messages
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(messages: ChatMessage[], testMode?: boolean | undefined): Promise<ChatResponse>;
/**
 * @overload
 * @param {ChatMessage[]} messages
 * @param {StreamingChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<AsyncIterable<ChatResponseChunk>>}
 */
export function chat(messages: ChatMessage[], options: StreamingChatOptions, testMode?: boolean | undefined): Promise<AsyncIterable<ChatResponseChunk>>;
/**
 * @overload
 * @param {ChatMessage[]} messages
 * @param {ChatOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<ChatResponse>}
 */
export function chat(messages: ChatMessage[], options: ChatOptions, testMode?: boolean | undefined): Promise<ChatResponse>;
export type ChatMessage = import("./types.js").ChatMessage;
export type ChatOptions = import("./types.js").ChatOptions;
export type ChatResponse = import("./types.js").ChatResponse;
export type ChatResponseChunk = import("./types.js").ChatResponseChunk;
export type StreamingChatOptions = import("./types.js").StreamingChatOptions;
