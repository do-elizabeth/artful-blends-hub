/**
 * @overload
 * @param {string} prompt
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLImageElement>}
 */
export function txt2img(prompt: string, testMode?: boolean | undefined): Promise<HTMLImageElement>;
/**
 * @overload
 * @param {string} prompt
 * @param {Txt2ImgOptions} options
 * @returns {Promise<HTMLImageElement>}
 */
export function txt2img(prompt: string, options: Txt2ImgOptions): Promise<HTMLImageElement>;
/**
 * @overload
 * @param {Txt2ImgOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLImageElement>}
 */
export function txt2img(options: Txt2ImgOptions, testMode?: boolean | undefined): Promise<HTMLImageElement>;
export type Txt2ImgOptions = import("./types.js").Txt2ImgOptions;
