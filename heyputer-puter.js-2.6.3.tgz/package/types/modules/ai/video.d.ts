/**
 * @overload
 * @param {string} prompt
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLVideoElement>}
 */
export function txt2vid(prompt: string, testMode?: boolean | undefined): Promise<HTMLVideoElement>;
/**
 * @overload
 * @param {string} prompt
 * @param {Txt2VidOptions} options
 * @returns {Promise<HTMLVideoElement>}
 */
export function txt2vid(prompt: string, options: Txt2VidOptions): Promise<HTMLVideoElement>;
/**
 * @overload
 * @param {Txt2VidOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLVideoElement>}
 */
export function txt2vid(options: Txt2VidOptions, testMode?: boolean | undefined): Promise<HTMLVideoElement>;
export type Txt2VidOptions = import("./types.js").Txt2VidOptions;
