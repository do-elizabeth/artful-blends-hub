/**
 * @overload
 * @param {string | File | Blob} source
 * @param {boolean} [testMode]
 * @returns {Promise<string>}
 */
export function img2txt(source: string | File | Blob, testMode?: boolean | undefined): Promise<string>;
/**
 * @overload
 * @param {string | File | Blob} source
 * @param {Img2TxtOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<string>}
 */
export function img2txt(source: string | File | Blob, options: Img2TxtOptions, testMode?: boolean | undefined): Promise<string>;
/**
 * @overload
 * @param {Img2TxtOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<string>}
 */
export function img2txt(options: Img2TxtOptions, testMode?: boolean | undefined): Promise<string>;
export type Img2TxtOptions = import("./types.js").Img2TxtOptions;
/**
 * The recognition result shapes the OCR drivers return.
 */
export type OcrResult = {
    blocks?: {
        type?: string;
        text?: string;
    }[];
    pages?: {
        markdown?: string;
    }[];
    document_annotation?: string;
    text?: string;
};
