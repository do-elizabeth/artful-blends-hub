/**
 * @overload
 * @param {string} [provider]
 * @returns {Promise<Record<string, unknown>[]>}
 */
export function listModels(provider?: string | undefined): Promise<Record<string, unknown>[]>;
/**
 * @overload
 * @returns {Promise<string[]>}
 */
export function listModelProviders(): Promise<string[]>;
