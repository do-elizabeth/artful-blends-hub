/**
 * @overload
 * @param {string | File | Blob} source
 * @param {boolean} [testMode]
 * @returns {Promise<Speech2TxtResult>}
 */
export function speech2txt(source: string | File | Blob, testMode?: boolean | undefined): Promise<Speech2TxtResult>;
/**
 * @overload
 * @param {string | File | Blob} source
 * @param {TextFormatSpeech2TxtOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<string>}
 */
export function speech2txt(source: string | File | Blob, options: TextFormatSpeech2TxtOptions, testMode?: boolean | undefined): Promise<string>;
/**
 * @overload
 * @param {string | File | Blob} source
 * @param {Speech2TxtOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<Speech2TxtResult>}
 */
export function speech2txt(source: string | File | Blob, options: Speech2TxtOptions, testMode?: boolean | undefined): Promise<Speech2TxtResult>;
/**
 * @overload
 * @param {TextFormatSpeech2TxtOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<string>}
 */
export function speech2txt(options: TextFormatSpeech2TxtOptions, testMode?: boolean | undefined): Promise<string>;
/**
 * @overload
 * @param {Speech2TxtOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<Speech2TxtResult>}
 */
export function speech2txt(options: Speech2TxtOptions, testMode?: boolean | undefined): Promise<Speech2TxtResult>;
export type Speech2TxtOptions = import("./types.js").Speech2TxtOptions;
export type Speech2TxtResult = import("./types.js").Speech2TxtResult;
export type TextFormatSpeech2TxtOptions = import("./types.js").TextFormatSpeech2TxtOptions;
