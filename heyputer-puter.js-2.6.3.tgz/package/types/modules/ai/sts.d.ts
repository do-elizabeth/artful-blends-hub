/**
 * @overload
 * @param {string | File | Blob} source
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function speech2speech(source: string | File | Blob, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {string | File | Blob} source
 * @param {Speech2SpeechOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function speech2speech(source: string | File | Blob, options: Speech2SpeechOptions, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {Speech2SpeechOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function speech2speech(options: Speech2SpeechOptions, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
export type Speech2SpeechOptions = import("./types.js").Speech2SpeechOptions;
