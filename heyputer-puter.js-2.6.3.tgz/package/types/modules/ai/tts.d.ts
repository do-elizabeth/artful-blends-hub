/**
 * @overload
 * @param {string} text
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function txt2speech(text: string, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {string} text
 * @param {Txt2SpeechOptions} options
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function txt2speech(text: string, options: Txt2SpeechOptions, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {string} text
 * @param {string} language
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function txt2speech(text: string, language: string, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {string} text
 * @param {string} language
 * @param {string} voice
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function txt2speech(text: string, language: string, voice: string, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {string} text
 * @param {string} language
 * @param {string} voice
 * @param {string} engine
 * @param {boolean} [testMode]
 * @returns {Promise<HTMLAudioElement>}
 */
export function txt2speech(text: string, language: string, voice: string, engine: string, testMode?: boolean | undefined): Promise<HTMLAudioElement>;
/**
 * @overload
 * @param {string} [provider]
 * @returns {Promise<TTSEngine[]>}
 */
export function listEngines(provider?: string | undefined): Promise<TTSEngine[]>;
/**
 * @overload
 * @param {ListTTSEnginesOptions} [options]
 * @returns {Promise<TTSEngine[]>}
 */
export function listEngines(options?: import("./types.js").ListTTSEnginesOptions | undefined): Promise<TTSEngine[]>;
/**
 * @overload
 * @param {string} [engine]
 * @returns {Promise<TTSVoice[]>}
 */
export function listVoices(engine?: string | undefined): Promise<TTSVoice[]>;
/**
 * @overload
 * @param {ListTTSVoicesOptions} [options]
 * @returns {Promise<TTSVoice[]>}
 */
export function listVoices(options?: import("./types.js").ListTTSVoicesOptions | undefined): Promise<TTSVoice[]>;
export type ListTTSEnginesOptions = import("./types.js").ListTTSEnginesOptions;
export type ListTTSVoicesOptions = import("./types.js").ListTTSVoicesOptions;
export type TTSEngine = import("./types.js").TTSEngine;
export type TTSVoice = import("./types.js").TTSVoice;
export type Txt2SpeechOptions = import("./types.js").Txt2SpeechOptions;
