export function toAudioElement(result: unknown): Promise<HTMLAudioElement>;
export function toImageElement(result: unknown): Promise<HTMLImageElement>;
export function toVideoElement(result: unknown): Promise<HTMLVideoElement>;
