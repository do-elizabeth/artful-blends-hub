export function isBlobLike(value: any): value is Blob | File;
export function isPlainObject(value: any): value is Record<string, unknown>;
export function hasTestModeFlag(values: any): any;
export function toDataUriIfBlob(value: any): Promise<any>;
export function dataUriByteLength(dataUri: any): number;
