export type AIMessageContent = string | {
    image_url?: {
        url: string;
    };
} | {
    video_url?: {
        url: string;
    };
} | Record<string, unknown>;
/**
 * An image attached to a message.
 */
export type ImageContent = {
    type: string;
    image_url: {
        url: string;
    };
};
/**
 * One tool call the model asked for.
 */
export type ToolCall = {
    id: string;
    function: {
        name: string;
        arguments: string;
    };
};
/**
 * A function/tool definition the model may call.
 */
export type Tool = {
    type: string;
    function: {
        name: string;
        description: string;
        parameters: object;
        strict?: boolean;
    };
};
/**
 * One message in a chat conversation.
 */
export type ChatMessage = {
    role?: string | undefined;
    content: AIMessageContent | AIMessageContent[];
    tool_calls?: ToolCall[] | undefined;
    tool_call_id?: string | undefined;
    cache_control?: {
        type: string;
    } | undefined;
    /**
     * Images attached to the message. Present on responses from
     * image-capable models.
     */
    images?: ImageContent[] | undefined;
    /**
     * Reasoning/thinking text, when the model exposes it and the
     * request asked for it. Present on responses only.
     */
    reasoning?: string | undefined;
    /**
     * Opaque provider reasoning artifacts (Anthropic thinking
     * signatures, OpenAI reasoning item ids/encrypted content). Resend them verbatim to continue an
     * extended-thinking turn. Present on responses only.
     */
    reasoning_details?: object[] | undefined;
    /**
     * Refusal message when the model declined, otherwise `null`.
     * Present on responses only.
     */
    refusal?: string | null | undefined;
};
/**
 * Options for a chat completion request.
 */
export type ChatOptions = {
    /**
     * The model to use for the completion. Defaults to `gpt-5-nano` if not
     * specified.
     */
    model?: string | undefined;
    /**
     * Sampling temperature between 0 and 2. Lower values are more focused
     * and deterministic, higher values more random. Defaults to the model's own default.
     */
    temperature?: number | undefined;
    max_tokens?: number | undefined;
    vision?: boolean | undefined;
    driver?: string | undefined;
    /**
     * The provider to route the request through.
     */
    provider?: string | undefined;
    /**
     * Function/tool definitions the model can call. See Function Calling.
     */
    tools?: Tool[] | undefined;
    /**
     * Response-format control for non-streaming results. `true` returns the
     * OpenAI-style shape regardless of provider or release date (`message.content` as a string,
     * `message.tool_calls`, a mapped `finish_reason`); `false` forces the provider's native shape. Left
     * unset, the SDK-wide `puter.ai.normalize` applies — itself tri-state: `true` normalizes every call,
     * `false` disables normalization for every call, and unset (the default) means the release-date
     * policy: models released on or after September 1, 2026 are normalized, older models keep their native
     * shape. Streaming responses are unaffected (chunks are already provider-uniform).
     */
    normalize?: boolean | undefined;
    response?: unknown;
    /**
     * Controls how much effort reasoning models spend thinking. Flat
     * form. Accepted values: `none`, `minimal`, `low`, `medium`, `high`, `xhigh` (availability varies by
     * model; default `medium` on newer GPT-5.x models). Reasoning models only.
     */
    reasoning_effort?: string | undefined;
    /**
     * Nested form of `reasoning_effort`. The `effort` value
     * accepts the same values as `reasoning_effort`. Reasoning models only.
     */
    reasoning?: {
        effort: string;
    } | undefined;
    /**
     * Controls how long or short responses are. Flat form. Accepted values:
     * `low`, `medium`, `high`. Reasoning models only.
     */
    verbosity?: string | undefined;
    /**
     * Nested form of `verbosity` — it lives under `text`. The
     * `verbosity` value accepts the same values as `verbosity`. Reasoning models only.
     */
    text?: {
        verbosity: string;
    } | undefined;
    /**
     * Controls image output for
     * image-capable models. `aspect_ratio` is the aspect ratio of the generated image, e.g. `"16:9"`,
     * `"1:1"`, `"9:16"`; `image_size` is the output quality/resolution and must be one of the model's
     * supported quality levels.
     */
    image_config?: {
        aspect_ratio: string;
        image_size: string;
    } | undefined;
    /**
     * Provider-neutral inline-compaction
     * opt-in for long stateless conversations. `true` enables it with provider defaults; an object sets the
     * token threshold at which earlier context is summarized. When the upstream compacts, you receive a
     * `"compaction"` chunk (streaming) or a `compaction` field on the result (non-streaming) — resend it in
     * `messages` on the next turn in place of the summarized history.
     */
    compaction?: boolean | {
        trigger_tokens?: number;
    } | undefined;
    /**
     * Escape hatch: a provider-native `context_management`
     * payload, passed through untouched. Prefer `compaction` for provider portability.
     */
    context_management?: unknown;
};
/**
 * `ChatOptions` with streaming turned on, which changes what `chat()` resolves
 * to.
 */
export type StreamingChatOptions = ChatOptions & {
    stream: boolean;
};
/**
 * What a non-streaming `chat()` resolves to.
 */
export type ChatResponse = {
    message?: ChatMessage | undefined;
    /**
     * Why generation stopped: `stop`, `length`, `tool_calls`, or
     * `content_filter` — or the vendor's own stop reason (e.g. Anthropic's `pause_turn`), passed
     * through unchanged when it has no OpenAI equivalent. Treat it as an open set.
     */
    finish_reason?: string | undefined;
    /**
     * Present and `true` when the response format was normalized
     * server-side (see the `normalize` option on [ChatOptions]).
     */
    normalized?: boolean | undefined;
    choices?: unknown;
    /**
     * Inline-compaction artifact, present when the upstream compacted earlier context during this
     * (non-streaming) response. Carries `type:'compaction'` so you can push it straight into `messages` on
     * the next turn in place of the summarized history (same shape as the streaming `compaction` chunk).
     */
    compaction?: {
        type: "compaction";
        id?: string;
        encrypted_content: string;
    } | undefined;
};
/**
 * A single chunk of a streaming chat response. Each chunk has a `type`
 * discriminator; which other fields are present depends on that `type`.
 */
export type ChatResponseChunk = {
    /**
     * The kind of chunk: `"text"`, `"reasoning"`, `"image"`, `"tool_use"`,
     * `"compaction"`, `"extra_content"`, `"usage"`, or `"error"`.
     */
    type: string;
    /**
     * Text delta. Present on `"text"` chunks.
     */
    text?: string | undefined;
    /**
     * Reasoning/thinking delta. Present on `"reasoning"` chunks.
     */
    reasoning?: string | undefined;
    /**
     * A generated image. Present on `"image"` chunks from image-capable
     * models.
     */
    image?: ImageContent | undefined;
    /**
     * Tool call id (`"tool_use"`) or compaction item id (`"compaction"`).
     */
    id?: string | undefined;
    /**
     * Tool/function name. Present on `"tool_use"` chunks.
     */
    name?: string | undefined;
    /**
     * Parsed tool call arguments. Present on `"tool_use"` chunks.
     */
    input?: unknown;
    /**
     * Opaque/encrypted compaction summary. Present on
     * `"compaction"` chunks — the same shape regardless of which provider served the request. Resend it in
     * `messages` on the next turn in place of the summarized history.
     */
    encrypted_content?: string | undefined;
    /**
     * Provider-specific extra metadata.
     */
    extra_content?: unknown;
    /**
     * Token usage totals. Present on the final `"usage"` chunk.
     */
    usage?: Record<string, number> | undefined;
    /**
     * Error description. Present on `"error"` chunks, which end the stream.
     */
    message?: string | undefined;
};
/**
 * Options for `img2txt()` (OCR).
 */
export type Img2TxtOptions = {
    source?: string | Blob | File | undefined;
    provider?: string | undefined;
    testMode?: boolean | undefined;
    /**
     * `snake_case` spelling of `testMode`, forwarded to the driver as-is.
     */
    test_mode?: boolean | undefined;
    model?: string | undefined;
    pages?: number[] | undefined;
    includeImageBase64?: boolean | undefined;
    imageLimit?: number | undefined;
    imageMinSize?: number | undefined;
    bboxAnnotationFormat?: string | undefined;
    documentAnnotationFormat?: string | undefined;
};
/**
 * Options for `txt2img()`.
 */
export type Txt2ImgOptions = {
    /**
     * Text description of the image to generate.
     */
    prompt?: string | undefined;
    /**
     * Image model to use (provider-specific). Defaults to `'gpt-image-1-mini'`
     * (OpenAI), or `'grok-imagine-image'` when `provider` is `'xai'`.
     */
    model?: string | undefined;
    /**
     * Image quality / output size tier. Interpretation is provider- and
     * model-specific: OpenAI GPT models take `'high'` | `'medium'` | `'low'` (default `'low'`),
     * `gpt-image-2` also accepts `'auto'`, and `gpt-image-2.5-sunburst` / `gpt-image-2.5-flare` also
     * accept `'xhigh'` | `'max'` | `'auto'`; Gemini takes an output size tier `'512'` | `'1K'` | `'2K'` |
     * `'4K'` (availability varies by model).
     */
    quality?: string | undefined;
    /**
     * An input image for image-to-image generation. Replicate and xAI
     * `grok-imagine-*` accept a URL; Gemini and OpenAI `gpt-image-*` expect a base64-encoded (or data-URI)
     * image (xAI also accepts base64/data-URI).
     */
    input_image?: string | undefined;
    /**
     * Multiple input images for image-to-image / multi-image
     * generation. Gemini and OpenAI `gpt-image-*` expect base64-encoded (or data-URI) images; Replicate
     * expects image URLs; xAI `grok-imagine-*` accepts either (up to 3 images).
     */
    input_images?: string[] | undefined;
    /**
     * MIME type of the input image(s), e.g. `'image/png'`. Used
     * as a fallback when the type cannot be auto-detected (Gemini).
     */
    input_image_mime_type?: string | undefined;
    driver?: string | undefined;
    provider?: string | undefined;
    service?: string | undefined;
    /**
     * Aspect ratio as `{ w, h }` (e.g. `{ w: 16, h: 9 }`).
     * Supported by OpenAI, Gemini, and Replicate.
     */
    ratio?: {
        w: number;
        h: number;
    } | undefined;
    /**
     * Width of the image to generate, in pixels (Together). Default `1024`.
     */
    width?: number | undefined;
    /**
     * Height of the image to generate, in pixels (Together). Default `1024`.
     */
    height?: number | undefined;
    /**
     * Alternative way to specify the aspect ratio (Together).
     */
    aspect_ratio?: string | undefined;
    /**
     * Number of generation/inference steps (Together, default `20`; Replicate
     * `flux-schnell`).
     */
    steps?: number | undefined;
    /**
     * Seed used for generation; reuse to reproduce results (Together, Replicate).
     */
    seed?: number | undefined;
    /**
     * Prompt describing what NOT to guide the image generation toward
     * (Together).
     */
    negative_prompt?: string | undefined;
    /**
     * Number of image results to generate (Together). Default `1`.
     */
    n?: number | undefined;
    /**
     * URL of an input image for models that support it (Together).
     */
    image_url?: string | undefined;
    /**
     * Base64-encoded input image for image-to-image generation (Together).
     */
    image_base64?: string | undefined;
    /**
     * URL of a mask image for inpainting (Together).
     */
    mask_image_url?: string | undefined;
    /**
     * Base64-encoded mask image for inpainting (Together).
     */
    mask_image_base64?: string | undefined;
    /**
     * How strongly the prompt influences the output (Together).
     */
    prompt_strength?: number | undefined;
    /**
     * When `true`, disables the safety checker (Together,
     * Replicate).
     */
    disable_safety_checker?: boolean | undefined;
    /**
     * Format of the image response. Together: `'base64'` | `'url'`.
     * Replicate: output format, e.g. `'webp'` | `'jpg'` | `'png'`.
     */
    response_format?: string | undefined;
    /**
     * Guidance scale (Replicate `flux-2-klein-9b-base`).
     */
    guidance?: number | undefined;
    /**
     * Use the model's optimized fast mode (Replicate `flux-2-dev`). Defaults
     * to `true` for that model, and affects pricing.
     */
    go_fast?: boolean | undefined;
    /**
     * Output quality, 0-100 (Replicate, flux family).
     */
    output_quality?: number | undefined;
    /**
     * Approximate output size in megapixels (Replicate, flux
     * family), e.g. `'0.25'` | `'0.5'` | `'1'` | `'2'`.
     */
    output_megapixels?: string | undefined;
    /**
     * Safety tolerance level (Replicate `flux-2-pro`,
     * `flux-1.1-pro`).
     */
    safety_tolerance?: number | undefined;
    /**
     * Enable prompt upsampling (Replicate `flux-1.1-pro`).
     */
    prompt_upsampling?: boolean | undefined;
    /**
     * Generation tier for Replicate Leonardo models, which affects
     * pricing: `'standard'` | `'ultra'` (`lucid-origin`), `'fast'` | `'quality'` | `'ultra'`
     * (`phoenix-1.0`).
     */
    generation_mode?: string | undefined;
    /**
     * Stylistic preset (Replicate Leonardo models).
     */
    style?: string | undefined;
    /**
     * Contrast preset (Replicate Leonardo models).
     */
    contrast?: string | undefined;
    /**
     * Server-side prompt enhancement (Replicate Leonardo models).
     */
    prompt_enhance?: boolean | undefined;
    /**
     * When `true`, returns a sample image without using credits.
     */
    test_mode?: boolean | undefined;
    /**
     * When set, the generated image is saved to this path on the
     * Puter filesystem. Relative paths resolve against the app's data directory (`~/AppData/<appID>/`) when
     * called from an app, or `~/` otherwise. The caller must have write permission to the destination.
     */
    puter_output_path?: string | undefined;
};
/**
 * Options for `txt2vid()`.
 */
export type Txt2VidOptions = {
    /**
     * Text description of the clip.
     */
    prompt?: string | undefined;
    /**
     * Pin the request to one provider: `'gemini-video-generation'`,
     * `'together-video-generation'` or `'byteplus-video-generation'`. Defaults to the provider that owns
     * `model`, or Google when neither is given.
     */
    provider?: string | undefined;
    /**
     * Same effect as `provider`.
     */
    driver?: string | undefined;
    /**
     * Video model id (provider-specific). Defaults to `'veo-3.1-lite'`.
     */
    model?: string | undefined;
    /**
     * Clip length in seconds. A value the model does not offer falls back
     * to the model default.
     */
    seconds?: number | undefined;
    /**
     * Alias of `seconds`.
     */
    duration?: number | undefined;
    /**
     * When `true`, returns a sample clip without using credits.
     */
    test_mode?: boolean | undefined;
    /**
     * Output size as `'WIDTHxHEIGHT'` on every provider (tier-based models map
     * it to the tier of the shorter side plus an aspect ratio), or a tier such as `'720p'` for Seedance
     * and Wan 2.7.
     */
    size?: string | undefined;
    /**
     * Alias of `size`.
     */
    resolution?: string | undefined;
    /**
     * First-frame image for image-to-video: a URL, data URI or raw
     * base64, on every provider.
     */
    input_reference?: string | undefined;
    /**
     * Last-frame image, same formats as `input_reference`.
     */
    last_frame?: string | undefined;
    /**
     * Subject/style reference images (URL, data URI or base64).
     * Veo 3.1: up to 3; Seedance 2.0: up to 9; Seedance 2.5: up to 30; Together: model-dependent.
     */
    reference_images?: string[] | undefined;
    /**
     * What to keep out of the video (Veo, Together).
     */
    negative_prompt?: string | undefined;
    /**
     * Generate a soundtrack on models that support audio (Seedance 2.x
     * and 1.5 Pro, and Together models with audio). Defaults to `true` on Seedance.
     */
    generate_audio?: boolean | undefined;
    /**
     * Random seed (Together, Seedance 1.x).
     */
    seed?: number | undefined;
    /**
     * Output width in pixels on Together models sized in pixels; with `height`,
     * selects the aspect ratio on Seedance and Wan 2.7. Filled in from `size` when omitted.
     */
    width?: number | undefined;
    /**
     * Output height in pixels; see `width`.
     */
    height?: number | undefined;
    /**
     * TogetherAI.
     */
    fps?: number | undefined;
    /**
     * TogetherAI.
     */
    steps?: number | undefined;
    /**
     * TogetherAI.
     */
    guidance_scale?: number | undefined;
    /**
     * TogetherAI.
     */
    output_format?: string | undefined;
    /**
     * TogetherAI.
     */
    output_quality?: number | undefined;
    /**
     * TogetherAI: keyframe images
     * for image-to-video.
     */
    frame_images?: {
        input_image: string;
        frame: number;
    }[] | undefined;
    /**
     * TogetherAI.
     */
    metadata?: Record<string, unknown> | undefined;
    /**
     * Save the generated video to this path on the Puter filesystem.
     * Relative paths resolve against the app's data directory (`~/AppData/<appID>/`) when called from an
     * app, or `~/` otherwise. The caller must have write permission to the destination.
     */
    puter_output_path?: string | undefined;
};
/**
 * Options for `txt2speech()`.
 */
export type Txt2SpeechOptions = {
    /**
     * Text to synthesize. Must be less than 3000 characters.
     */
    text?: string | undefined;
    /**
     * Language code. For AWS Polly defaults to `'en-US'`; for xAI a BCP-47
     * code defaulting to `'en'` (supports `'auto'`).
     */
    language?: string | undefined;
    /**
     * Voice ID used for synthesis (provider-specific). Defaults to `'Joanna'`
     * (aws-polly), `'alloy'` (openai), `'21m00Tcm4TlvDq8ikWAM'` (elevenlabs), `'Kore'` (gemini), `'eve'`
     * (xai), `'geffen_32'` (speechify).
     */
    voice?: string | undefined;
    /**
     * AWS Polly synthesis engine: `'standard'` (default), `'neural'`,
     * `'long-form'`, or `'generative'`.
     */
    engine?: string | undefined;
    /**
     * TTS provider: `'aws-polly'` (default), `'openai'`, `'elevenlabs'`,
     * `'gemini'`, `'xai'`, or `'speechify'`. Common aliases (`'eleven'`, `'google'`, `'grok'`, `'polly'`,
     * `'simba'`, …) resolve to these.
     */
    provider?: string | undefined;
    /**
     * Model identifier (provider-specific).
     */
    model?: string | undefined;
    /**
     * OpenAI output format: `'mp3'` (default), `'wav'`, `'opus'`,
     * `'aac'`, `'flac'`, or `'pcm'`.
     */
    response_format?: string | undefined;
    /**
     * Output format for ElevenLabs (defaults to `'mp3_44100_128'`) and
     * xAI (`'mp3'` default, `'wav'`, `'pcm'`, `'mulaw'`, `'alaw'`).
     */
    output_format?: string | undefined;
    /**
     * Natural-language guidance for voice style such as tone, speed, and
     * mood (OpenAI and Gemini).
     */
    instructions?: string | undefined;
    /**
     * ElevenLabs voice tuning options (e.g. stability,
     * similarity boost, speed).
     */
    voice_settings?: Record<string, unknown> | undefined;
    /**
     * When `true`, AWS Polly treats `text` as SSML markup.
     */
    ssml?: boolean | undefined;
    /**
     * When `true`, returns a sample audio without using credits.
     */
    test_mode?: boolean | undefined;
};
/**
 * Options for `txt2speech.listEngines()`.
 */
export type ListTTSEnginesOptions = {
    /**
     * TTS provider to query. Defaults to `'aws-polly'`; `'all'` returns every
     * provider's engines.
     */
    provider?: string | undefined;
};
/**
 * A TTS engine/model as returned by `txt2speech.listEngines()`.
 */
export type TTSEngine = {
    /**
     * Engine/model identifier.
     */
    id: string;
    /**
     * Human-readable engine name.
     */
    name: string;
    /**
     * Provider this engine belongs to.
     */
    provider: string;
    /**
     * Cost per million characters (may be absent).
     */
    pricing_per_million_chars?: number | undefined;
};
/**
 * Options for `txt2speech.listVoices()`.
 */
export type ListTTSVoicesOptions = {
    /**
     * TTS provider to query. Defaults to `'aws-polly'`; `'all'` returns every
     * provider's voices.
     */
    provider?: string | undefined;
    /**
     * Engine/model filter (provider-specific, ignored by some providers).
     */
    engine?: string | undefined;
};
/**
 * A TTS voice as returned by `txt2speech.listVoices()`.
 */
export type TTSVoice = {
    /**
     * Voice identifier to pass to `txt2speech()`.
     */
    id: string;
    /**
     * Human-readable voice name.
     */
    name: string;
    /**
     * Provider this voice belongs to.
     */
    provider: string;
    /**
     * Language info (may be absent).
     */
    language?: {
        name: string;
        code: string;
    } | undefined;
    /**
     * Short description of the voice (may be absent).
     */
    description?: string | undefined;
    /**
     * Voice category, e.g. `'premade'` (may be absent).
     */
    category?: string | undefined;
    /**
     * Provider-specific labels (may be absent).
     */
    labels?: Record<string, unknown> | undefined;
    /**
     * Model IDs this voice works with (may be absent).
     */
    supported_models?: string[] | undefined;
    /**
     * Engine types this voice supports (may be absent).
     */
    supported_engines?: string[] | undefined;
};
/**
 * One word of a `speech2txt()` transcript.
 */
export type Speech2TxtWord = {
    text: string;
    start: number;
    end: number;
    /**
     * Detected speaker, present when `diarize: true` (xAI).
     */
    speaker?: string | undefined;
};
/**
 * What `speech2txt()` resolves to, unless `response_format` is `"text"`.
 */
export type Speech2TxtResult = {
    text: string;
    language: string;
    segments?: Record<string, unknown>[] | undefined;
    /**
     * Duration of the audio in seconds (provider-dependent, e.g. xAI).
     */
    duration?: number | undefined;
    /**
     * Per-word timestamps (provider-dependent, e.g. xAI).
     */
    words?: Speech2TxtWord[] | undefined;
};
/**
 * The options every `speech2txt()` form shares.
 */
export type BaseSpeech2TxtOptions = {
    file?: string | Blob | File | undefined;
    audio?: string | Blob | File | undefined;
    provider?: string | undefined;
    model?: string | undefined;
    language?: string | undefined;
    prompt?: string | undefined;
    stream?: boolean | undefined;
    translate?: boolean | undefined;
    temperature?: number | undefined;
    logprobs?: boolean | undefined;
    timestamp_granularities?: string[] | undefined;
    chunking_strategy?: string | undefined;
    known_speaker_names?: string[] | undefined;
    known_speaker_references?: string[] | undefined;
    extra_body?: Record<string, unknown> | undefined;
    format?: boolean | undefined;
    diarize?: boolean | undefined;
    multichannel?: boolean | undefined;
    channels?: number | undefined;
    audio_format?: string | undefined;
    sample_rate?: number | undefined;
    test_mode?: boolean | undefined;
};
/**
 * The `response_format: "text"` form, which resolves to a plain string.
 */
export type TextFormatSpeech2TxtOptions = BaseSpeech2TxtOptions & {
    response_format: "text";
};
/**
 * Any other `speech2txt()` form, which resolves to a `Speech2TxtResult`.
 */
export type Speech2TxtOptions = BaseSpeech2TxtOptions & {
    response_format?: Exclude<string, "text">;
};
/**
 * Options for `speech2speech()`. The camelCase aliases are mapped onto the
 * snake_case names before the request goes out; the snake_case spelling wins
 * when both are given.
 */
export type Speech2SpeechOptions = {
    audio?: string | Blob | File | undefined;
    file?: string | Blob | File | undefined;
    provider?: string | undefined;
    model?: string | undefined;
    model_id?: string | undefined;
    voice?: string | undefined;
    voice_id?: string | undefined;
    output_format?: string | undefined;
    voice_settings?: Record<string, unknown> | undefined;
    seed?: number | undefined;
    file_format?: string | undefined;
    remove_background_noise?: boolean | undefined;
    optimize_streaming_latency?: number | undefined;
    enable_logging?: boolean | undefined;
    test_mode?: boolean | undefined;
    /**
     * camelCase alias of `model_id`.
     */
    modelId?: string | undefined;
    /**
     * camelCase alias of `voice_id`.
     */
    voiceId?: string | undefined;
    /**
     * camelCase alias of `output_format`.
     */
    outputFormat?: string | undefined;
    /**
     * camelCase alias of `voice_settings`.
     */
    voiceSettings?: Record<string, unknown> | undefined;
    /**
     * camelCase alias of `file_format`.
     */
    fileFormat?: string | undefined;
    /**
     * camelCase alias of `remove_background_noise`.
     */
    removeBackgroundNoise?: boolean | undefined;
    /**
     * camelCase alias of `optimize_streaming_latency`.
     */
    optimizeStreamingLatency?: number | undefined;
    /**
     * camelCase alias of `enable_logging`.
     */
    enableLogging?: boolean | undefined;
};
