/**
 * Information about a deployed worker, as returned by `get()` and `list()`.
 *
 * @typedef {Object} WorkerInfo
 * @property {string} name The name of the worker.
 * @property {string} url The URL of the worker.
 * @property {string} file_path The file path of the worker's source code.
 * @property {string} file_uid The unique identifier of the worker file.
 * @property {string | null} app_uid The unique identifier of the app or sandbox app owning the worker, or null if user-scoped.
 * @property {string} created_at The date and time when the worker was created.
 */
/**
 * The result of a worker deployment, as returned by `create()`.
 *
 * @typedef {Object} WorkerDeployment
 * @property {boolean} success Whether the worker deployment was successful.
 * @property {string} url The URL of the deployed worker.
 * @property {string[]} [errors] Any errors that occurred during deployment.
 */
/** @typedef {import('../lib/types.js').ListPage<WorkerInfo>} WorkerPage */
/** @typedef {import('../lib/types.js').ListPaginationOptions} ListPaginationOptions */
/** @typedef {import('../lib/types.js').ListStreamOptions} ListStreamOptions */
/**
 * The `puter.workers` module: deploy and call serverless workers.
 */
export class WorkersHandler extends PuterModule {
    /**
     * @overload
     * @param {string} workerName
     * @param {string} filePath
     * @param {string} [appName] an existing app to bind the worker to
     * @returns {Promise<WorkerDeployment>}
     */
    create(workerName: string, filePath: string, appName?: string | undefined): Promise<WorkerDeployment>;
    /**
     * @overload
     * @param {string} workerName
     * @param {string} filePath
     * @param {{ sandbox?: boolean }} [options] whether the worker gets its own
     *   `sandbox-<workerName>` app. Defaults to `true` for user tokens and
     *   `false` when an app deploys the worker.
     * @returns {Promise<WorkerDeployment>}
     */
    create(workerName: string, filePath: string, options?: {
        sandbox?: boolean;
    } | undefined): Promise<WorkerDeployment>;
    /**
     * Calls a worker endpoint, attaching the user's session so the worker gets
     * user context (`user.puter`) for the User-Pays model. Takes the same
     * arguments as `fetch` and resolves to its `Response`. Set the
     * `x-puter-no-auth` header to send the request without the session.
     *
     * @param {...unknown} args a `fetch`-compatible `(input, init?)` pair
     * @returns {Promise<Response>}
     */
    exec(...args: unknown[]): Promise<Response>;
    /**
     * @overload
     * @param {ListStreamOptions} options
     * @returns {AsyncIterableIterator<WorkerPage>}
     */
    list(options: ListStreamOptions): AsyncIterableIterator<WorkerPage>;
    /**
     * @overload
     * @param {ListPaginationOptions} options
     * @returns {Promise<WorkerPage>}
     */
    list(options: ListPaginationOptions): Promise<WorkerPage>;
    /**
     * @overload
     * @returns {Promise<WorkerInfo[]>}
     */
    list(): Promise<WorkerInfo[]>;
    /**
     * Returns the named worker, or `undefined` if the account has no worker by
     * that name. Worker names are case-insensitive.
     *
     * @param {string} workerName
     * @returns {Promise<WorkerInfo | undefined>}
     */
    get(workerName: string): Promise<WorkerInfo | undefined>;
    /**
     * Deletes a worker and stops it serving. Resolves to `true` on success.
     *
     * @param {string} workerName
     * @returns {Promise<boolean>}
     */
    delete(workerName: string): Promise<boolean>;
    /**
     * Opens a live log stream for a worker. The resolved handle is an
     * `EventTarget` that emits `log` events (and calls `onLog`) as the worker
     * logs; `close()` ends the stream. It also carries `start`/`cancel`, so it
     * can be handed to a `ReadableStream`.
     *
     * @param {string} workerName
     * @returns {Promise<EventTarget & { close: () => void, onLog: (event: MessageEvent) => void }>}
     */
    getLoggingHandle(workerName: string): Promise<EventTarget & {
        close: () => void;
        onLog: (event: MessageEvent) => void;
    }>;
    #private;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../lib/types.js').OmitMembers<
 *     typeof WorkersHandler,
 *     'puter' | 'authToken'
 * >} WorkersConstructor
 */
export const Workers: WorkersConstructor;
/**
 * Information about a deployed worker, as returned by `get()` and `list()`.
 */
export type WorkerInfo = {
    /**
     * The name of the worker.
     */
    name: string;
    /**
     * The URL of the worker.
     */
    url: string;
    /**
     * The file path of the worker's source code.
     */
    file_path: string;
    /**
     * The unique identifier of the worker file.
     */
    file_uid: string;
    /**
     * The unique identifier of the app or sandbox app owning the worker, or null if user-scoped.
     */
    app_uid: string | null;
    /**
     * The date and time when the worker was created.
     */
    created_at: string;
};
/**
 * The result of a worker deployment, as returned by `create()`.
 */
export type WorkerDeployment = {
    /**
     * Whether the worker deployment was successful.
     */
    success: boolean;
    /**
     * The URL of the deployed worker.
     */
    url: string;
    /**
     * Any errors that occurred during deployment.
     */
    errors?: string[] | undefined;
};
export type WorkerPage = import("../lib/types.js").ListPage<WorkerInfo>;
export type ListPaginationOptions = import("../lib/types.js").ListPaginationOptions;
export type ListStreamOptions = import("../lib/types.js").ListStreamOptions;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type WorkersConstructor = import("../lib/types.js").OmitMembers<typeof WorkersHandler, "puter" | "authToken">;
import { PuterModule } from '../lib/PuterModule.js';
