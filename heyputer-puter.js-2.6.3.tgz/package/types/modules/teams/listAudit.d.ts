/**
 * @overload
 * @param {string} uid
 * @param {import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<TeamAuditPage>}
 */
export function listAudit(uid: string, options: import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<TeamAuditPage>;
/**
 * @overload
 * @param {string} uid
 * @param {TeamListOptions & ({ cursor: string | null } | { includeTotal: true })} options
 * @returns {Promise<TeamAuditPage>}
 */
export function listAudit(uid: string, options: TeamListOptions & ({
    cursor: string | null;
} | {
    includeTotal: true;
})): Promise<TeamAuditPage>;
/**
 * @overload
 * @param {string} uid
 * @param {{ limit?: number }} [options]
 * @returns {Promise<TeamAuditEntry[]>}
 */
export function listAudit(uid: string, options?: {
    limit?: number;
} | undefined): Promise<TeamAuditEntry[]>;
export type TeamAuditEntry = import("./types.js").TeamAuditEntry;
export type TeamAuditPage = import("../../lib/types.js").ListPage<TeamAuditEntry>;
export type TeamListOptions = Omit<import("../../lib/types.js").ListPaginationOptions, "offset">;
