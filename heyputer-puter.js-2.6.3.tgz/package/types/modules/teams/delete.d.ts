/**
 * Deletes a team. Owner account only. The accounts it provisioned keep
 * existing; what stops is the team paying for them. Its audit log stays
 * readable to the owner account afterwards.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @returns {Promise<void>}
 */
export function del(this: import("./index.js").TeamsModule, uid: string): Promise<void>;
