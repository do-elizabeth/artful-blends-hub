/**
 * Issues a fresh one-time credential for an account that has never signed in,
 * invalidating the previous one. Owner account only.
 *
 * It refuses with `conflict` once the account has been activated: after that
 * the member owns their own password, and an administrator able to replace it
 * would be able to reach their data.
 *
 * The returned password is shown once and is not retrievable afterwards.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @param {string} username
 * @returns {Promise<import('./types.js').TemporaryCredential>}
 */
export function resendActivation(this: import("./index.js").TeamsModule, uid: string, username: string): Promise<import("./types.js").TemporaryCredential>;
