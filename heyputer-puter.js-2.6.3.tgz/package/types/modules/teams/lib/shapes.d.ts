/** @typedef {import('../types.js').Team} Team */
/** @typedef {import('../types.js').TeamMember} TeamMember */
/** @typedef {import('../types.js').TeamAuditEntry} TeamAuditEntry */
/**
 * @param {Record<string, unknown>} row
 * @returns {Team}
 */
export function toTeam(row: Record<string, unknown>): Team;
/**
 * @param {Record<string, unknown>} row
 * @returns {import('../types.js').TeamDirectoryEntry}
 */
export function toDirectoryEntry(row: Record<string, unknown>): import("../types.js").TeamDirectoryEntry;
/**
 * @param {Record<string, unknown>} row
 * @returns {TeamMember}
 */
export function toMember(row: Record<string, unknown>): TeamMember;
/**
 * @param {Record<string, unknown>} row
 * @returns {TeamAuditEntry}
 */
export function toAuditEntry(row: Record<string, unknown>): TeamAuditEntry;
/**
 * Applies `map` to whichever of the three list forms `result` is, leaving the
 * form itself alone.
 *
 * @template T
 * @param {unknown} result
 * @param {(row: Record<string, unknown>) => T} map
 * @returns {unknown}
 */
export function mapListResult<T>(result: unknown, map: (row: Record<string, unknown>) => T): unknown;
export type Team = import("../types.js").Team;
export type TeamMember = import("../types.js").TeamMember;
export type TeamAuditEntry = import("../types.js").TeamAuditEntry;
