/**
 * The three list forms every `puter.teams` list method shares, over a `/teams`
 * route instead of a driver call: a plain array by default, the
 * `{ items, cursor? }` envelope once `cursor` or `includeTotal` is passed, and
 * an async iterator of envelopes under `stream: true`. Matches
 * `puter.apps.list()`.
 *
 * The `/teams` routes are keyset-only, so `offset` is refused rather than sent
 * and quietly ignored — a rejected call is easier to diagnose than page one
 * returned four times.
 *
 * @param {import('../../../index.js').Puter} puter
 * @param {string} route
 * @param {import('../../../lib/types.js').ListPaginationOptions | import('../../../lib/types.js').ListStreamOptions} [options]
 * @param {string} [operation]
 * @returns {Promise<unknown[]> | Promise<import('../../../lib/types.js').ListPage<unknown>> | AsyncIterableIterator<import('../../../lib/types.js').ListPage<unknown>>}
 */
export function listRoute(puter: import("../../../index.js").Puter, route: string, options?: import("../../../lib/types.js").ListPaginationOptions | import("../../../lib/types.js").ListStreamOptions, operation?: string): Promise<unknown[]> | Promise<import("../../../lib/types.js").ListPage<unknown>> | AsyncIterableIterator<import("../../../lib/types.js").ListPage<unknown>>;
