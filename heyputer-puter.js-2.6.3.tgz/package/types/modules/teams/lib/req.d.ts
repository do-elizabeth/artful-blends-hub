/**
 * Request helper for the `/teams` routes. Unlike `perms/lib/req.js` these
 * reject on failure rather than resolving `{ error: true }` — nothing depends
 * on the older shape here, so the module throws like the rest of the SDK.
 *
 * @param {import('../../../index.js').Puter} puter
 * @param {string} method
 * @param {string} route
 * @param {{ body?: Record<string, unknown>, query?: Record<string, unknown>, operation?: string }} [opts]
 * @returns {Promise<unknown>}
 */
export function req(puter: import("../../../index.js").Puter, method: string, route: string, opts?: {
    body?: Record<string, unknown>;
    query?: Record<string, unknown>;
    operation?: string;
}): Promise<unknown>;
/**
 * Rejects a blank or non-string path segment before it reaches the wire, where
 * an empty `uid` or `username` would silently address a different route.
 *
 * @param {unknown} value
 * @param {string} name
 * @returns {string}
 */
export function requireSegment(value: unknown, name: string): string;
