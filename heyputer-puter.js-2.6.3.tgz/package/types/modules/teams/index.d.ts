/**
 * The `puter.teams` module — team administration.
 *
 * Every method takes a team `uid`, never a handle: a handle is a mutable
 * label that deleting the team releases, so a stored one can later resolve
 * to a different team.
 *
 * Method implementations live in the sibling files as `this`-context functions
 * whose JSDoc (including the per-form `@overload` declarations) is the source
 * of truth for the public signatures — `types/` is generated from it, never
 * edited by hand.
 */
export class TeamsModule extends PuterModule {
    create: typeof create;
    list: typeof list;
    get: typeof get;
    update: typeof update;
    delete: typeof del;
    listMembers: typeof listMembers;
    createMember: typeof createMember;
    resendActivation: typeof resendActivation;
    disableMember: typeof disableMember;
    enableMember: typeof enableMember;
    resetPassword: typeof resetPassword;
    deleteMemberAccount: typeof deleteMemberAccount;
    listAudit: typeof listAudit;
    listOwnAudit: typeof listOwnAudit;
    listDirectory: typeof listDirectory;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof TeamsModule,
 *     'puter' | 'authToken'
 * >} TeamsConstructor
 */
export const Teams: TeamsConstructor;
export default Teams;
export type Puter = import("../../index.js").Puter;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type TeamsConstructor = import("../../lib/types.js").OmitMembers<typeof TeamsModule, "puter" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { create } from './create.js';
import { list } from './list.js';
import { get } from './get.js';
import { update } from './update.js';
import { del } from './delete.js';
import { listMembers } from './listMembers.js';
import { createMember } from './createMember.js';
import { resendActivation } from './resendActivation.js';
import { disableMember } from './disableMember.js';
import { enableMember } from './enableMember.js';
import { resetPassword } from './resetPassword.js';
import { deleteMemberAccount } from './deleteMemberAccount.js';
import { listAudit } from './listAudit.js';
import { listOwnAudit } from './listOwnAudit.js';
import { listDirectory } from './listDirectory.js';
