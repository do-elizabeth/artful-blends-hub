/**
 * @overload
 * @param {string} uid
 * @param {import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<TeamMemberPage>}
 */
export function listMembers(uid: string, options: import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<TeamMemberPage>;
/**
 * @overload
 * @param {string} uid
 * @param {TeamListOptions & ({ cursor: string | null } | { includeTotal: true })} options
 * @returns {Promise<TeamMemberPage>}
 */
export function listMembers(uid: string, options: TeamListOptions & ({
    cursor: string | null;
} | {
    includeTotal: true;
})): Promise<TeamMemberPage>;
/**
 * @overload
 * @param {string} uid
 * @param {{ limit?: number }} [options]
 * @returns {Promise<TeamMember[]>}
 */
export function listMembers(uid: string, options?: {
    limit?: number;
} | undefined): Promise<TeamMember[]>;
export type TeamMember = import("./types.js").TeamMember;
export type TeamMemberPage = import("../../lib/types.js").ListPage<TeamMember>;
export type TeamListOptions = Omit<import("../../lib/types.js").ListPaginationOptions, "offset">;
