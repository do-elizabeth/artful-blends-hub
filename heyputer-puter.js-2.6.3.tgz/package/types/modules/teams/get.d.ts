/**
 * Returns one team the caller belongs to.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @returns {Promise<import('./types.js').Team>}
 */
export function get(this: import("./index.js").TeamsModule, uid: string): Promise<import("./types.js").Team>;
