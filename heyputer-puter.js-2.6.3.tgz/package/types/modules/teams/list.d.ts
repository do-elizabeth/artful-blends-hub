/**
 * @overload
 * @param {import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<TeamPage>}
 */
export function list(options: import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<TeamPage>;
/**
 * @overload
 * @param {TeamListOptions & ({ cursor: string | null } | { includeTotal: true })} options
 * @returns {Promise<TeamPage>}
 */
export function list(options: TeamListOptions & ({
    cursor: string | null;
} | {
    includeTotal: true;
})): Promise<TeamPage>;
/**
 * @overload
 * @param {{ limit?: number }} [options]
 * @returns {Promise<Team[]>}
 */
export function list(options?: {
    limit?: number;
} | undefined): Promise<Team[]>;
export type Team = import("./types.js").Team;
export type TeamPage = import("../../lib/types.js").ListPage<Team>;
export type TeamListOptions = Omit<import("../../lib/types.js").ListPaginationOptions, "offset">;
