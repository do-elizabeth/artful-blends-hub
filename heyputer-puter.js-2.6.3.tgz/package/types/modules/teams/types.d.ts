/**
 * A team. `uid` is the only stable reference: `handle` is a label that
 * `update()` can change and deleting the team releases, so a stored
 * handle can later resolve to a different team.
 */
export type Team = {
    /**
     * The team's unique identifier. Pass this to every other `puter.teams` method.
     */
    uid: string;
    /**
     * The team's display name.
     */
    name: string | null;
    /**
     * The team's short handle, unique while it exists. `null` when unset.
     */
    handle: string | null;
    /**
     * Whether the caller is the owner account of this team.
     */
    isOwner: boolean;
    /**
     * Whether apps acting for a member may read the member list
     * through `Teams.listDirectory()`. Off unless the owner account turns it on.
     */
    directoryEnabled: boolean;
    /**
     * When the team was created, in `YYYY-MM-DDTHH:MM:SSZ` format.
     */
    createdAt: string;
};
/**
 * Options for `Teams.create()`.
 */
export type CreateTeamOptions = {
    /**
     * The team's display name.
     */
    name: string;
    /**
     * A short handle, lowercase letters, digits and single hyphens.
     * Omit or pass `null` for none.
     */
    handle?: string | null | undefined;
};
/**
 * Attributes to change with `Teams.update()`. Omitted fields are left alone.
 */
export type UpdateTeamAttributes = {
    /**
     * The team's new display name.
     */
    name?: string | undefined;
    /**
     * A new handle, or `null` to release the current one.
     */
    handle?: string | null | undefined;
    /**
     * Whether apps acting for a member may read the member list.
     * Off by default; turning it on is recorded in the team's audit log.
     */
    directoryEnabled?: boolean | undefined;
};
/**
 * An account belonging to a team.
 */
export type TeamDirectoryEntry = {
    /**
     * The colleague's Puter username.
     */
    username: string;
    /**
     * Their account identifier, stable across a username change.
     */
    uuid: string;
};
export type TeamMember = {
    /**
     * The member's Puter username.
     */
    username: string;
    /**
     * Whether the team provisioned and pays for this account, as opposed
     * to a pre-existing account that joined it.
     */
    orgOwned: boolean;
    /**
     * When the account joined the team, in `YYYY-MM-DDTHH:MM:SSZ` format.
     */
    createdAt: string;
};
/**
 * Details for the account `Teams.createMember()` provisions.
 */
export type CreateMemberOptions = {
    /**
     * The username for the new account. Must be free across all of Puter.
     */
    username: string;
    /**
     * The address the member is reachable at. It must not already own an account.
     */
    email: string;
};
/**
 * The one-time credential for an account that has not been used yet. It is
 * shown once and cannot be retrieved afterwards — deliver it out of band.
 */
export type TemporaryCredential = {
    /**
     * The account the credential is for.
     */
    username: string;
    /**
     * The password the member signs in with once, then must change.
     */
    temporaryPassword: string;
};
/**
 * One entry in a team's record of what it did to its accounts.
 */
export type TeamAuditEntry = {
    /**
     * What was done, e.g. `create_member`, `disable_member`, `delete_team`.
     */
    action: string;
    /**
     * The reason recorded with the action, when one was given.
     */
    reason: string | null;
    /**
     * The account the action was about. `null` if that account is gone.
     */
    username: string | null;
    /**
     * Who performed it. `null` when Puter itself did.
     */
    actorUsername: string | null;
    /**
     * When it happened, in `YYYY-MM-DDTHH:MM:SSZ` format.
     */
    createdAt: string;
};
