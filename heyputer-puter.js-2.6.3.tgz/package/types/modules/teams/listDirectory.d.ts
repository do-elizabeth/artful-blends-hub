/**
 * @overload
 * @param {string} uid
 * @param {import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<TeamDirectoryPage>}
 */
export function listDirectory(uid: string, options: import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<TeamDirectoryPage>;
/**
 * @overload
 * @param {string} uid
 * @param {TeamListOptions & ({ cursor: string | null } | { includeTotal: true })} options
 * @returns {Promise<TeamDirectoryPage>}
 */
export function listDirectory(uid: string, options: TeamListOptions & ({
    cursor: string | null;
} | {
    includeTotal: true;
})): Promise<TeamDirectoryPage>;
/**
 * @overload
 * @param {string} uid
 * @param {{ limit?: number }} [options]
 * @returns {Promise<TeamDirectoryEntry[]>}
 */
export function listDirectory(uid: string, options?: {
    limit?: number;
} | undefined): Promise<TeamDirectoryEntry[]>;
export type TeamDirectoryEntry = import("./types.js").TeamDirectoryEntry;
export type TeamDirectoryPage = import("../../lib/types.js").ListPage<TeamDirectoryEntry>;
export type TeamListOptions = Omit<import("../../lib/types.js").ListPaginationOptions, "offset">;
