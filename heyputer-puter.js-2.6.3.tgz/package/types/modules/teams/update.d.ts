/**
 * Renames a team or changes its handle. Owner account only. A released
 * handle becomes available to other teams, so anything holding one should
 * hold the `uid` instead.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @param {import('./types.js').UpdateTeamAttributes} attributes
 * @returns {Promise<import('./types.js').Team>}
 */
export function update(this: import("./index.js").TeamsModule, uid: string, attributes: import("./types.js").UpdateTeamAttributes): Promise<import("./types.js").Team>;
