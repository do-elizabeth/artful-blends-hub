/**
 * Restores an account previously suspended with `disableMember()`. Owner
 * account only.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @param {string} username
 * @returns {Promise<void>}
 */
export function enableMember(this: import("./index.js").TeamsModule, uid: string, username: string): Promise<void>;
