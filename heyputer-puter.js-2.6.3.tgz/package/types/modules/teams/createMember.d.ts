/**
 * Provisions a new account owned by the team. Owner account only.
 *
 * There is no role: the owner account is the sole administrator and every
 * provisioned account is an ordinary member.
 *
 * The returned password is shown once and is not retrievable afterwards —
 * deliver it out of band. The member must change it at first sign-in.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @param {import('./types.js').CreateMemberOptions} options
 * @returns {Promise<import('./types.js').TemporaryCredential>}
 */
export function createMember(this: import("./index.js").TeamsModule, uid: string, options: import("./types.js").CreateMemberOptions): Promise<import("./types.js").TemporaryCredential>;
