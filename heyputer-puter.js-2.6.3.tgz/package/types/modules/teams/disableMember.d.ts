/**
 * Suspends an account the team owns, ending its sessions. Owner account
 * only, and reversible with `enableMember()`.
 *
 * A disabled account no longer costs a per-account charge, but the team is
 * still billed for the bytes it holds.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {string} uid
 * @param {string} username
 * @returns {Promise<void>}
 */
export function disableMember(this: import("./index.js").TeamsModule, uid: string, username: string): Promise<void>;
