/** @typedef {import('./types.js').Team} Team */
/**
 * Creates a team owned by the caller, who becomes its owner account.
 *
 * @this {import('./index.js').TeamsModule}
 * @param {import('./types.js').CreateTeamOptions} options
 * @returns {Promise<Team>}
 */
export function create(this: import("./index.js").TeamsModule, options: import("./types.js").CreateTeamOptions): Promise<Team>;
export type Team = import("./types.js").Team;
