/**
 * @overload
 * @param {string} subdomain
 * @param {string} dirPath
 * @returns {Promise<Subdomain>}
 */
export function create(subdomain: string, dirPath: string): Promise<Subdomain>;
/**
 * @overload
 * @param {{ subdomain: string, root_dir: string }} options
 * @returns {Promise<Subdomain>}
 */
export function create(options: {
    subdomain: string;
    root_dir: string;
}): Promise<Subdomain>;
export type Subdomain = import("./types.js").Subdomain;
