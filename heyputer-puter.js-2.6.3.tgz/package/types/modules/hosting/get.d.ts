/** @typedef {import('./types.js').Subdomain} Subdomain */
/**
 * Retrieves a subdomain by name. Rejects if the subdomain does not exist.
 *
 * @this {import('./index.js').HostingModule}
 * @param {string} subdomain
 * @returns {Promise<Subdomain>}
 */
export function get(this: import("./index.js").HostingModule, subdomain: string): Promise<Subdomain>;
export type Subdomain = import("./types.js").Subdomain;
