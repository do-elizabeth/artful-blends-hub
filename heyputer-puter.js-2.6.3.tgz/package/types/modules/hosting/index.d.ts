/** @typedef {import('../../index.js').Puter} Puter */
/**
 * The `puter.hosting` module.
 *
 * Method implementations live in the sibling files as `this`-context
 * functions whose JSDoc (including the per-form `@overload` declarations) is
 * the source of truth for the public signatures — `types/` is generated from
 * it, never edited by hand.
 */
export class HostingModule extends PuterModule {
    list: typeof list;
    create: typeof create;
    update: typeof update;
    get: typeof get;
    delete: typeof del;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../../lib/types.js').OmitMembers<
 *     typeof HostingModule,
 *     'puter' | 'authToken'
 * >} HostingConstructor
 */
export const Hosting: HostingConstructor;
export default Hosting;
export type Puter = import("../../index.js").Puter;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type HostingConstructor = import("../../lib/types.js").OmitMembers<typeof HostingModule, "puter" | "authToken">;
import { PuterModule } from '../../lib/PuterModule.js';
import { list } from './list.js';
import { create } from './create.js';
import { update } from './update.js';
import { get } from './get.js';
import { del } from './delete.js';
