/**
 * A subdomain hosted on Puter, containing its details.
 */
export type Subdomain = {
    /**
     * Unique identifier of the subdomain.
     */
    uid: string;
    /**
     * Name of the subdomain, i.e. the part before the main domain
     * (e.g. `example` in `example.puter.site`).
     */
    subdomain: string;
    /**
     * The root directory of the subdomain, where its
     * files are stored.
     */
    root_dir: import("../FSItem.js").FSItem;
};
