export function normalizeSubdomain(value: unknown): unknown;
