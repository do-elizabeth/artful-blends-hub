/**
 * Deletes a subdomain from the account; it is no longer served. The associated
 * directory is disconnected but not deleted. Rejects if the subdomain does not
 * exist.
 *
 * @this {import('./index.js').HostingModule}
 * @param {string} subdomain
 * @returns {Promise<{ success: boolean, uid: string }>}
 */
export function del(this: import("./index.js").HostingModule, subdomain: string): Promise<{
    success: boolean;
    uid: string;
}>;
