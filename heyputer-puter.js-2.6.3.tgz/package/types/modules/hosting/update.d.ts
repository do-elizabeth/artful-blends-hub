/** @typedef {import('./types.js').Subdomain} Subdomain */
/**
 * Updates a subdomain to point at a new directory. Rejects if the subdomain
 * or the path does not exist. Passing no `dirPath` disconnects the directory.
 *
 * @this {import('./index.js').HostingModule}
 * @param {string} subdomain
 * @param {string} [dirPath]
 * @returns {Promise<Subdomain>}
 */
export function update(this: import("./index.js").HostingModule, subdomain: string, dirPath?: string): Promise<Subdomain>;
export type Subdomain = import("./types.js").Subdomain;
