/**
 * @overload
 * @param {import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<import('../../lib/types.js').ListPage<Subdomain>>}
 */
export function list(options: import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<import("../../lib/types.js").ListPage<Subdomain>>;
/**
 * @overload
 * @param {import('../../lib/types.js').ListPaginationOptions & ({ cursor: string | null } | { includeTotal: true })} options
 * @returns {Promise<import('../../lib/types.js').ListPage<Subdomain>>}
 */
export function list(options: import("../../lib/types.js").ListPaginationOptions & ({
    cursor: string | null;
} | {
    includeTotal: true;
})): Promise<import("../../lib/types.js").ListPage<Subdomain>>;
/**
 * @overload
 * @param {{ limit?: number, offset?: number }} [options]
 * @returns {Promise<Subdomain[]>}
 */
export function list(options?: {
    limit?: number;
    offset?: number;
} | undefined): Promise<Subdomain[]>;
export type Subdomain = import("./types.js").Subdomain;
