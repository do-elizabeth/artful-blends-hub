/**
 * Whether a string is a room name (as opposed to a generated invite code).
 *
 * @param {string} value
 * @returns {boolean}
 */
export function isRoomName(value: string): boolean;
/**
 * Dispatched by `PuterPeerServer` for the `'connection'` event when a client
 * connects.
 */
export class PuterPeerServerConnectionEvent extends Event {
    /**
     * @param {PuterPeerConnection} connection
     * @param {PuterPeerUser} [user]
     */
    constructor(connection: PuterPeerConnection, user?: PuterPeerUser);
    /**
     * The connection to the client.
     *
     * @type {PuterPeerConnection}
     */
    conn: PuterPeerConnection;
    /**
     * Metadata about the connecting user, when available.
     *
     * @type {PuterPeerUser | undefined}
     */
    user: PuterPeerUser | undefined;
}
/**
 * Dispatched by `PuterPeerServer` for the `'reconnect'` event once it has
 * re-registered with the signaller after losing its socket. Existing
 * connections are unaffected; this only concerns clients yet to connect.
 */
export class PuterPeerServerReconnectEvent extends Event {
    /** @param {string} inviteCode */
    constructor(inviteCode: string);
    /**
     * The invite code in force now. Unchanged for a server with a `name`; a
     * server on a generated code gets a new one, since the old one died with
     * the socket.
     *
     * @type {string}
     */
    inviteCode: string;
}
/**
 * Dispatched by `PuterPeerServer` for the `'close'` event when the server has
 * stopped accepting clients for good without `close()` having been called:
 * its name was taken over by a newer server of yours (`replaced`), or is
 * held by someone else and could not be reclaimed (`name_in_use`). Existing
 * connections stay open; the invite code no longer works.
 */
export class PuterPeerServerCloseEvent extends Event {
    /** @param {string} reason */
    constructor(reason: string);
    /**
     * Why the server stopped: `'replaced'` or `'name_in_use'`.
     *
     * @type {string}
     */
    reason: string;
}
/**
 * Dispatched by `PuterPeerConnection` for the `'message'` event when a message
 * is received.
 */
export class PuterPeerConnectionMessageEvent extends Event {
    /** @param {ArrayBuffer | string} message */
    constructor(message: ArrayBuffer | string);
    /**
     * The received message payload.
     *
     * @type {ArrayBuffer | string}
     */
    data: ArrayBuffer | string;
}
/**
 * Dispatched by `PuterPeerConnection` for the `'open'` event when the data
 * channel is ready.
 */
export class PuterPeerConnectionOpenEvent extends Event {
    constructor();
}
/**
 * Dispatched by `PuterPeerConnection` for the `'close'` event when the
 * connection closes.
 */
export class PuterPeerConnectionCloseEvent extends Event {
    /** @param {string} [reason] */
    constructor(reason?: string);
    /**
     * The reason the connection was closed, if one was provided.
     *
     * @type {string | undefined}
     */
    reason: string | undefined;
}
/**
 * Dispatched by `PuterPeerConnection` for the `'error'` event when a connection
 * error occurs.
 */
export class PuterPeerConnectionErrorEvent extends Event {
    /** @param {Error & { code?: string } | string} error */
    constructor(error: (Error & {
        code?: string;
    }) | string);
    /**
     * The error. When the signaller refused the connection this is an `Error`
     * whose `code` names why: `no_host` (a room nobody is serving right now),
     * `invalid_invite` (an invite code that is not live), `invalid_auth`.
     *
     * @type {Error & { code?: string } | string}
     */
    error: (Error & {
        code?: string;
    }) | string;
}
export class PuterPeerServer extends EventTarget {
    constructor(peerConfig: any);
    connections: Map<any, any>;
    /**
     * The invite code to share with other clients so they can connect. For a
     * server started with a `name`, this is the name.
     *
     * @type {string | undefined}
     */
    inviteCode: string | undefined;
    /**
     * Opens the signalling connection and registers this server, resolving to
     * the invite code other clients connect with (also kept on `inviteCode`).
     * `puter.peer.serve()` calls this.
     *
     * @param {PuterPeerOptions} [options]
     * @returns {Promise<string>}
     */
    start(options?: PuterPeerOptions): Promise<string>;
    /**
     * Replaces the guest grant handed to clients that connect from now on.
     * Pass a fresh grant before the previous one expires so guests joining
     * hours into a session still get relays.
     *
     * @param {string | null} grant
     * @returns {void}
     */
    setGuestGrant(grant: string | null): void;
    /**
     * Closes every client connection, then the signalling connection.
     *
     * @returns {void}
     */
    close(): void;
    #private;
}
/**
 * A WebRTC data-channel connection to a peer. Emits `'open'`, `'message'`,
 * `'close'`, and `'error'` events.
 */
export class PuterPeerConnection extends EventTarget {
    constructor(peerConfig: any);
    peerconnection: RTCPeerConnection;
    /**
     * Information about the user who created the server.
     *
     * @type {PuterPeerUser | undefined}
     */
    owner: PuterPeerUser | undefined;
    /**
     * The room name this connection was made in, when the server was reached
     * by name.
     *
     * @type {string | undefined}
     */
    room: string | undefined;
    connected: boolean;
    closed: boolean;
    /**
     * Connects to the server that issued `invitecode` — or serves the room of
     * that name — resolving once the offer has been exchanged.
     * `puter.peer.connect()` calls this.
     *
     * @param {string} invitecode
     * @param {PuterPeerOptions} [options]
     * @returns {Promise<void>}
     */
    connect(invitecode: string, options?: PuterPeerOptions): Promise<void>;
    /**
     * Closes the connection, optionally telling the peer why.
     *
     * @param {string} [reason]
     * @returns {void}
     */
    close(reason?: string): void;
    /**
     * Creates an SDP offer and applies it as the local description.
     *
     * @returns {Promise<RTCSessionDescriptionInit>}
     */
    createOffer(): Promise<RTCSessionDescriptionInit>;
    /**
     * Creates an SDP answer and applies it as the local description.
     *
     * @returns {Promise<RTCSessionDescriptionInit>}
     */
    createAnswer(): Promise<RTCSessionDescriptionInit>;
    /**
     * Applies the peer's SDP description.
     *
     * @param {RTCSessionDescriptionInit} description
     * @returns {Promise<void>}
     */
    setRemoteDescription(description: RTCSessionDescriptionInit): Promise<void>;
    /**
     * Adds an ICE candidate received from the peer.
     *
     * @param {RTCIceCandidateInit} candidate
     * @returns {Promise<void>}
     */
    addIceCandidate(candidate: RTCIceCandidateInit): Promise<void>;
    /**
     * Sends a message over the data channel. Messages sent before the channel
     * opens are buffered and flushed on open.
     *
     * @param {PuterPeerMessage} message
     * @returns {void}
     */
    send(message: PuterPeerMessage): void;
    #private;
}
/**
 * The `puter.peer` API. Provides WebRTC data channels with built-in signaling
 * and TURN relays for connecting clients directly without your own signaling
 * server.
 *
 * Hosting a session requires authentication. Guests can join one without an
 * account by passing `anonToken`, and reach the Puter-managed relays with a
 * `turnGrant` the host issued via `createGuestGrant()` — relay usage is
 * charged to the host that issued it.
 *
 * A server is reached either by the invite code it was handed, good for as
 * long as it serves, or by a room name it chose (`serve({ name })`), which
 * anyone can dial as `connect(name)` for as long as someone serves it.
 */
export class PeerModule extends PuterModule {
    /**
     * Creates a grant that lets guests without a Puter session use the
     * Puter-managed relays. Requires authentication.
     *
     * Hand the grant to the people you invite — alongside the invite code —
     * and they pass it to `connect()` as `turnGrant`. Their relay usage counts
     * against this account, so treat the grant as something that spends your
     * allowance: share it with the session you meant to host, and let it
     * expire rather than reusing one indefinitely.
     *
     * @returns {Promise<{ grant: string, expiresAt: number }>} The grant, and
     * when it stops being accepted (seconds since the epoch).
     */
    createGuestGrant(): Promise<{
        grant: string;
        expiresAt: number;
    }>;
    /**
     * Fetches TURN relay credentials ahead of time so connections start
     * faster. Optional — `serve()` and `connect()` call it when needed — and
     * it resolves either way: if relays can't be loaded, connecting falls back
     * to the default ICE servers.
     *
     * With `turnGrant`, credentials are minted against the granting account
     * instead of the caller's own session, which is how a guest gets relays
     * without signing in.
     *
     * @param {Object} [options]
     * @param {string} [options.turnGrant] A grant from `createGuestGrant()`.
     * @returns {Promise<void>}
     */
    ensureTurnRelays(options?: {
        turnGrant?: string | undefined;
    }): Promise<void>;
    /**
     * Creates a peer server and starts it, resolving to the server once it has
     * an invite code. Requires authentication, unless `anonToken` is supplied.
     *
     * With `name`, the server is reached by that room name instead of a
     * generated code — the same name every time it serves, so the address can
     * be shared ahead of time and reused.
     *
     * @param {PuterPeerOptions} [options]
     * @returns {Promise<PuterPeerServer>}
     */
    serve(options?: PuterPeerOptions): Promise<PuterPeerServer>;
    /**
     * Connects to a peer server — by the invite code from `serve()`, or by
     * the room name it serves under — resolving once the offer has been
     * exchanged. Requires authentication, unless `anonToken` is supplied to
     * join without a session; pair it with a `turnGrant` from the host so the
     * connection can still use relays, or leave that to the host, whose
     * `guestGrant` reaches the guest through the signaller.
     *
     * @param {string} invitecode
     * @param {PuterPeerOptions} [options]
     * @returns {Promise<PuterPeerConnection>}
     */
    connect(invitecode: string, options?: PuterPeerOptions): Promise<PuterPeerConnection>;
    #private;
}
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 *
 * @typedef {import('../lib/types.js').OmitMembers<
 *     typeof PeerModule,
 *     'puter' | 'authToken'
 * >} PeerConstructor
 */
export const Peer: PeerConstructor;
export default Peer;
/**
 * Options for `puter.peer.serve()` and `puter.peer.connect()`.
 */
export type PuterPeerOptions = {
    /**
     * Custom ICE servers (STUN/TURN) to use instead of the
     * Puter-managed relays.
     */
    iceServers?: RTCIceServer[] | undefined;
    /**
     * Route every candidate through a TURN relay.
     */
    forceRelay?: boolean | undefined;
    /**
     * Take part without a Puter session. Any uuid; it identifies this
     * guest for the duration of the session and skips the sign-in prompt.
     */
    anonToken?: string | undefined;
    /**
     * A grant from `puter.peer.createGuestGrant()`, letting a guest with
     * no session use the Puter-managed relays on the granting account's allowance.
     */
    turnGrant?: string | undefined;
    /**
     * `serve()` only: serve under a room name of your choosing instead of a
     * generated invite code. Clients reach the server with `connect(name)`. Lowercase letters, digits
     * and hyphens, 3–64 characters. The name is yours while you serve it, and free again once you stop;
     * serving a name that is currently held fails with `name_in_use` — unless the holder is you, in
     * which case the newer server takes over and the older one is closed.
     */
    name?: string | undefined;
    /**
     * `serve()` only: a grant from `puter.peer.createGuestGrant()`
     * handed to every guest that connects without a `turnGrant` of its own, so they reach the relays
     * without you having to deliver the grant some other way. Renew it with `server.setGuestGrant()`.
     */
    guestGrant?: string | undefined;
};
/**
 * Metadata about a peer user.
 */
export type PuterPeerUser = {
    username: string;
    uuid: string;
};
export type PuterPeerMessage = string | Blob | ArrayBuffer | ArrayBufferView;
export type PuterPeerDescription = RTCSessionDescription | RTCSessionDescriptionInit;
export type PuterPeerIceCandidate = RTCIceCandidate | RTCIceCandidateInit;
/**
 * The public face of the module: derived from the class, with the internal
 * `puter` handle and the legacy `authToken` accessor omitted.
 */
export type PeerConstructor = import("../lib/types.js").OmitMembers<typeof PeerModule, "puter" | "authToken">;
import { PuterModule } from '../lib/PuterModule.js';
