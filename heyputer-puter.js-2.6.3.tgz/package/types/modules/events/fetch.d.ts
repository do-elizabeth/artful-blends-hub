/** @typedef {import('./types.js').PuterNotifEvent} PuterNotifEvent */
/** @typedef {import('./types.js').EventFetchPage} EventFetchPage */
/** @typedef {import('./types.js').EventFetchOptions} EventFetchOptions */
/**
 * Reads what a subject recorded while nothing was listening.
 *
 * A plain query, not a subscription: nothing is registered, no position is kept
 * for you, and the same call from anywhere returns the same answer. Keep the
 * `cursor` a page comes back with and pass it as `after` to continue; a page
 * with no `cursor` is the end of what there is.
 *
 * Only subjects with a store behind them can answer. Today that is `notif:` —
 * the notification mailbox — and any other family is refused rather than
 * answered with an empty page, which would read as "nothing happened".
 *
 * A fetched event carries the same `id` as the live delivery of the same
 * notification, so a client that reconnects mid-catch-up can drop the
 * duplicate.
 *
 * @this {import('./index.js').EventsModule}
 * @param {EventFetchOptions} options
 * @returns {Promise<EventFetchPage>}
 */
export function fetch(this: import("./index.js").EventsModule, options: EventFetchOptions): Promise<EventFetchPage>;
export type PuterNotifEvent = import("./types.js").PuterNotifEvent;
export type EventFetchPage = import("./types.js").EventFetchPage;
export type EventFetchOptions = import("./types.js").EventFetchOptions;
