/**
 * Turning what a developer wrote into what gets deployed.
 *
 * A handler is not called where it is written — it is serialized, stored, and
 * run later in the app's events worker. So the three accepted forms all reduce
 * to one string, that string is scanned for anything it cannot carry with it,
 * and its hash goes along so the server can tell whether the code a
 * subscription was written against is still what is published.
 */
/** Hard cap on a subscription's serialized `context`, matching the column. */
export const CONTEXT_MAX_BYTES: 4096;
export function byteLength(text: any): number;
export function hashSource(source: string): Promise<string>;
export function asExpression(source: string): string;
export function sourceOf(handler: unknown): string | null;
export function resolveSource(puter: import("../../../index.js").Puter, handler: unknown): Promise<string>;
export function prepareHandler(puter: import("../../../index.js").Puter, handler: unknown): Promise<{
    source: string;
    hash: string;
}>;
export function serializeContext(context: unknown): string | undefined;
