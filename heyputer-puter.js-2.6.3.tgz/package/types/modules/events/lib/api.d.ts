/**
 * @param {import('../../../index.js').Puter} puter
 * @param {string} route
 * @param {Record<string, unknown>} [body] Present makes it a POST.
 * @param {Record<string, string | number | boolean>} [query]
 * @returns {Promise<Record<string, unknown>>}
 */
export function request(puter: import("../../../index.js").Puter, route: string, body?: Record<string, unknown>, query?: Record<string, string | number | boolean>): Promise<Record<string, unknown>>;
