export function assertSubject(subject: unknown): void;
export function assertHandler(handler: unknown): void;
