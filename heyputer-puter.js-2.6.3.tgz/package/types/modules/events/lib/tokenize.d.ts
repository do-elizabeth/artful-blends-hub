export function tokenize(source: string): Token[];
export type Token = {
    type: "name" | "num" | "punct";
    value: string;
};
