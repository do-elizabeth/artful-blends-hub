export class EventHandlers {
    /** @param {import('../index.js').EventsModule} module */
    constructor(module: import("../index.js").EventsModule);
    /** @internal */
    module: import("../index.js").EventsModule;
    /**
     * @internal The hash last seen published, keyed by app and name — the
     *   base a publish claims it is updating. Empty until this client has
     *   published or listed, which is what makes a first publish
     *   create-or-idempotent. Keyed by app as well as name because one
     *   name means different code in two apps.
     * @type {Map<string, string>}
     */
    known: Map<string, string>;
    /**
     * Publishes one named handler.
     *
     * @param {string} name The name subscriptions bind to.
     * @param {Function | string | { file: string }} handler The handler: a
     *   function (serialized with `toString()`), its source, or a path to read
     *   it from. A file resolves now, not at delivery.
     * @param {HandlerOptions} [options]
     * @returns {Promise<PublishedHandler>}
     */
    publish(name: string, handler: Function | string | {
        file: string;
    }, options?: HandlerOptions): Promise<PublishedHandler>;
    /**
     * Publishes a set of handlers in one call — what a build step has. Items
     * are taken in order, and one the server refuses stops the pass, so a
     * deploy never reports success over a half-published set.
     *
     * @param {HandlerPublication[]} handlers
     * @param {HandlerOptions} [options]
     * @returns {Promise<PublishedHandler[]>}
     */
    publishAll(handlers: HandlerPublication[], options?: HandlerOptions): Promise<PublishedHandler[]>;
    /**
     * What this app has published: names, source hashes, and how many
     * subscriptions each is carrying. Never the source.
     *
     * @param {HandlerOptions} [options]
     * @returns {Promise<HandlerSummary[]>}
     */
    list(options?: HandlerOptions): Promise<HandlerSummary[]>;
    /**
     * Removes a name. With nothing bound to it the handler simply goes; with
     * subscriptions on it they are **suspended**, not deleted, and publishing
     * the name again resumes them.
     *
     * @param {string} name
     * @param {HandlerOptions} [options]
     * @returns {Promise<{ name: string, removed: boolean, suspended: number }>}
     */
    remove(name: string, options?: HandlerOptions): Promise<{
        name: string;
        removed: boolean;
        suspended: number;
    }>;
    /**
     * @internal Drop every cached publish base for an app, after something
     *   removed its whole set. Sending a base for a name that is gone is what
     *   makes the next publish look like a lost race. The implicit-app keys go
     *   too: those are an app token's own app, which is the only app it can
     *   have emptied.
     * @param {string} appUid
     */
    forget(appUid: string): void;
    #private;
}
export type PublishedHandler = import("../types.js").PublishedHandler;
export type HandlerSummary = import("../types.js").HandlerSummary;
export type HandlerOptions = import("../types.js").HandlerOptions;
export type HandlerPublication = import("../types.js").HandlerPublication;
