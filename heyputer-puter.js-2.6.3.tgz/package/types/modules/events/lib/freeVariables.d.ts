/**
 * Names the runtime provides. Curated rather than derived from `globalThis`:
 * the handler runs in a worker isolate, not in the environment doing the scan,
 * so what is present here says nothing about what is present there.
 */
export const HANDLER_GLOBALS: Set<string>;
export function collectBindings(tokens: import("./tokenize.js").Token[]): Set<string>;
export function collectReferences(tokens: import("./tokenize.js").Token[]): string[];
export function scanHandlerSource(source: string): {
    bound: Set<string>;
    references: string[];
};
