/** @typedef {import('../types.js').EventAnchor} EventAnchor */
/** @typedef {import('../types.js').EventGapMarker} EventGapMarker */
/** @typedef {import('../types.js').EventHandler} EventHandler */
/** @typedef {import('../types.js').PuterEvent} PuterEvent */
/** @typedef {import('../types.js').PuterKvEvent} PuterKvEvent */
/**
 * A live subscription, as returned by `puter.events.onLocal()`.
 *
 * The handle survives reconnects: the connection dying takes the server's
 * subscription with it, the SDK makes a new one, and this object keeps
 * pointing at it — with a new `subId`, which is why nothing should be stored
 * against that id.
 */
export class EventSubscription {
    /**
     * @internal
     * @param {import('./channel.js').EventChannel} channel
     * @param {string} subject
     * @param {EventHandler} handler
     * @param {{ onError?: (error: Error & { code?: string }) => void, timeout?: number }} options
     */
    constructor(channel: import("./channel.js").EventChannel, subject: string, handler: EventHandler, options?: {
        onError?: (error: Error & {
            code?: string;
        }) => void;
        timeout?: number;
    });
    /** The subject this was subscribed with. */
    subject: string;
    /**
     * The server's id for the current subscription, or `null` while the
     * connection is down. Changes on every reconnect.
     *
     * @type {string | null}
     */
    subId: string | null;
    /**
     * The node the subscription is keyed to, which is the nearest existing
     * ancestor when the subject named something that does not exist yet.
     *
     * @type {EventAnchor | null}
     */
    anchor: EventAnchor | null;
    /**
     * The pattern events under the anchor are matched against, or `null` when
     * the subject named the anchor itself.
     *
     * @type {string | null}
     */
    match: string | null;
    /**
     * The single operation this subscription is limited to, or `null` for all
     * of them.
     *
     * @type {string | null}
     */
    op: string | null;
    /** @internal @type {import('./channel.js').EventChannel} */
    channel: import("./channel.js").EventChannel;
    /** @internal @type {EventHandler} */
    handler: EventHandler;
    /** @internal @type {((error: Error & { code?: string }) => void) | undefined} */
    onError: ((error: Error & {
        code?: string;
    }) => void) | undefined;
    /** @internal @type {number | undefined} */
    timeout: number | undefined;
    /** @internal Set while a subscribe for this handle is in flight. */
    pending: boolean;
    /**
     * Ends the subscription. Routing stops immediately; the server is told
     * when there is still a connection to tell it over. Safe to call more than
     * once, and after the connection has gone away — it never throws.
     *
     * @returns {Promise<void>}
     */
    off(): Promise<void>;
    /**
     * @internal
     * @param {PuterEvent | PuterKvEvent | EventGapMarker} event
     * @param {Record<string, unknown>} [ctx] The subscription's stored
     *   context, which the handler must not be able to mutate: it is one
     *   snapshot shared across every delivery.
     * @returns {void}
     */
    deliver(event: PuterEvent | PuterKvEvent | EventGapMarker, ctx?: Record<string, unknown>): void;
    /**
     * @internal
     * @param {{ subId: string, anchor?: EventAnchor, match?: string | null, op?: string | null }} view
     * @returns {void}
     */
    apply(view: {
        subId: string;
        anchor?: EventAnchor;
        match?: string | null;
        op?: string | null;
    }): void;
}
export type EventAnchor = import("../types.js").EventAnchor;
export type EventGapMarker = import("../types.js").EventGapMarker;
export type EventHandler = import("../types.js").EventHandler;
export type PuterEvent = import("../types.js").PuterEvent;
export type PuterKvEvent = import("../types.js").PuterKvEvent;
