export class EventsWorkers {
    /** @param {import('../index.js').EventsModule} module */
    constructor(module: import("../index.js").EventsModule);
    /** @internal */
    module: import("../index.js").EventsModule;
    /**
     * The caller's own events workers, one per app it owns with at least one
     * published handler.
     *
     * @param {EventsWorkersListOptions} [options]
     * @returns {Promise<EventsWorkerPage>}
     */
    list(options?: EventsWorkersListOptions): Promise<EventsWorkerPage>;
    /**
     * Removes every handler an app has published, taking its events worker
     * down with the last one. Subscriptions bound to them are **suspended**,
     * the same as removing each by name — never deleted.
     *
     * @param {string} appUid
     * @returns {Promise<DestroyedEventsWorker>}
     */
    destroy(appUid: string): Promise<DestroyedEventsWorker>;
}
export type EventsWorkersListOptions = import("../types.js").EventsWorkersListOptions;
export type EventsWorkerPage = import("../types.js").EventsWorkerPage;
export type DestroyedEventsWorker = import("../types.js").DestroyedEventsWorker;
