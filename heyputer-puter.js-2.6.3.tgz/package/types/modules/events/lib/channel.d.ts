/** How long a verb waits for its ack before the call is called lost. */
export const DEFAULT_TIMEOUT_MS: 30000;
/**
 * The one connection every subscription rides on, and the routing table that
 * makes one socket serve all of them.
 *
 * Opened by the first subscription and closed by the last, so an app that
 * never subscribes never connects. Session subscriptions die with the socket,
 * so a reconnect is not transparent server-side — this re-issues each live
 * subscription and re-points its handle at the new id, which is what keeps
 * `onLocal` a thing you call once.
 *
 * A persistent subscription is the other way round: the server holds it, its
 * id outlives every connection, and what a reconnect has to rebuild is only
 * this side's routing — so those registrations are kept apart from the session
 * ones and are never re-subscribed.
 */
export class EventChannel {
    /** @param {import('../index.js').EventsModule} module */
    constructor(module: import("../index.js").EventsModule);
    /** @internal */
    module: import("../index.js").EventsModule;
    /** @internal @type {import('socket.io-client').Socket | null} */
    socket: import("socket.io-client").Socket | null;
    /** @internal @type {Set<EventSubscription>} */
    subscriptions: Set<EventSubscription>;
    /** @internal @type {Map<string, EventSubscription>} */
    byId: Map<string, EventSubscription>;
    /**
     * @internal Persistent subscriptions this client is running the
     *   handler for, by their server-side id.
     * @type {Map<string, DurableRegistration>}
     */
    durable: Map<string, DurableRegistration>;
    /** @internal Rejectors for verbs still waiting on an ack. */
    waiters: Set<any>;
    /** @internal Subscribes that have not resolved yet. */
    inflight: number;
    /**
     * @internal Bumped every time the connection goes away, so a request
     *   that failed with it can be told from one a live connection
     *   refused.
     */
    generation: number;
    /** @internal @type {ReturnType<typeof setTimeout> | null} */
    retryTimer: ReturnType<typeof setTimeout> | null;
    /**
     * @internal
     * @param {string} subject
     * @param {EventHandler} handler
     * @param {OnLocalOptions} options
     * @returns {Promise<EventSubscription>}
     */
    subscribe(subject: string, handler: EventHandler, options: OnLocalOptions): Promise<EventSubscription>;
    /**
     * @internal
     * @param {EventSubscription} sub
     * @returns {Promise<void>}
     */
    remove(sub: EventSubscription): Promise<void>;
    /**
     * Run a persistent subscription's handler here whenever this client is the
     * one the server delivers to. The subscription itself already exists and is
     * not re-registered by any of this — what is registered is only where its
     * deliveries go while this page is open.
     *
     * @internal
     * @param {string} subId
     * @param {import('../types.js').EventHandler} handler
     * @param {Record<string, unknown>} [ctx] The context the subscription was
     *   created with, delivered frozen alongside every event.
     * @returns {void}
     */
    registerDurable(subId: string, handler: import("../types.js").EventHandler, ctx?: Record<string, unknown>): void;
    /**
     * Stop routing a persistent subscription here. The subscription is
     * untouched — ending it is `unsubscribe()`, which is a different thing from
     * this page no longer running its handler.
     *
     * @internal
     * @param {string} subId
     * @returns {void}
     */
    deregisterDurable(subId: string): void;
    /**
     * Rebuild the connection against the current token and origin. Live
     * subscriptions are re-issued once it is up.
     *
     * @internal
     * @returns {void}
     */
    reset(): void;
    /**
     * @internal
     * @returns {import('socket.io-client').Socket}
     */
    connect(): import("socket.io-client").Socket;
    /**
     * @internal
     * @param {string} verb
     * @param {Record<string, unknown>} payload
     * @param {number} timeoutMs
     * @returns {Promise<VerbAck>}
     */
    request(verb: string, payload: Record<string, unknown>, timeoutMs: number): Promise<VerbAck>;
    /**
     * The server dropped every subscription this socket held when it went
     * away, so nothing here has a server-side id until it is re-issued — and
     * nothing that was waiting on an ack is going to get one.
     *
     * @internal
     * @returns {void}
     */
    orphan(): void;
    /**
     * @internal
     * @returns {void}
     */
    resubscribe(): void;
    /**
     * Run `resubscribe` again once the call budget has had time to refill.
     * One timer covers every subscription that was turned away.
     *
     * @internal
     * @param {number} generation
     * @returns {void}
     */
    retryResubscribe(generation: number): void;
    /**
     * @internal
     * @param {{ subId?: string, event?: unknown, ackRequired?: boolean, ackId?: string }} envelope
     * @returns {void}
     */
    route(envelope: {
        subId?: string;
        event?: unknown;
        ackRequired?: boolean;
        ackId?: string;
    }): void;
    /**
     * Run a persistent subscription's handler on one delivery.
     *
     * The handler is handed the same environment its published copy gets in the
     * app's events worker, so one body runs unchanged in either place. A
     * delivery owed to exactly one consumer carries `ack`: calling it settles
     * the delivery, resolving without calling it settles it anyway, and
     * throwing settles nothing — the lease lapses and it is delivered again.
     *
     * @internal
     * @param {DurableRegistration} registration
     * @param {{ event?: unknown, ackRequired?: boolean, ackId?: string, origin?: string }} envelope
     * @returns {void}
     */
    runDurable(registration: DurableRegistration, envelope: {
        event?: unknown;
        ackRequired?: boolean;
        ackId?: string;
        origin?: string;
    }): void;
    /**
     * Tell the server a delivery was taken. Best effort: a lost ack is a
     * redelivery, which `single` callers are told to expect, and there is
     * nothing a failure here leaves for the caller to fix.
     *
     * @internal
     * @param {string} subId
     * @param {string} ackId
     * @param {string} [origin] Echoed back untouched: it names whichever
     *   deployment is holding the delivery, which need not be the one this
     *   connection reached.
     * @returns {Promise<void>}
     */
    ack(subId: string, ackId: string, origin?: string): Promise<void>;
    /**
     * The connection is not coming back: fail what is waiting on it and end
     * every subscription it was carrying.
     *
     * @internal
     * @param {PuterJSError} error
     * @returns {void}
     */
    fail(error: PuterJSError): void;
    /**
     * @internal
     * @param {EventSubscription} sub
     * @param {PuterJSError} error
     * @returns {void}
     */
    lapse(sub: EventSubscription, error: PuterJSError): void;
    /**
     * @internal
     * @param {EventSubscription} sub
     * @returns {void}
     */
    forget(sub: EventSubscription): void;
    /**
     * @internal
     * @param {PuterJSError} error
     * @returns {void}
     */
    rejectWaiters(error: PuterJSError): void;
    /**
     * Best-effort removal of a subscription no handle points at any more.
     *
     * @internal
     * @param {string} subId
     * @param {number} timeoutMs
     * @returns {void}
     */
    dropOnServer(subId: string, timeoutMs: number): void;
    /**
     * @internal
     * @returns {void}
     */
    closeIfIdle(): void;
    /**
     * @internal
     * @returns {void}
     */
    close(): void;
}
export type EventGapMarker = import("../types.js").EventGapMarker;
export type EventHandler = import("../types.js").EventHandler;
export type OnLocalOptions = import("../types.js").OnLocalOptions;
export type PuterEvent = import("../types.js").PuterEvent;
export type PuterKvEvent = import("../types.js").PuterKvEvent;
/**
 * What the server says a subscription is, in its `subscribe` ack.
 */
export type SubscriptionView = {
    subId: string;
    subject: string;
    anchor: import("../types.js").EventAnchor;
    match: string | null;
    op: string | null;
};
export type VerbAck = {
    ok: true;
    sub?: SubscriptionView;
};
/**
 * One persistent subscription this client runs the handler for.
 */
export type DurableRegistration = {
    subId: string;
    handler: import("../types.js").EventHandler;
    ctx: Readonly<Record<string, unknown>>;
};
import { EventSubscription } from './subscription.js';
import { PuterJSError } from '../../../lib/PuterJSError.js';
