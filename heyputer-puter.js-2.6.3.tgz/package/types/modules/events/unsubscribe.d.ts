/**
 * Ends a persistent subscription.
 *
 * An id this account does not hold — one already ended, or one another app
 * created — reads as absent rather than refused, so the call cannot be used to
 * find out which subscriptions exist.
 *
 * @this {import('./index.js').EventsModule}
 * @param {string} subId The `subId` of the subscription to end.
 * @returns {Promise<void>}
 */
export function unsubscribe(this: import("./index.js").EventsModule, subId: string): Promise<void>;
