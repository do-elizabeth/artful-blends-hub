/** @typedef {import('./types.js').OnPersistentOptions} OnPersistentOptions */
/** @typedef {import('./types.js').PersistentSubscription} PersistentSubscription */
/**
 * Subscribes to a subject with a subscription that outlives this connection.
 *
 * Unlike `onLocal()`, the subscription is stored against the account, keeps
 * matching while the app is closed, and is ended by
 * `puter.events.unsubscribe()` rather than by navigating away. What runs it
 * while nothing is open is the app's published handler, named by `handlerName`.
 *
 * While this client *is* open it runs the handler itself, if one was passed as
 * a function: the same body, the same `{ event, ctx }`, plus `user`, `fetch`
 * and — for a subscription owed to one consumer — `ack`.
 *
 * `context` is evaluated **here, now** — serialized once and delivered to every
 * invocation as a frozen `ctx`. It never re-evaluates, so a value read from the
 * environment is the value that subscription carries forever.
 *
 * @this {import('./index.js').EventsModule}
 * @param {OnPersistentOptions} options
 * @returns {Promise<PersistentSubscription>}
 */
export function onPersistent(this: import("./index.js").EventsModule, options?: OnPersistentOptions): Promise<PersistentSubscription>;
export type OnPersistentOptions = import("./types.js").OnPersistentOptions;
export type PersistentSubscription = import("./types.js").PersistentSubscription;
