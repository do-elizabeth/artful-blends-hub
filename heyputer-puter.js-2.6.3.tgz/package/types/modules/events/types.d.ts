/**
 * What a subscription is keyed to. For an `fs:` subject naming something that
 * does not exist yet, this is the nearest existing ancestor and the rest of the
 * subject became `match`. For a `kv:` subject there is no node: `uid` is the app
 * whose store is watched and `path` is the key prefix it anchors at; for one made
 * through a share handle, `uid` is the handle and `path` is empty.
 */
export type EventAnchor = {
    /**
     * The anchor node's uid, or the watched app's id.
     */
    uid: string;
    /**
     * The anchor node's absolute path, or the key prefix.
     */
    path: string;
};
/**
 * One filesystem change, as the server projects it. Nothing internal is
 * included: a subscriber gets the node, when it happened, and whether it was
 * their own doing.
 */
export type PuterEvent = {
    /**
     * Unique id for this event. Stable across the
     * subscriptions it was delivered to.
     */
    id: string;
    /**
     * The subject the delivery was projected onto,
     * naming the node it happened to — `fs:<uid>:<op>`. Not the subject string
     * you subscribed with.
     */
    subject: string;
    /**
     * What happened.
     * `move` covers a move and an in-place rename.
     */
    op: "add" | "write" | "move" | "remove" | "meta";
    /**
     * The uid of the node the event is about.
     */
    uid: string;
    /**
     * The path of the node the event is about.
     */
    path: string;
    /**
     * On a `move`, the path the node left — present only
     * when the subscription was watching that side.
     */
    from?: string | undefined;
    /**
     * `true` when the change was made by the account
     * holding the subscription — the flag to check to ignore your own writes.
     */
    self: boolean;
    /**
     * Milliseconds since the epoch.
     */
    ts: number;
    /**
     * Position within one dispatch, for events that fan out
     * to several subscriptions at once.
     */
    seq: number;
};
/**
 * One key-value change. It carries `key` where a filesystem event carries `uid`
 * and `path` — a KV change happens to a key in a store, and there is no node to
 * name — and never the new value, so a delivery cannot become a read.
 */
export type PuterKvEvent = {
    /**
     * Unique id for this event.
     */
    id: string;
    /**
     * `kv:<appId>:<key>`, naming the key that changed.
     */
    subject: string;
    /**
     * `set` for a write, `del` for a
     * removal, `expire` when only the key's lifetime changed.
     */
    op: "set" | "del" | "expire";
    /**
     * The key the event is about.
     */
    key: string;
    /**
     * `true` when the change was made by the account
     * holding the subscription.
     */
    self: boolean;
    /**
     * Milliseconds since the epoch.
     */
    ts: number;
    /**
     * Position within one dispatch, for events that fan out
     * to several subscriptions at once.
     */
    seq: number;
};
/**
 * One notification, as the events layer projects it. The same object whether it
 * arrived live or came back from `fetch()`, and `id` is the notification's own
 * uid on both — which is what lets a client that reconnects mid-catch-up drop
 * the copy it already has.
 */
export type PuterNotifEvent = {
    /**
     * The notification's uid, and the dedup key.
     */
    id: string;
    /**
     * `notif:<appId|userId>:<audience>`, naming the
     * slice of the mailbox it belongs to.
     */
    subject: string;
    /**
     * Always `'post'` — the mailbox verbs (marking one read
     * or dismissed) are their own surface, not events.
     */
    op: "post";
    /**
     * The notification's uid, as the mailbox names it.
     */
    uid: string;
    /**
     * What kind of notification it is, from the published
     * catalog — `share.received`, `app.worker.deployed`, and so on.
     */
    type: string;
    /**
     * Who the recipient
     * is in relation to it: their account, an app they own, or an app they use.
     */
    audience: "account" | "developer" | "app-user";
    /**
     * The app it is about, or `null` for one from
     * the platform itself.
     */
    appUid: string | null;
    /**
     * The payload — `title`,
     * `text`, `icon`, `fields` — exactly as the desktop receives it.
     */
    notification: Record<string, unknown>;
    /**
     * Always `true`: a mailbox is your own.
     */
    self: boolean;
    /**
     * When it was created, in milliseconds since the epoch.
     */
    ts: number;
    /**
     * Position within one dispatch.
     */
    seq: number;
};
/**
 * Options for {@link import ('./fetch.js').fetch}.
 */
export type EventFetchOptions = {
    /**
     * What to read. Only `notif:` subjects have a store
     * behind them — `notif:account` for your account's notifications,
     * `notif:app-user` for an app's own, or `notif:<appId>:<audience>` in full.
     */
    subject: string;
    /**
     * The `cursor` from the previous page. Absent starts
     * from the oldest notification still kept.
     */
    after?: string | undefined;
    /**
     * Events per page. Capped at 200; defaults to 50.
     */
    limit?: number | undefined;
};
/**
 * One page of missed events.
 */
export type EventFetchPage = {
    /**
     * The events, oldest first.
     */
    items: PuterNotifEvent[];
    /**
     * Pass as `after` to read the next page. Absent
     * means there is nothing after this page — for now.
     */
    cursor?: string | undefined;
};
/**
 * Stands in for events that happened and were not delivered — a per-event
 * ceiling was hit, or deliveries were coming faster than the subscription's
 * allowance. It carries no `uid` or `path`, because what was dropped is
 * exactly what it cannot name: treat it as "re-read the anchor", never as
 * "nothing changed".
 */
export type EventGapMarker = {
    /**
     * Unique id for the dispatch the gap happened in.
     */
    id: string;
    /**
     * The subject that was being delivered.
     */
    subject: string;
    /**
     * Always `'gap'`.
     */
    op: "gap";
    /**
     * Why the delivery was dropped —
     * `matched_subscription_limit`, `filter_evaluation_limit`,
     * `delivery_rate_limit`, `backlog_overflow` when undelivered events were
     * shed to stay inside a backlog cap, `suspended_backlog_expired` when a
     * suspended subscription held them past its deadline, or `handler_rejected`
     * when the subscription's handler refused the delivery outright.
     */
    reason: string;
    /**
     * Milliseconds since the epoch.
     */
    ts: number;
};
/**
 * What a handler is called with. An object rather than the event itself, so
 * more can be added to the call without breaking existing handlers.
 *
 * The last three arrive only on a persistent subscription, and are what let one
 * handler body run unchanged here and in the app's events worker.
 */
export type EventDelivery = {
    /**
     * The delivered
     * event, or a gap marker in place of events that were dropped.
     */
    event: PuterEvent | PuterKvEvent | EventGapMarker;
    /**
     * The `context` the
     * subscription was created with, frozen. Present only for a persistent
     * subscription; a session subscription carries none.
     */
    ctx?: Readonly<Record<string, unknown>> | undefined;
    /**
     * A `puter` bound to the account holding the
     * subscription — the ambient one when the handler runs in a client.
     */
    user?: unknown;
    /**
     * `puter.net.fetch` where it exists, the environment's `fetch` otherwise.
     */
    fetch?: ((input: unknown, init?: unknown) => Promise<unknown>) | undefined;
    /**
     * Settles the delivery. Present only on a
     * `single` subscription: calling it hands the delivery back as taken,
     * returning without calling it does the same, and throwing does neither — the
     * delivery is offered again when its lease lapses.
     */
    ack?: (() => Promise<void>) | undefined;
};
/**
 * A subscription handler. Its return value is ignored; a rejected promise is
 * reported and does not affect the subscription.
 */
export type EventHandler = (delivery: EventDelivery) => unknown;
/**
 * Options for {@link import ('./onLocal.js').onLocal}.
 */
export type OnLocalOptions = {
    /**
     * Called if
     * the subscription lapses — the connection was lost and re-subscribing
     * failed. The subscription is gone by then and the handler will not be
     * called again; subscribe again to resume. Without this, a lapse is reported
     * on the console.
     */
    onError?: ((error: Error & {
        code?: string;
    }) => void) | undefined;
    /**
     * How long to wait for the server to answer
     * `subscribe`, in milliseconds. Default `30000`.
     */
    timeout?: number | undefined;
};
/**
 * Options for {@link import ('./onPersistent.js').onPersistent}.
 */
export type OnPersistentOptions = {
    /**
     * What to watch — the same grammar `onLocal()`
     * takes, e.g. `fs:~/Documents` or `fs:~/inbox/*.json:add`.
     */
    subject: string;
    /**
     * `broadcast` (the default)
     * delivers to everything listening; `single` delivers to exactly one
     * consumer, which must acknowledge, and requires a `handlerName`.
     */
    delivery?: "broadcast" | "single" | undefined;
    /**
     * Transports the
     * deliveries may take. Defaults to `['socket', 'worker']`. A `single`
     * subscription may not target `push`.
     */
    targets?: ("socket" | "worker" | "push")[] | undefined;
    /**
     * The published handler this subscription
     * binds to. Required for `single`.
     */
    handlerName?: string | undefined;
    /**
     * The handler
     * source this subscription was written against. Sent as a hash, not as
     * source: the subscription binds only if it matches what is published under
     * `handlerName`, which is also required when this is given.
     */
    handler?: string | Function | {
        file: string;
    } | undefined;
    /**
     * Values the handler needs,
     * evaluated **now** and delivered as a frozen `ctx` on every invocation.
     * Capped at 4 KB serialized.
     */
    context?: Record<string, unknown> | undefined;
    /**
     * When the subscription ends by
     * itself — unix seconds or an ISO-8601 string, and it has to be in the
     * future.
     */
    expiresAt?: string | number | undefined;
};
/**
 * A subscription that outlives the connection that made it.
 *
 * `context` values are deliberately absent: the column holds whatever secret
 * the handler needs, and a listing is the one surface an app can call
 * repeatedly. What comes back is its shape — which keys are set, and a hash
 * that changes when any value does.
 */
export type PersistentSubscription = {
    /**
     * The subscription's id, and what `unsubscribe()`
     * names. Stable for the life of the subscription.
     */
    subId: string;
    /**
     * The subject it was created with.
     */
    subject: string;
    /**
     * The node it is keyed to.
     */
    anchor: EventAnchor;
    /**
     * The pattern events under the anchor are
     * matched against, or `null` when the subject named the anchor itself.
     */
    match: string | null;
    /**
     * The single operation it is limited to, or
     * `null` for all of them.
     */
    op: string | null;
    /**
     * Transports its
     * deliveries may take.
     */
    targets: Array<"socket" | "worker" | "push">;
    /**
     * Its delivery class.
     */
    delivery: "broadcast" | "single";
    /**
     * The handler it is bound to.
     */
    handlerName: string | null;
    /**
     * The app that created it, or `null` for one
     * an account session made.
     */
    appUid: string | null;
    /**
     * Key names of its stored context,
     * never the values, or `null` when it carries none.
     */
    contextKeys: string[] | null;
    /**
     * Hash of its stored context, so a
     * change is visible without the values.
     */
    contextHash: string | null;
    /**
     * Unix seconds.
     */
    createdAt: number;
    /**
     * Unix seconds, or `null` for one with no
     * end.
     */
    expiresAt: number | null;
    /**
     * When it stopped delivering without
     * being removed, or `null` while it is live.
     */
    suspendedAt: number | null;
    /**
     * Why it stopped —
     * `handler_not_found`, `failures`, `no_credit`, or `permission_revoked`.
     */
    suspendedReason: string | null;
    /**
     * Ends the subscription: stops running
     * its handler here and unsubscribes it. Present on the subscription
     * `onPersistent()` returns, not on one a listing reports.
     */
    off?: (() => Promise<void>) | undefined;
};
/**
 * Where a handler operation applies. An app token publishes into its own app
 * and needs neither field; an account session has to name an app it owns.
 */
export type HandlerOptions = {
    /**
     * Take the name whatever is published under it.
     * Without this, a publish whose base has moved is refused with
     * `events_handler_conflict`.
     */
    replace?: boolean | undefined;
    /**
     * The app to publish into. Required when the
     * caller is an account session rather than an app.
     */
    appUid?: string | undefined;
};
/**
 * One item of a `publishAll()` set.
 */
export type HandlerPublication = {
    /**
     * The name subscriptions bind to.
     */
    name: string;
    /**
     * The handler: a
     * function, its source, or a path to read it from.
     */
    handler: Function | string | {
        file: string;
    };
    /**
     * Take the name whatever is published under it.
     */
    replace?: boolean | undefined;
};
/**
 * What a publish reports back. Never the source.
 */
export type PublishedHandler = {
    name: string;
    /**
     * SHA-256 of the published source.
     */
    hash: string;
    /**
     * Unix seconds.
     */
    updatedAt: number;
    /**
     * What the publish
     * did. `unchanged` means the same source was already published.
     */
    outcome: "created" | "updated" | "unchanged";
    /**
     * Suspended subscriptions this publish brought
     * back into service.
     */
    resumed: number;
};
/**
 * One handler as `puter.events.handlers.list()` reports it.
 */
export type HandlerSummary = {
    name: string;
    /**
     * SHA-256 of the published source.
     */
    hash: string;
    /**
     * Unix seconds.
     */
    updatedAt: number;
    /**
     * How many subscriptions are bound to this
     * name, suspended ones included.
     */
    subscriptions: number;
};
/**
 * Options for `puter.events.workers.list()`.
 */
export type EventsWorkersListOptions = {
    /**
     * Apps per page.
     */
    limit?: number | undefined;
    /**
     * The `cursor` from a previous page. Absent starts
     * from the first page.
     */
    cursor?: string | undefined;
};
/**
 * One app of the caller's with published handlers — and so with an events
 * worker standing behind them.
 */
export type EventsWorkerSummary = {
    appUid: string;
    appName: string;
    appTitle: string;
    /**
     * How many handlers this app has published.
     */
    handlerCount: number;
    /**
     * When this app's events worker first came into
     * being — its earliest published handler. Unix seconds.
     */
    createdAt: number;
    /**
     * Its most recently published or updated handler.
     * Unix seconds.
     */
    updatedAt: number;
    /**
     * The deployed script name, for support/diagnosis.
     */
    script: string;
};
/**
 * One page of `puter.events.workers.list()`.
 */
export type EventsWorkerPage = {
    items: EventsWorkerSummary[];
    /**
     * Pass to read the next page. Absent means there
     * is no next page.
     */
    cursor?: string | undefined;
    /**
     * Whether this server actually deploys events
     * workers. `false` on a self-hosted install without the runtime turned on —
     * apps can still publish handlers, but nothing runs a background delivery.
     */
    deployable: boolean;
};
/**
 * What `puter.events.workers.destroy()` reports back.
 */
export type DestroyedEventsWorker = {
    appUid: string;
    /**
     * How many handlers were deleted.
     */
    removed: number;
    /**
     * How many subscriptions were suspended as a
     * result, across all of them.
     */
    suspended: number;
};
