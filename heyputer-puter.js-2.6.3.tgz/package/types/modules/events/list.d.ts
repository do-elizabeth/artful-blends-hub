/**
 * @overload
 * @param {import('../../lib/types.js').ListStreamOptions} options
 * @returns {AsyncIterableIterator<SubscriptionPage>}
 */
export function list(options: import("../../lib/types.js").ListStreamOptions): AsyncIterableIterator<SubscriptionPage>;
/**
 * @overload
 * @param {import('../../lib/types.js').ListPaginationOptions & ({ cursor: string | null } | { includeTotal: true })} options
 * @returns {Promise<SubscriptionPage>}
 */
export function list(options: import("../../lib/types.js").ListPaginationOptions & ({
    cursor: string | null;
} | {
    includeTotal: true;
})): Promise<SubscriptionPage>;
/**
 * @overload
 * @param {{ limit?: number }} [options]
 * @returns {Promise<PersistentSubscription[]>}
 */
export function list(options?: {
    limit?: number;
} | undefined): Promise<PersistentSubscription[]>;
export type PersistentSubscription = import("./types.js").PersistentSubscription;
export type SubscriptionPage = import("../../lib/types.js").ListPage<PersistentSubscription>;
