export default PuterDialog;
declare class PuterDialog extends HTMLElement {
    static messageID: number;
    /**
     * @param {Function} resolve - Resolves the implicit-auth promise.
     * @param {Function} reject - Rejects the implicit-auth promise.
     * @param {Object} [options] - Optional configuration.
     * @param {string} [options.popupURL] - When set, the dialog acts as a
     *   generic popup launcher: it opens this URL (instead of the default
     *   implicit-auth URL), skips the `puter.token` message handling and
     *   `puterAuthState` bookkeeping (the caller owns the auth result), and
     *   reports cancellation through `options.onCancel`.
     * @param {string} [options.popupName] - Window name for the popup. Give
     *   each concurrent launcher a distinct name: `window.open()` reuses a
     *   window that already carries the requested name, so sharing one name
     *   navigates (and hijacks) a popup another pending flow is waiting on.
     * @param {Function} [options.onLaunch] - Called with the opened popup
     *   window (or null if the browser blocked it) right after launch.
     * @param {Function} [options.onCancel] - Called when the user dismisses
     *   the dialog without completing authentication.
     */
    constructor(resolve: Function, reject: Function, options?: {
        popupURL?: string | undefined;
        popupName?: string | undefined;
        onLaunch?: Function | undefined;
        onCancel?: Function | undefined;
    });
    reject: Function;
    resolve: Function;
    options: {
        popupURL?: string | undefined;
        popupName?: string | undefined;
        onLaunch?: Function | undefined;
        onCancel?: Function | undefined;
    };
    messageListener: (event: any) => Promise<void>;
    cancelListener: () => void;
    connectedCallback(): void;
    authPopup: Window | null | undefined;
    open(): void;
    close(): void;
    #private;
}
