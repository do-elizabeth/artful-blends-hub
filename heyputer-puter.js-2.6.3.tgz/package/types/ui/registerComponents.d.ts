export function registerComponents(): void;
export default registerComponents;
