export default PuterContextMenu;
declare class PuterContextMenu extends PuterWebComponent {
    static _isMac(): boolean;
    set items(val: any[]);
    get items(): any[];
    _renderItems(items: any): any;
    _positionMenu(): void;
    _isMobile(): boolean;
    _showBackdrop(): void;
    _backdrop: HTMLDivElement | null | undefined;
    _hideBackdrop(): void;
    _bindEvents(): void;
    _outsideClickHandler: ((e: any) => void) | undefined;
    _keyHandler: ((e: any) => void) | undefined;
    _handleKey(e: any): boolean;
    _focusableIndices(): any[];
    _setFocusIndex(index: any): void;
    _clearFocus(): void;
    _itemEl(index: any): any;
    _moveFocus(delta: any): void;
    _activateFocused(): void;
    _openFocusedSubmenu(): boolean;
    _typeahead(char: any): boolean;
    _showSubmenu(parentEl: any, items: any): void;
    _sheetHidden: boolean | undefined;
    _scheduleSubmenuClose(): void;
    _cancelSubmenuClose(): void;
    _submenuCloseCheck(): void;
    _setSafeTraverse(on: any): void;
    _setKeyboardNav(on: any): void;
    _pointInRect(p: any, r: any): boolean;
    _pointInElement(p: any, el: any): boolean;
    _isMouseHeadingToSubmenu(submenu: any): boolean;
    _hideSubmenu(parentEl: any): void;
    _hideActiveSubmenu(restoreSelf?: boolean): void;
    _closeAll(): void;
    _closing: boolean | undefined;
    _escapeHTML(str: any): string;
    _escapeAttr(str: any): any;
    /**
     * Render a keyboard-shortcut string in OS-appropriate form.
     *
     *   Mac:  modifiers as glyphs, concatenated  →  ⇧⌘D
     *   Win/Linux:  text labels joined with '+'   →  Ctrl+Shift+D
     *
     * Accepts portable tokens (Mod, Cmd, Ctrl, Alt, Option, Shift, Meta) and
     * the literal Mac glyphs (⌘ ⌃ ⌥ ⇧). 'Mod' is the recommended portable
     * name — it maps to Cmd on Mac and Ctrl elsewhere.
     */
    _formatShortcut(str: any): string;
    _getActiveSubmenu(): null;
    /**
     * Returns true if a document-level event targets this menu or any
     * submenu nested below it. e.target on shadow-DOM-crossing events is
     * the submenu's host element, so we use contains() on each host in the
     * chain.
     */
    _isEventInChain(e: any): boolean;
    #private;
}
import PuterWebComponent from '../PuterWebComponent.js';
