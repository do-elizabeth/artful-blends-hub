export default PuterSpinner;
declare class PuterSpinner extends PuterWebComponent {
    _escapeHTML(str: any): string;
}
import PuterWebComponent from '../PuterWebComponent.js';
