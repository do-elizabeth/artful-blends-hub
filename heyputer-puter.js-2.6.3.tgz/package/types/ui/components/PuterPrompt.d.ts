export default PuterPrompt;
declare class PuterPrompt extends PuterWebComponent {
    set options(val: null);
    get options(): null;
    _escapeHTML(str: any): string;
    _escapeAttr(str: any): any;
    #private;
}
import PuterWebComponent from '../PuterWebComponent.js';
