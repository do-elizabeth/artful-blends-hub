export default PuterAlert;
declare class PuterAlert extends PuterWebComponent {
    set buttons(val: null);
    get buttons(): null;
    set options(val: null);
    get options(): null;
    _renderMessage(str: any): string;
    _escapeHTML(str: any): string;
    _escapeAttr(str: any): string;
    #private;
}
import PuterWebComponent from '../PuterWebComponent.js';
