export default PuterMenubar;
declare class PuterMenubar extends PuterWebComponent {
    set items(val: any[]);
    get items(): any[];
    _suppressClickFor: any;
    _keyHandler: ((e: any) => void) | undefined;
    _keyUpHandler: ((e: any) => void) | undefined;
    _docPointerDownHandler: ((e: any) => void) | undefined;
    _suppressClickTimer: NodeJS.Timeout | undefined;
    _docFocusInHandler: ((e: any) => void) | undefined;
    _winBlurHandler: (() => void) | undefined;
    _mouseMoveHandler: (() => void) | undefined;
    _onGlobalKeyDown(e: any): void;
    _onGlobalKeyUp(e: any): void;
    _activateMenubar(): void;
    _deactivateMenubar(): void;
    _renderButtonFocus(): void;
    _setKeyboardNav(on: any): void;
    _moveButtonFocus(delta: any, { swapDropdown, openDropdown }?: {
        swapDropdown?: boolean | undefined;
        openDropdown?: boolean | undefined;
    }): void;
    _buttonEl(index: any): any;
    _openFocusedButton(focusFirstItem: any): void;
    _openDropdown(buttonEl: any, item: any): void;
    _closeDropdown(): void;
    _escapeHTML(str: any): string;
    #private;
}
import PuterWebComponent from '../PuterWebComponent.js';
