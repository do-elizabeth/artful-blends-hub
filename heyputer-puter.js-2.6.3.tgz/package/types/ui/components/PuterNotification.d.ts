export default PuterNotification;
declare class PuterNotification extends PuterWebComponent {
    _dismissTimer: NodeJS.Timeout | undefined;
    _dismiss(): void;
    _dismissed: boolean | undefined;
    _escapeHTML(str: any): string;
    _escapeAttr(str: any): any;
}
import PuterWebComponent from '../PuterWebComponent.js';
