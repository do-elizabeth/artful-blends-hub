export default PuterColorPicker;
declare class PuterColorPicker extends PuterWebComponent {
    _setColor(color: any, opts?: {}): void;
    _normalizeHex(str: any): any;
    #private;
}
import PuterWebComponent from '../PuterWebComponent.js';
