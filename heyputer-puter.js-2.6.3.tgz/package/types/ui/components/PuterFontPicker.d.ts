export default PuterFontPicker;
declare class PuterFontPicker extends PuterWebComponent {
    _renderFontList(fonts: any): any;
    _escapeHTML(str: any): string;
    _escapeAttr(str: any): any;
    #private;
}
import PuterWebComponent from '../PuterWebComponent.js';
