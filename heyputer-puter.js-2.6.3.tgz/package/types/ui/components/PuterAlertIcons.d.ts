export namespace DEFAULT_ALERT_ICONS {
    let error: string;
    let warning: string;
    let info: string;
    let success: string;
    let confirm: string;
}
