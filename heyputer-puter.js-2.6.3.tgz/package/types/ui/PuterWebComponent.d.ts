export default PuterWebComponent;
/**
 * PuterWebComponent - Base class for all Puter web components.
 * Provides Shadow DOM setup, style injection, and common helpers.
 */
declare class PuterWebComponent extends HTMLElement {
    connectedCallback(): void;
    disconnectedCallback(): void;
    _setupThemeWatchers(): void;
    _themeObserver: MutationObserver | null | undefined;
    _themeMediaQuery: MediaQueryList | null | undefined;
    _themeMediaListener: (() => void) | null | undefined;
    _teardownThemeWatchers(): void;
    /**
     * Resolves the effective theme from the `theme` attribute and the system
     * preference, then toggles a `.puter-theme-dark` class on the host so
     * components can style with `:host(.puter-theme-dark) ...`.
     *   theme="dark"   → always dark
     *   theme="light"  → always light
     *   unset / other  → follow system (prefers-color-scheme)
     */
    _applyTheme(): void;
    _rerender(): void;
    /** Override in subclass: return CSS string */
    getStyles(): string;
    /** Override in subclass: return HTML string */
    render(): string;
    /** Override in subclass: called after render, set up event listeners here */
    onReady(): void;
    /** Dispatch a CustomEvent from this element */
    emitEvent(name: any, detail: any): void;
    /** Query within shadow root */
    $(selector: any): any;
    /** Query all within shadow root */
    $$(selector: any): NodeListOf<any> | undefined;
    /** Open a <dialog> inside the shadow root */
    open(): void;
    /** Close and remove this component */
    close(): void;
}
