/**
 * Minimal named-event emitter. Subclasses declare the event names they
 * support; listening for anything else is reported and ignored.
 *
 * A subclass names its events — and the payload each one carries — by passing
 * an event map through `@extends`, which is what gives callers a typed
 * `handler` argument per event name:
 *
 *   /** @extends {EventListener<{ open: void, data: Uint8Array }>} *\/
 *   class MySocket extends EventListener { ... }
 *
 * @template {Record<string, unknown>} [EventMap=Record<string, unknown>]
 */
export default class EventListener<EventMap extends Record<string, unknown> = Record<string, unknown>> {
    /** @param {(keyof EventMap & string)[] | string[]} eventNames */
    constructor(eventNames: (keyof EventMap & string)[] | string[]);
    /**
     * Calls every handler registered for `eventName` with `data`.
     *
     * @template {keyof EventMap & string} K
     * @param {K} eventName
     * @param {EventMap[K]} [data]
     * @returns {void}
     */
    emit<K extends keyof EventMap & string>(eventName: K, data?: EventMap[K]): void;
    /**
     * Registers `callback` for `eventName`. Returns `undefined` — after
     * reporting it — when the event is not one this emitter supports.
     *
     * @template {keyof EventMap & string} K
     * @param {K} eventName
     * @param {(data: EventMap[K]) => void} callback
     * @returns {this | undefined}
     */
    on<K extends keyof EventMap & string>(eventName: K, callback: (data: EventMap[K]) => void): this | undefined;
    /**
     * Removes a handler previously registered with `on`.
     *
     * @template {keyof EventMap & string} K
     * @param {K} eventName
     * @param {(data: EventMap[K]) => void} callback
     * @returns {this | undefined}
     */
    off<K extends keyof EventMap & string>(eventName: K, callback: (data: EventMap[K]) => void): this | undefined;
    #private;
}
