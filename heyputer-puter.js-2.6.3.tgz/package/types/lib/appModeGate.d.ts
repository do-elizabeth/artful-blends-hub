export function isFramedDocument(scope?: typeof globalThis): boolean;
