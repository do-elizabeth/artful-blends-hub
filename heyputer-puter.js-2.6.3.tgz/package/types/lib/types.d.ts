/**
 * Constructor of `Class` whose instances omit the `Keys` members. Cast a
 * class to this to keep implementation-only fields (like the owning Puter
 * instance) off the public type without wrapping the class at runtime.
 *
 * The constraint must be `any[]`, not `unknown[]`: a constructor with typed
 * parameters isn't assignable to `new (...args: unknown[])`.
 */
export type OmitMembers<Class extends new (...args: any[]) => any, Keys extends keyof InstanceType<Class>> = new (...args: ConstructorParameters<Class>) => Omit<InstanceType<Class>, Keys>;
/**
 * The environment the SDK is running in.
 */
export type PuterEnvironment = "app" | "gui" | "web" | "web-worker" | "service-worker" | "nodejs";
/**
 * The legacy positional callbacks most methods accept alongside the promise
 * they return.
 */
export type RequestCallbacks<T = unknown> = {
    /**
     * Called with the result once the call succeeds.
     */
    success?: ((value: T) => void) | undefined;
    /**
     * Called with the rejection reason if the call fails.
     */
    error?: ((reason: unknown) => void) | undefined;
};
export type APILoggingConfigOwn = {
    /**
     * Whether request logging is on.
     */
    enabled?: boolean | undefined;
};
export type APILoggingConfig = APILoggingConfigOwn & Record<string, unknown>;
/**
 * Standard pagination request params shared by list APIs
 * (`puter.apps.list()`, `puter.hosting.list()`, `puter.workers.list()`,
 * `puter.fs.readdir()`).
 */
export type ListPaginationOptions = {
    /**
     * Maximum items per page. Each endpoint documents its cap and default.
     */
    limit?: number | undefined;
    /**
     * Skips the given number of items. Cannot be combined with `cursor` or
     * `stream`; prefer `cursor` — requests get slower and more expensive the larger the offset.
     */
    offset?: number | undefined;
    /**
     * Opaque continuation cursor. Pass `null` for the first page, then
     * each page's `cursor` to fetch the next one.
     */
    cursor?: string | null | undefined;
    /**
     * When `true`, the result includes a `total` count of every item
     * across all pages.
     */
    includeTotal?: boolean | undefined;
};
/**
 * One page of a paginated listing.
 */
export type ListPage<T = unknown> = {
    /**
     * The items on this page. A page may hold fewer than `limit` items while more pages exist.
     */
    items: T[];
    /**
     * Present only while more pages exist; pass it to the next call to resume.
     */
    cursor?: string | undefined;
    /**
     * Total item count across all pages; present when requested via `includeTotal`.
     */
    total?: number | undefined;
};
/**
 * The `stream: true` form of list methods: returns an async iterator of
 * pages for `for await ... of` instead of a promise.
 */
export type ListStreamOptions = {
    /**
     * Stream page envelopes as they are fetched.
     */
    stream: true;
    /**
     * Maximum items per page. Defaults to the endpoint's page size.
     */
    limit?: number | undefined;
    /**
     * Start streaming from a previous page's `cursor` instead of the beginning.
     */
    cursor?: string | null | undefined;
    /**
     * Include a `total` count on the first streamed page.
     */
    includeTotal?: boolean | undefined;
};
export type PaginationOptions = {
    page?: number | undefined;
    per_page?: number | undefined;
};
export type PaginatedResult<T = unknown> = {
    data: T[];
    page?: number | undefined;
    pages?: number | undefined;
};
/**
 * A tool the SDK exposes to a parent app over the `puter.tools` bridge.
 */
export type ToolSchema = {
    /**
     * The tool's JSON-schema description, in OpenAI function-calling form.
     */
    function: {
        name: string;
        description: string;
        parameters: Record<string, unknown>;
        strict?: boolean;
    };
    /**
     * Runs the tool with the parameters the caller supplied.
     */
    exec: (parameters: Record<string, unknown>) => unknown | Promise<unknown>;
};
