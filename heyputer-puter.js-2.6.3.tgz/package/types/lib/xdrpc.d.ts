/**
 * This module provides a simple RPC mechanism for cross-document
 * (iframe / window.postMessage) communication.
 */
export const $SCOPE: "9a9c83a4-7897-43a0-93b9-53217b84fde6";
/**
 * The CallbackManager is used to manage callbacks for RPCs.
 * It is used by the dehydrator and hydrator to store and retrieve
 * the functions that are being called remotely.
 */
export class CallbackManager {
    callbacks: Map<any, any>;
    register_callback(callback: any): number;
    attach_to_source(source: any): void;
    #private;
}
/**
 * The dehydrator replaces functions in an object with identifiers,
 * so that hydrate() can be called on the other side of the frame
 * to bind RPC stubs. The original functions are stored in a map
 * so that they can be called when the RPC is invoked.
 */
export class Dehydrator {
    constructor({ callbackManager }: {
        callbackManager: any;
    });
    callbackManager: any;
    dehydrate(value: any): any;
    dehydrate_value_(value: any): any;
}
/**
 * The hydrator binds RPC stubs to the functions that were
 * previously dehydrated. This allows the RPC to be invoked
 * on the other side of the frame.
 */
export class Hydrator {
    constructor({ target }: {
        target: any;
    });
    target: any;
    hydrate(value: any): any;
    hydrate_value_(value: any): any;
}
