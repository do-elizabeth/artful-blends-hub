/**
 * Client-side page iteration for list APIs that follow the standard
 * `{ items, cursor?, total? }` envelope (doc/pagination.md). List modules
 * build a `fetchPage` closure that issues one request with their base
 * arguments merged under the per-page pagination params.
 */
export type ListPage = {
    items: unknown[];
    cursor?: string;
    total?: number;
};
/**
 * Client-side page iteration for list APIs that follow the standard
 * `{ items, cursor?, total? }` envelope (doc/pagination.md). List modules
 * build a `fetchPage` closure that issues one request with their base
 * arguments merged under the per-page pagination params.
 */
export type FetchPage = (pageParams: {
    cursor: string | null;
    includeTotal?: boolean;
}) => Promise<ListPage | unknown[]>;
/**
 * Fetches every page and returns the concatenated items — the legacy
 * full-listing shape, produced with bounded per-request work.
 *
 * @param {FetchPage} fetchPage
 * @returns {Promise<unknown[]>}
 */
export function fetchAllPages(fetchPage: FetchPage): Promise<unknown[]>;
/**
 * Client-side page iteration for list APIs that follow the standard
 * `{ items, cursor?, total? }` envelope (doc/pagination.md). List modules
 * build a `fetchPage` closure that issues one request with their base
 * arguments merged under the per-page pagination params.
 *
 * @typedef {{ items: unknown[], cursor?: string, total?: number }} ListPage
 * @typedef {(pageParams: { cursor: string | null, includeTotal?: boolean }) => Promise<ListPage | unknown[]>} FetchPage
 */
/**
 * Async generator over page envelopes, following `cursor` until it is
 * absent. `includeTotal` is sent on the first request only — totals cost
 * more the more items exist, and the count doesn't change page to page.
 * A backend that ignores pagination params responds with a bare array;
 * that becomes the one and only page, so old backends stay compatible.
 *
 * @param {FetchPage} fetchPage
 * @param {{ cursor?: string | null, includeTotal?: boolean }} [opts]
 * @returns {AsyncGenerator<ListPage, void, undefined>}
 */
export function iteratePages(fetchPage: FetchPage, opts?: {
    cursor?: string | null;
    includeTotal?: boolean;
}): AsyncGenerator<ListPage, void, undefined>;
