/**
 * A `fetch`-Response-like view over a
 *   completed (or streaming) XHR.
 */
export type PuterResponse = {
    /**
     * - Status in the 200-299 range.
     */
    ok: boolean;
    status: number;
    statusText: string;
    /**
     * - Final response URL.
     */
    url: string;
    headers: {
        get(name: string): string | null;
    };
    json: () => Promise<any>;
    text: () => Promise<string>;
    blob: () => Promise<Blob>;
    arrayBuffer: () => Promise<ArrayBuffer>;
    /**
     * - Parsed NDJSON lines; only
     * meaningful for `application/x-ndjson` responses.
     */
    stream: () => AsyncGenerator<any>;
};
/**
 * A driver method to invoke. `iface` is the interface name and `driver` the
 * concrete implementation behind it, which the backend resolves to the
 * interface's default when omitted. `puter` is the SDK instance the call runs
 * against; it falls back to the global instance.
 */
export type DriverCall = {
    iface: string;
    method: string;
    args?: unknown;
    driver?: string;
    testMode?: boolean;
    puter?: unknown;
};
/**
 * The one XHR builder both `initXhr` (utils.js) and `fetchUrl` wrap. Opens the
 * request, applies headers/credentials/responseType, and stashes the whole
 * `spec` on `xhr._puterReq` as the single replay representation — any attempt
 * (reauth, permission, transient) rebuilds the request by calling
 * `buildXhr(spec)` again, which re-reads the live token when
 * `includePuterAuth`.
 *
 * @param {Object} spec
 * @param {string} spec.url - Full request URL.
 * @param {string} [spec.method='GET'] Default is `'GET'`
 * @param {Object} [spec.headers] - Extra headers (nullish values skipped).
 * @param {boolean} [spec.includePuterAuth=false] - Add a fresh `Authorization:
 *   Bearer`. Default is `false`
 * @param {string} [spec.authToken] - The token to send when there is no live
 *   one to read — during construction, before `globalThis.puter` is assigned —
 *   or, without `includePuterAuth`, a token that isn't the live one at all.
 * @param {boolean} [spec.withCredentials=true] Default is `true`
 * @param {string} [spec.responseType=''] Default is `''`
 * @param {Object} [spec.logId] - Pre-built apiCallLogger request id.
 * @returns {XMLHttpRequest}
 */
export function buildXhr(spec: {
    url: string;
    method?: string | undefined;
    headers?: Object | undefined;
    includePuterAuth?: boolean | undefined;
    authToken?: string | undefined;
    withCredentials?: boolean | undefined;
    responseType?: string | undefined;
    logId?: Object | undefined;
}): XMLHttpRequest;
/**
 * @param {string} key - Fully-qualified request key (namespace it yourself,
 *   e.g. `${method}:${url}:${bodyKey}`).
 * @param {() => Promise<any>} factory - Runs the request; called only on a
 *   miss.
 * @param {{ windowMs?: number }} [opts]
 * @returns {Promise<any>} Shared promise (resolved value shared by reference).
 */
export function dedupe(key: string, factory: () => Promise<any>, { windowMs }?: {
    windowMs?: number;
}): Promise<any>;
/**
 * Driver call resolving the method's `result`, the shape `puter.ai.*`,
 * `puter.kv.*`, `puter.apps.*` and friends expose. Rejects with the driver's
 * error payload on failure, drives the env-specific auth / funding / email
 * prompts, and resolves an async iterator of lines for a streaming response.
 *
 * @param {DriverCall} call
 * @param {{
 *     responseType?: '' | 'text' | 'blob';
 *     readonly?: boolean;
 *     transform?: (result: unknown) => unknown;
 *     onError?: (error: unknown) => void;
 * }} [opts]
 *   `readonly` marks the method retry-safe on transient failures (a
 *   rate/concurrency 429 replays either way — see GATE_REJECT_STATUS),
 *   `transform` post-processes a successful result, and `onError` is the legacy
 *   error callback the module APIs accept alongside the promise.
 * @returns {Promise<unknown>}
 */
export function driverCall(call: DriverCall, opts?: {
    responseType?: "" | "text" | "blob";
    readonly?: boolean;
    transform?: (result: unknown) => unknown;
    onError?: (error: unknown) => void;
}): Promise<unknown>;
/**
 * Driver call resolving the response envelope (`{ success, result }`) as the
 * backend sent it — the shape `puter.drivers.call()` has always returned. A
 * driver-level failure resolves with the envelope instead of rejecting; only
 * transport failures and unreadable responses throw.
 *
 * NDJSON resolves an async iterator of parsed lines and `octet-stream` a Blob,
 * neither with the per-line prompts `driverCall` layers on.
 *
 * @param {DriverCall} call
 * @returns {Promise<unknown>}
 */
export function driverCallEnvelope(call: DriverCall): Promise<unknown>;
/**
 * XHR-based `fetch()` replacement. Returns a `fetch`-Response-like object.
 *
 * Fetch semantics: the promise resolves for any HTTP status (`ok` reflects
 * 2xx); it rejects only on network/abort errors. The one exception is a 401
 * carrying a reauth signal — the reauth flow is driven first and, on success,
 * the request is replayed once with the fresh token (transparent recovery). A
 * non-recoverable 401 resolves as an `ok: false` response like any other.
 *
 * @param {string} url - Full request URL (callers own origin composition).
 * @param {Object} [opts]
 * @param {boolean} [opts.includePuterAuth=false] - Add `Authorization: Bearer
 *   <puter.authToken>`. Default is `false`
 * @param {string} [opts.authToken] - The Bearer credential to send when the
 *   live `puter.authToken` can't be read yet (boot-time calls, before the
 *   global is assigned) or, without `includePuterAuth`, a token that isn't the
 *   live one at all (one being exchanged for another).
 * @param {string} [opts.method='GET'] Default is `'GET'`
 * @param {Object} [opts.headers] - Extra request headers (undefined/null values
 *   skipped).
 * @param {string | Blob | ArrayBuffer | FormData | null} [opts.body]
 * @param {'' | 'text' | 'json' | 'blob' | 'arraybuffer'} [opts.responseType='']
 *   Default is `''`
 * @param {boolean} [opts.withCredentials=true] Default is `true`
 * @param {AbortSignal} [opts.signal]
 * @param {{ service: string; operation: string; params?: Object }} [opts.logContext]
 *   Semantic context for the centralized API-call log. Omit to log generically.
 * @param {boolean} [opts.retry] - Force-enable (`true`) or disable (`false`)
 *   transient-failure auto-retry for this request; omit for the default
 *   (idempotent methods retry, others don't). Never retries a write.
 * @param {boolean | string} [opts.dedupe] - Coalesce concurrent identical
 *   in-flight requests (reads only): `true` auto-keys by method+url+body, or
 *   pass a key.
 * @param {boolean} [opts.interactiveReauth=true] - Whether a reauth-recoverable
 *   401 may raise sign-in UI. Pass `false` for requests the user didn't ask for
 *   (boot telemetry, cache warmers): the stale token is dropped silently and
 *   the 401 surfaces to the caller instead. Default is `true`
 * @param {Object} [opts.paginate] - Reserved for a later sprint step (ignored).
 * @returns {Promise<PuterResponse>}
 */
export function fetchUrl(url: string, opts?: {
    includePuterAuth?: boolean | undefined;
    authToken?: string | undefined;
    method?: string | undefined;
    headers?: Object | undefined;
    body?: string | Blob | ArrayBuffer | FormData | null | undefined;
    responseType?: "" | "text" | "json" | "blob" | "arraybuffer" | undefined;
    withCredentials?: boolean | undefined;
    signal?: AbortSignal | undefined;
    logContext?: {
        service: string;
        operation: string;
        params?: Object;
    } | undefined;
    retry?: boolean | undefined;
    dedupe?: string | boolean | undefined;
    interactiveReauth?: boolean | undefined;
    paginate?: Object | undefined;
}): Promise<PuterResponse>;
/**
 * Read a completed XHR as a driver/API response: JSON when the body parses as
 * JSON, the raw text when it doesn't, and — for `responseType: 'blob'` — the
 * Blob itself (wrapped in a success envelope unless the response declares a
 * type we can read directly).
 *
 * @param {XMLHttpRequest} xhr
 * @returns {Promise<unknown>}
 */
export function parseResponse(xhr: XMLHttpRequest): Promise<unknown>;
/**
 * Shared 401 reauth policy for a parsed response body. Drives the env-specific
 * reauth flow on the Puter class and tells the caller what to do next, so the
 * fetch replacement (`fetchUrl`) and the generic XHR path (`handle_resp` in
 * utils.js) apply the exact same policy.
 *
 * Recognised backend signals:
 *
 * - `reauth_required` (`authProbe`): revoked sessions and expired sessions
 *   beyond the silent re-mint window.
 * - `token_auth_failed` (legacy `APIError.create('token_auth_failed')`): token no
 *   longer valid, prompt re-login (web env only).
 *
 * @param {Object} resp - The parsed response body.
 * @param {Object} [opts]
 * @param {boolean} [opts.interactive=true] - Whether this request may raise
 *   sign-in UI. False for requests the user didn't ask for (see
 *   `resolveBackgroundReauth`). Default is `true`
 * @param {string} [opts.sentToken] - The token the failed request carried, so a
 *   background reauth only discards a token that is still the current one.
 * @returns {Promise<
 *     { action: 'replay' } | { action: 'reject'; error: Object } | null
 * >}
 *   `replay` when the caller should re-issue the request once with the fresh
 *   token, `reject` with the error to surface, or `null` when this is not a
 *   reauth-recoverable 401 and the caller should handle it normally.
 */
export function resolveReauth(resp: Object, { interactive, sentToken }?: {
    interactive?: boolean | undefined;
    sentToken?: string | undefined;
}): Promise<{
    action: "replay";
} | {
    action: "reject";
    error: Object;
} | null>;
/**
 * The one retry loop. Sends `spec` (rebuilding per attempt), classifies each
 * outcome, and retries on reauth / permission / transient causes; otherwise
 * hands the outcome to `shape`.
 *
 * @param {Object} spec - BuildXhr spec (+ optional buildBody, signal).
 * @param {Object} opts
 * @param {boolean} [opts.retrySafe=false] - Eligible for transient backoff
 *   retry. Default is `false`
 * @param {boolean} [opts.retryGated=true] - Eligible for 429 backoff retry,
 *   regardless of method (the gate rejects before the handler runs). Default is
 *   `true`
 * @param {string | null} [opts.permission] - `driver:<iface>:<method>` enables
 *   the permission cause.
 * @param {(lineStream, xhr) => any} opts.shapeStream - Wrap an NDJSON stream.
 * @param {(outcome) => any} opts.shape - Shape a buffered outcome (may throw).
 */
export function sendWithRetry(spec: Object, { retrySafe, retryGated, permission, shapeStream, shape, }: {
    retrySafe?: boolean | undefined;
    retryGated?: boolean | undefined;
    permission?: string | null | undefined;
    shapeStream: (lineStream: any, xhr: any) => any;
    shape: (outcome: any) => any;
}): Promise<any>;
