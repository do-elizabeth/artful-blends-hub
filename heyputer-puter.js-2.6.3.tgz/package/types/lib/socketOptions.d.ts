export function socketAutoUnref(puter: Puter): boolean;
export type Puter = import("../index.js").Puter;
