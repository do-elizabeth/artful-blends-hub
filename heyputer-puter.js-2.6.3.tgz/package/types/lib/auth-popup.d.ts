export function hasUserActivation(): boolean;
export function openAuthPopup(url: string, title?: string): Window | null;
