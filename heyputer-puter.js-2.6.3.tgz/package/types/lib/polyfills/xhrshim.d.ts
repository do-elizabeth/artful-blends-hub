export default XMLHttpRequestShim;
declare const XMLHttpRequestShim: {
    new (): {
        onreadystatechange(): void;
        readyState: any;
        response: any;
        responseType: string;
        responseURL: string;
        status: number;
        statusText: string;
        timeout: number;
        withCredentials: boolean;
        upload: {
            addEventListener(): void;
        };
        get responseText(): any;
        get responseXML(): void;
        abort(): void;
        open(method: any, url: any): void;
        setRequestHeader(header: any, value: any): void;
        overrideMimeType(mimeType: any): void;
        getAllResponseHeaders(): string;
        getResponseHeader(headerName: any): string | null;
        send(body?: null): void;
        [sDispatch](evt: any): void;
        addEventListener(type: string, callback: EventListenerOrEventListenerObject | null, options?: AddEventListenerOptions | boolean): void;
        dispatchEvent(event: Event): boolean;
        removeEventListener(type: string, callback: EventListenerOrEventListenerObject | null, options?: EventListenerOptions | boolean): void;
    };
    get UNSENT(): number;
    get OPENED(): number;
    get HEADERS_RECEIVED(): number;
    get LOADING(): number;
    get DONE(): number;
};
declare const sDispatch: unique symbol;
