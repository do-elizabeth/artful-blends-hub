export class FileReaderPoly {
    result: any;
    error: any;
    onload: any;
    onerror: any;
    onloadend: any;
    readAsDataURL(blob: any): void;
    #private;
}
