export default localStorageMemory;
declare namespace localStorageMemory {
    let length: number;
    /**
     * returns item for passed key, or null
     *
     * @para {String} key
     *       name of item to be returned
     * @returns {String|null}
     */
    function getItem(key: any): string | null;
    /**
     * sets item for key to passed value, as String
     *
     * @para {String} key
     *       name of item to be set
     * @para {String} value
     *       value, will always be turned into a String
     * @returns {undefined}
     */
    function setItem(key: any, value: any): undefined;
    /**
     * removes item for passed key
     *
     * @para {String} key
     *       name of item to be removed
     * @returns {undefined}
     */
    function removeItem(key: any): undefined;
    /**
     * returns name of key at passed index
     *
     * @para {Number} index
     *       Position for key to be returned (starts at 0)
     * @returns {String|null}
     */
    function key(index: any): string | null;
    /**
     * removes all stored items and sets length to 0
     *
     * @returns {undefined}
     */
    function clear(): undefined;
}
