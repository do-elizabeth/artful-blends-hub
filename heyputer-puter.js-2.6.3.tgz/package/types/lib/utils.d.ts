export function blobToDataUri(blob: any): Promise<any>;
/**
 * Handles an error by invoking a specified error callback and then rejecting a promise.
 *
 * @param {Function} error_cb - An optional callback function that is called if it's provided.
 *                              This function should take an error object as its only argument.
 * @param {Function} reject_func - A function used to reject a promise. It should take an error object
 *                                 as its only argument.
 * @param {Object} error - The error object that is passed to both the error callback and the reject function.
 *
 * @returns {void} The function does not return a value but will call the reject function with the error.
 */
export function handle_error(error_cb: Function, reject_func: Function, error: Object): void;
/**
 * Initializes and returns an XMLHttpRequest object configured for a specific API endpoint, method, and headers.
 *
 * @param {string} endpoint - The API endpoint to which the request will be sent. This is appended to the API origin URL.
 * @param {string} APIOrigin - The origin URL of the API. This is prepended to the endpoint.
 * @param {string} authToken - The authorization token used for accessing the API. This is included in the request headers.
 * @param {string} [method='post'] - The HTTP method to be used for the request. Defaults to 'post' if not specified.
 * @param {string} [contentType='application/json;charset=UTF-8'] - The content type of the request. Defaults to
 *                                                                  'application/json;charset=UTF-8' if not specified.
 *
 * @returns {XMLHttpRequest} The initialized XMLHttpRequest object.
 */
export function initXhr(endpoint: string, APIOrigin: string, authToken: string, method?: string, contentType?: string, responseType?: undefined): XMLHttpRequest;
export function isVideoInput(url: any): boolean;
/**
 * Makes the function for one driver method: the returned function takes either
 * a named-parameters object or the positional arguments listed in `argNames`,
 * optionally followed by legacy success/error callbacks, and resolves the
 * driver's `result`.
 *
 * `error` is forwarded to `driverCall` as `onError`; `success` is consumed so
 * it stays off the wire but is never invoked — these methods are promise-only.
 * That is deliberate: it has never fired, so invoking it now would double-run
 * handlers in apps that pass one and also await the promise.
 *
 * @param {{
 *   iface: string,
 *   method: string,
 *   argNames?: string[],
 *   driver?: string,
 *   puter?: unknown,
 *   testMode?: boolean,
 *   readonly?: boolean,
 *   responseType?: '' | 'text' | 'blob',
 *   preprocess?: (args: Record<string, unknown>) => Record<string, unknown>,
 *   transform?: (result: unknown) => unknown,
 * }} spec `iface`/`driver`/`method`/`testMode` address the driver call itself
 *   (see `driverCall`); the rest configures this wrapper.
 * @returns {(...args: unknown[]) => Promise<unknown>}
 */
export function makeDriverMethod(spec: {
    iface: string;
    method: string;
    argNames?: string[];
    driver?: string;
    puter?: unknown;
    testMode?: boolean;
    readonly?: boolean;
    responseType?: "" | "text" | "blob";
    preprocess?: (args: Record<string, unknown>) => Record<string, unknown>;
    transform?: (result: unknown) => unknown;
}): (...args: unknown[]) => Promise<unknown>;
export function setupXhrEventHandlers(xhr: any, success_cb: any, error_cb: any, resolve_func: any, reject_func: any): void;
/**
 * A function that generates a UUID (Universally Unique Identifier) using the version 4 format,
 * which are random UUIDs. It uses the cryptographic number generator available in modern browsers.
 *
 * The generated UUID is a 36 character string (32 alphanumeric characters separated by 4 hyphens).
 * It follows the pattern: xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx, where x is any hexadecimal digit
 * and y is one of 8, 9, A, or B.
 *
 * @returns {string} Returns a new UUID v4 string.
 *
 * @example
 *
 * let id = this.#uuidv4(); // Generate a new UUID
 *
 */
export function uuidv4(): string;
