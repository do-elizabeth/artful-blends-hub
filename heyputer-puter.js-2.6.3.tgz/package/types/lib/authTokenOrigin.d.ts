export function isStoredTokenUsableForOrigin({ boundOrigin, currentOrigin, defaultAPIOrigin, }: {
    boundOrigin: string | null | undefined;
    currentOrigin: string;
    defaultAPIOrigin: string;
}): boolean;
