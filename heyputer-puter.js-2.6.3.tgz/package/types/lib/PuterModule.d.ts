/** @typedef {import('../index.js').Puter} Puter */
/**
 * Base for the `puter.*` modules. Holds the owning Puter instance and reads
 * auth state off it live, so a token or origin change is visible everywhere
 * at once and there is nothing to keep in sync.
 *
 * A module that holds a connection open (rather than reading state per call)
 * can subscribe with `puter.onAuthStateChanged()` to rebuild it.
 */
export class PuterModule {
    /** @param {Puter} puter */
    constructor(puter: Puter);
    /** @type {Puter} */
    puter: Puter;
    /** @returns {string | null | undefined} */
    get authToken(): string | null | undefined;
    /** @returns {string} */
    get APIOrigin(): string;
    /** @returns {string | undefined} */
    get appID(): string | undefined;
}
export type Puter = import("../index.js").Puter;
