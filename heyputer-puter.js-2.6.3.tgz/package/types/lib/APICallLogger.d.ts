export default APICallLogger;
/**
 * APICallLogger provides centralized logging for all API calls made by the puter-js SDK.
 * It logs API calls in a simple format: service - operation - params - result
 */
declare class APICallLogger {
    constructor(config?: {});
    config: {
        enabled: any;
    };
    /**
     * Updates the logger configuration
     * @param {Object} newConfig - New configuration options
     */
    updateConfig(newConfig: Object): void;
    /**
     * Enables API call logging
     */
    enable(): void;
    /**
     * Disables API call logging
     */
    disable(): void;
    /**
     * Checks if logging is enabled for the current configuration
     * @returns {boolean}
     */
    isEnabled(): boolean;
    /**
     * Logs the completion of an API request in a simple format
     * @param {Object} options - Request completion options
     */
    logRequest(options?: Object): void;
    /**
     * Gets current logging statistics
     * @returns {Object}
     */
    getStats(): Object;
}
